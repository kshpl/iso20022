from __future__ import annotations

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at

from .findings import Finding


def _node(parent: etree._Element | None, adapter: Adapter, path: str) -> etree._Element | None:
    if parent is None:
        return None
    return parent.find("/".join(adapter.q(part) for part in path.split("/")))


def _agent_identity(agent: etree._Element | None, adapter: Adapter) -> dict[str, str]:
    if agent is None:
        return {}
    paths = (
        "FinInstnId/BIC", "FinInstnId/BICFI", "FinInstnId/LEI",
        "FinInstnId/ClrSysMmbId/ClrSysId/Cd", "FinInstnId/ClrSysMmbId/MmbId",
        "FinInstnId/Othr/Id", "FinInstnId/Nm",
    )
    return {path: value for path in paths if (value := text_at(agent, adapter, path))}


def validate_mdr(groups: list[etree._Element], adapter: Adapter) -> list[Finding]:
    findings: list[Finding] = []
    names = {
        1: "PAYMENT_TYPE_INFORMATION", 2: "CHEQUE_INSTRUCTION", 3: "CHARGES_ACCOUNT",
        4: "CHARGES_ACCOUNT_AGENT", 5: "CHARGE_BEARER", 6: "ULTIMATE_DEBTOR",
        7: "CHEQUE_CREDITOR_ACCOUNT", 8: "CHEQUE_DELIVERY_CREDITOR_AGENT",
        9: "CHEQUE_DELIVERY_NO_CREDITOR_AGENT", 10: "NON_CHEQUE_PAYMENT_METHOD",
        11: "CHEQUE_NO_DELIVERY_NO_CREDITOR_AGENT", 12: "INTERMEDIARY_AGENT_2",
        13: "INTERMEDIARY_AGENT_3", 14: "CHEQUE_BENEFICIARY",
        15: "INTERMEDIARY_AGENT_1_ACCOUNT", 16: "INTERMEDIARY_AGENT_2_ACCOUNT",
        17: "INTERMEDIARY_AGENT_3_ACCOUNT", 18: "CHEQUE_MATURITY_DATE",
        19: "INSTRUCTION_FOR_DEBTOR_AGENT",
    }

    def add(number: int, message: str, node: etree._Element | None) -> None:
        findings.append(Finding(f"MDR_{names[number]}", message, node))

    for group in groups:
        method = text_at(group, adapter, "PmtMtd")
        group_type = _node(group, adapter, "PmtTpInf")
        group_charge = _node(group, adapter, "ChrgBr")
        group_ultimate = _node(group, adapter, "UltmtDbtr")
        group_debtor_instruction = _node(group, adapter, "InstrForDbtrAgt")
        charges_account = _node(group, adapter, "ChrgsAcct")
        charges_agent = _node(group, adapter, "ChrgsAcctAgt")
        debtor_agent = _node(group, adapter, "DbtrAgt")

        if charges_agent is not None and charges_account is None:
            add(3, "ChrgsAcctAgt wymaga obecności ChrgsAcct.", charges_agent)
        debtor_identity = _agent_identity(debtor_agent, adapter)
        charges_identity = _agent_identity(charges_agent, adapter)
        if charges_agent is not None and debtor_identity and not debtor_identity.items() <= charges_identity.items():
            add(4, "ChrgsAcctAgt musi wskazywać instytucję dłużnika; może jedynie doprecyzować jej oddział.", charges_agent)

        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            tx_type = _node(tx, adapter, "PmtTpInf")
            tx_charge = _node(tx, adapter, "ChrgBr")
            tx_ultimate = _node(tx, adapter, "UltmtDbtr")
            cheque = _node(tx, adapter, "ChqInstr")
            creditor = _node(tx, adapter, "Cdtr")
            creditor_account = _node(tx, adapter, "CdtrAcct")
            creditor_agent = _node(tx, adapter, "CdtrAgt")

            if group_type is not None and tx_type is not None:
                add(1, "PmtTpInf nie może występować jednocześnie na poziomie grupy i transakcji.", tx_type)
            if method != "CHK" and cheque is not None:
                add(2, "ChqInstr jest dozwolone wyłącznie dla metody płatności CHK.", cheque)
            if group_charge is not None and tx_charge is not None:
                add(5, "ChrgBr nie może występować jednocześnie na poziomie grupy i transakcji.", tx_charge)
            if group_ultimate is not None and tx_ultimate is not None:
                add(6, "UltmtDbtr nie może występować jednocześnie na poziomie grupy i transakcji.", tx_ultimate)
            tx_debtor_instruction = _node(tx, adapter, "InstrForDbtrAgt")
            if group_debtor_instruction is not None and tx_debtor_instruction is not None:
                add(19, "InstrForDbtrAgt nie może występować jednocześnie na poziomie grupy i transakcji.", tx_debtor_instruction)
            if method == "CHK" and creditor_account is not None:
                add(7, "CdtrAcct nie jest dozwolone dla płatności czekiem.", creditor_account)

            delivery = text_at(tx, adapter, "ChqInstr/DlvryMtd/Cd")
            agent_required_delivery = {"MLFA", "CRFA", "RGFA", "PUFA"}
            if method == "CHK" and delivery in agent_required_delivery and creditor_agent is None:
                add(8, "Wybrana metoda dostarczenia czeku wymaga CdtrAgt.", cheque)
            if method == "CHK" and delivery and delivery not in agent_required_delivery and creditor_agent is not None:
                add(9, "CdtrAgt nie jest dozwolony dla wybranej metody dostarczenia czeku.", creditor_agent)
            if method != "CHK" and creditor is None and creditor_account is None:
                add(10, "Płatność bez Cdtr wymaga CdtrAcct.", tx)
            if method == "CHK" and cheque is not None and delivery is None and creditor_agent is not None:
                add(11, "CdtrAgt nie jest dozwolony dla czeku bez DlvryMtd.", creditor_agent)

            for number, account_name, agent_name, predecessor in (
                (12, "IntrmyAgt2", "IntrmyAgt2", "IntrmyAgt1"),
                (13, "IntrmyAgt3", "IntrmyAgt3", "IntrmyAgt2"),
                (15, "IntrmyAgt1Acct", "IntrmyAgt1", None),
                (16, "IntrmyAgt2Acct", "IntrmyAgt2", None),
                (17, "IntrmyAgt3Acct", "IntrmyAgt3", None),
            ):
                source = _node(tx, adapter, account_name)
                required = _node(tx, adapter, predecessor or agent_name)
                if source is not None and required is None:
                    add(number, f"{account_name} wymaga obecności {predecessor or agent_name}.", source)

            chqb = [node for node in tx.findall(f".//{adapter.q('InstrForCdtrAgt')}/{adapter.q('Cd')}") if node.text == "CHQB"]
            if chqb and creditor_account is not None:
                add(14, "Instrukcja CHQB wyklucza CdtrAcct.", creditor_account)
            maturity = _node(tx, adapter, "ChqInstr/ChqMtrtyDt")
            cheque_type = text_at(tx, adapter, "ChqInstr/ChqTp")
            if maturity is not None and cheque_type not in {"DRFT", "ELDR"}:
                add(18, "ChqMtrtyDt wymaga ChqTp o wartości DRFT albo ELDR.", maturity)
    return findings
