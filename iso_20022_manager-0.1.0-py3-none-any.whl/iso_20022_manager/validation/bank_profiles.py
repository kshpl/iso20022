from __future__ import annotations

import json
import re
from collections import Counter
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from functools import lru_cache
from importlib.resources import files

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, find_every, find_first, text_at
from iso_20022_manager.core.totals import Amount, read_amount

from .code_sets import reference_data
from .findings import Finding
from .bank_context import BNP_SPLIT_CODES, BNP_SPLIT_PROPRIETARY, creditor_bank_country, is_mail, rule_source, seb_domestic
from .seb_accounts import validate_swedish_bban


BANK_PROFILE_PREFIXES = ("mbank-", "ing-", "santander-", "bnp-", "citidirect-", "pko-", "seb-")


@lru_cache(maxsize=1)
def profile_bundle() -> dict[str, object]:
    path = files("iso_20022_manager.resources").joinpath("profiles", "bank-profiles.json")
    return json.loads(path.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _profile_index() -> dict[str, dict[str, object]]:
    bundle = profile_bundle()
    latest = bundle["latest_onexml_source"]
    return {
        profile["profile_id"]: profile | {
            "latest_published_source": latest,
            "scope_notice": "Baza OneXML 5.0 z wybranymi kontrolami OneXML 5.2 (kwota, adres, koszty, księgowanie i PmtTpInf).",
        }
        if profile["profile_id"].startswith("ing-insidebusiness-") else profile
        for profile in bundle["profiles"]
    }


def profile_catalog() -> list[dict[str, object]]:
    return list(_profile_index().values())


def profile_ids() -> set[str]:
    return set(_profile_index())


def _manifest(profile_id: str) -> dict[str, object]:
    return _profile_index()[profile_id]


def _node(parent: etree._Element | None, adapter: Adapter, path: str) -> etree._Element | None:
    if parent is None:
        return None
    return find_first(parent, "/".join(adapter.q(part) for part in path.split("/")))


def _effective(group: etree._Element, tx: etree._Element, adapter: Adapter, path: str) -> str | None:
    if path.startswith("PmtTpInf/") and _node(tx, adapter, "PmtTpInf") is not None:
        # ISO/MDR uses one PmtTpInf level, not per-leaf merging. PKO explicitly
        # permits a transaction override; SEB permits transaction SEPA. Neither
        # may pick the other arm of a group Cd/Prtry choice by accident.
        return text_at(tx, adapter, path)
    return text_at(tx, adapter, path) or text_at(group, adapter, path)


def _first_node(*nodes: etree._Element | None) -> etree._Element | None:
    return next((node for node in nodes if node is not None), None)


def _required(findings: list[Finding], parent: etree._Element, adapter: Adapter, path: str, rule: str, label: str) -> etree._Element | None:
    node = _node(parent, adapter, path)
    if node is None or not (node.text or "").strip():
        findings.append(Finding(rule, f"Profil bankowy wymaga pola {label} ({path}).", node if node is not None else parent, category="profile"))
        return None
    return node


def _account(parent: etree._Element, adapter: Adapter, prefix: str) -> tuple[str | None, etree._Element | None, str | None]:
    iban = _node(parent, adapter, f"{prefix}/Id/IBAN")
    other = _node(parent, adapter, f"{prefix}/Id/Othr/Id")
    node = iban if iban is not None else other
    return ((node.text or "").replace(" ", "") if node is not None else None, node, "IBAN" if iban is not None else "OTHR" if other is not None else None)


def _service(group: etree._Element, tx: etree._Element, adapter: Adapter) -> str | None:
    return _effective(group, tx, adapter, "PmtTpInf/SvcLvl/Cd")


def _local_instrument(group: etree._Element, tx: etree._Element, adapter: Adapter) -> str | None:
    return _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Cd") or _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Prtry")


def _charge(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[str | None, etree._Element | None]:
    tx_node = _node(tx, adapter, "ChrgBr")
    group_node = _node(group, adapter, "ChrgBr")
    node = tx_node if tx_node is not None else group_node
    return (node.text if node is not None else None, node)


def _is_sepa(group: etree._Element, tx: etree._Element, adapter: Adapter, *, ing_pl: bool = False) -> bool:
    service = _service(group, tx, adapter)
    return service == "SEPA" or (ing_pl and service == "URGP" and read_amount(tx, adapter).currency == "EUR")


def _is_split(group: etree._Element, tx: etree._Element, adapter: Adapter) -> bool:
    purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") or _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Prtry")
    instrument = _local_instrument(group, tx, adapter) or ""
    return purpose in {"VATX", "SPLI", "SPLT"} or "VAT" in instrument or _node(tx, adapter, "RmtInf/Strd/TaxRmt") is not None


def _check_address(findings: list[Finding], party: etree._Element | None, adapter: Adapter, rule: str) -> None:
    address = _node(party, adapter, "PstlAdr")
    if address is None or len(address) == 0:
        return
    if _node(address, adapter, "Ctry") is None:
        findings.append(Finding(rule, "Adres pocztowy wymaga kodu kraju Ctry.", address, category="profile"))
    structured = any(_node(address, adapter, name) is not None for name in ("StrtNm", "BldgNb", "TwnNm"))
    if structured and _node(address, adapter, "TwnNm") is None:
        findings.append(Finding(rule, "Adres strukturalny lub hybrydowy wymaga TwnNm.", address, category="profile"))


def _valid_polish_account(value: str | None) -> bool:
    compact = (value or "").replace(" ", "").upper()
    if compact.startswith("PL"):
        compact = compact[2:]
    if not re.fullmatch(r"\d{26}", compact):
        return False
    rearranged = compact[2:] + "2521" + compact[:2]
    remainder = 0
    for digit in rearranged:
        remainder = (remainder * 10 + int(digit)) % 97
    return remainder == 1


def _require_instructed(findings, tx, amount: Amount, prefix, source):
    if amount.kind == "equivalent":
        findings.append(Finding(f"{prefix}_INSTRUCTED_AMOUNT", "Ten profil wymaga Amt/InstdAmt. Zastąp kwotę równoważną kwotą i walutą przelewu.", amount.node.getparent() if amount.node is not None else tx, category="profile", source=source))


def _check_minimum_cent(findings, tx, amount: Amount, prefix, source):
    if amount.value is not None and amount.value < Decimal("0.01"):
        findings.append(Finding(f"{prefix}_AMOUNT_MINIMUM", "Minimalna kwota przelewu wynosi 0,01.", amount.node if amount.node is not None else tx, category="profile", source=source))


def _check_sepa(findings: list[Finding], group: etree._Element, tx: etree._Element, adapter: Adapter, prefix: str, charge_values: set[str] = frozenset({"SLEV"}), *, equivalent_currency: etree._Element | None = None) -> None:
    amount = read_amount(tx, adapter)
    _, account_node, kind = _account(tx, adapter, "CdtrAcct")
    currency = equivalent_currency.text if equivalent_currency is not None else amount.currency
    currency_node = equivalent_currency if equivalent_currency is not None else amount.node
    if currency != "EUR":
        findings.append(Finding(f"{prefix}_SEPA_CURRENCY", "Przelew SEPA wymaga waluty EUR.", currency_node if currency_node is not None else tx, category="profile"))
    if kind != "IBAN":
        findings.append(Finding(f"{prefix}_SEPA_CREDITOR_IBAN", "Przelew SEPA wymaga rachunku odbiorcy w formacie IBAN.", account_node if account_node is not None else tx, category="profile"))
    charge, charge_node = _charge(group, tx, adapter)
    if charge not in charge_values:
        findings.append(Finding(f"{prefix}_SEPA_CHARGE", f"Dla SEPA ChrgBr musi mieć wartość: {', '.join(sorted(charge_values))}.", charge_node if charge_node is not None else tx, category="profile"))


def _check_common(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], prefix: str, *, money_orders: bool = False) -> None:
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    if header is not None:
        _required(findings, header, adapter, "MsgId", f"{prefix}_MSG_ID", "MsgId")
    for group in groups:
        method = _required(findings, group, adapter, "PmtMtd", f"{prefix}_PAYMENT_METHOD", "PmtMtd")
        cheque = method is not None and money_orders and method.text == "CHK"
        if method is not None and method.text != "TRF" and not cheque:
            allowed = "TRF albo CHK" if money_orders else "TRF"
            findings.append(Finding(f"{prefix}_PAYMENT_METHOD", f"Kanał przyjmuje PmtMtd={allowed}.", method, category="profile"))
        _required(findings, group, adapter, "PmtInfId", f"{prefix}_PMTINF_ID", "PmtInfId")
        if not any(text_at(group, adapter, path) for path in adapter.execution_date_paths):
            findings.append(Finding(f"{prefix}_EXECUTION_DATE", "Profil wymaga żądanej daty realizacji ReqdExctnDt.", group, category="profile"))
        _required(findings, group, adapter, "Dbtr/Nm", f"{prefix}_DEBTOR_NAME", "Dbtr/Nm")
        debtor_account, _, _ = _account(group, adapter, "DbtrAcct")
        if not debtor_account:
            findings.append(Finding(f"{prefix}_DEBTOR_ACCOUNT", "Profil wymaga rachunku dłużnika DbtrAcct.", group, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            _required(findings, tx, adapter, "Cdtr/Nm", f"{prefix}_CREDITOR_NAME", "Cdtr/Nm")
            creditor_account, _, _ = _account(tx, adapter, "CdtrAcct")
            if not creditor_account and not cheque and not (prefix == "MBANK_COMPANYNET" and is_mail(tx, adapter)):
                findings.append(Finding(f"{prefix}_CREDITOR_ACCOUNT", "Profil wymaga rachunku odbiorcy CdtrAcct.", tx, category="profile"))


def _validate_mbank(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], swiftnet: bool) -> None:
    prefix = "MBANK_SWIFTNET" if swiftnet else "MBANK_COMPANYNET"
    profile_id = "mbank-swiftnet-2026" if swiftnet else "mbank-companynet-2026"
    amount_source = rule_source(profile_id, "PDF tabele Amt/InstdAmt", product="transfer")
    foreign_source = rule_source(profile_id, "PDF §3, typ zlecenia do zagranicznego banku" if swiftnet else "PDF §6.6, s. 25", product="foreign")
    _check_common(findings, tree, adapter, groups, prefix)
    header = _node(_node(tree.getroot(), adapter, "CstmrCdtTrfInitn"), adapter, "GrpHdr")
    msg_id = _node(header, adapter, "MsgId")
    if msg_id is not None and re.search(r"\s", msg_id.text or ""):
        findings.append(Finding(f"{prefix}_MSG_ID_SPACE", "MsgId dla mBanku nie może zawierać spacji.", msg_id, category="profile"))
    if swiftnet:
        init_id = _node(header, adapter, f"InitgPty/Id/OrgId/{'AnyBIC' if adapter.message_identifier.endswith('.09') else 'BICOrBEI'}")
        if init_id is None:
            findings.append(Finding(f"{prefix}_INITIATING_BIC", "SWIFTNET wymaga identyfikatora BIC strony inicjującej.", header, category="profile"))
    instr: list[tuple[str, etree._Element]] = []
    for group in groups:
        if swiftnet or any(not is_mail(tx, adapter) for tx in group.findall(adapter.q("CdtTrfTxInf"))):
            _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BIC banku dłużnika")
        for member in group.iter(adapter.q("MmbId")):
            if member.text and not re.fullmatch(r"\d{8}", member.text):
                findings.append(Finding(f"{prefix}_CLEARING_MEMBER", "MmbId w profilu mBank musi zawierać dokładnie 8 cyfr.", member, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            _require_instructed(findings, tx, amount, prefix, amount_source)
            if swiftnet:
                _check_minimum_cent(findings, tx, amount, prefix, amount_source)
            end = _node(tx, adapter, "PmtId/EndToEndId")
            if end is None or not (end.text or "") or (swiftnet and end.text != " " and not end.text.strip()):
                message = "Profil bankowy wymaga pola EndToEndId." + (" SWIFTNET dopuszcza pojedynczą spację jako reprezentację braku referencji." if swiftnet else "")
                findings.append(Finding(f"{prefix}_ENDTOEND", message, end if end is not None else tx, category="profile", source=rule_source("mbank-swiftnet-2026" if swiftnet else "mbank-companynet-2026", "SWIFTNET PDF s. 8/14/19/25" if swiftnet else "CompanyNet tabela EndToEndId", product="transfer")))
            sepa = _is_sepa(group, tx, adapter)
            mail = not swiftnet and is_mail(tx, adapter)
            if mail:
                _validate_mbank_mail(findings, group, tx, adapter, header)
            ins = _node(tx, adapter, "PmtId/InstrId")
            if ins is not None and ins.text:
                instr.append((ins.text, ins))
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix)
            purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
            remittance_node = _node(tx, adapter, "RmtInf/Ustrd")
            remittance = remittance_node.text or "" if remittance_node is not None else ""
            split = purpose == "VATX" or remittance.startswith("/VAT/")
            if not sepa and not mail and not split and purpose != "TAXS":
                bank_country = creditor_bank_country(tx, adapter)
                currency_transfer = amount.currency not in {None, "PLN"}
                foreign_bank = bank_country not in {None, "PL"} or (bank_country is None and currency_transfer)
                if foreign_bank:
                    bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
                    if bic is None or not (bic.text or "").strip():
                        agent = _node(tx, adapter, "CdtrAgt")
                        findings.append(Finding(f"{prefix}_FOREIGN_CREDITOR_BIC", "Przelew do zagranicznego banku wymaga BIC banku odbiorcy.", _first_node(bic, agent, tx), category="profile", source=foreign_source))
                if foreign_bank or currency_transfer:
                    charge, charge_node = _charge(group, tx, adapter)
                    allowed = {"SHAR", "DEBT", "CRED"} if foreign_bank and not swiftnet else {"SHAR", "SLEV", "DEBT", "CRED"}
                    if charge not in allowed:
                        findings.append(Finding(f"{prefix}_FOREIGN_CHARGE", f"Dozwolone ChrgBr dla tego przelewu: {', '.join(sorted(allowed))}.", _first_node(charge_node, tx), category="profile", source=foreign_source if foreign_bank else None))
                elif swiftnet and amount.currency == "PLN":
                    creditor, creditor_node, creditor_kind = _account(tx, adapter, "CdtrAcct")
                    if creditor_kind != "IBAN" or not _valid_polish_account(creditor):
                        findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_IBAN", "Krajowy SWIFTNET wymaga polskiego IBAN odbiorcy.", _first_node(creditor_node, tx), category="profile", source=rule_source(profile_id, "PDF §3, poz. 1–3", product="domestic")))
            if split:
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_SPLIT_CURRENCY", "Płatność podzielona mBank wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
                creditor, creditor_node, creditor_kind = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(debtor) or (swiftnet and debtor_kind != "IBAN"):
                    findings.append(Finding(f"{prefix}_SPLIT_DEBTOR_ACCOUNT", "Split payment wymaga poprawnego polskiego rachunku rozliczeniowego dłużnika.", debtor_node if debtor_node is not None else group, category="profile"))
                if not _valid_polish_account(creditor) or (swiftnet and creditor_kind != "IBAN"):
                    findings.append(Finding(f"{prefix}_SPLIT_CREDITOR_ACCOUNT", "Split payment wymaga poprawnego polskiego rachunku rozliczeniowego odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                match = re.fullmatch(r"/VAT/(\d{1,10},\d{2})/IDC/(.{1,14})/INV/(.{1,35}?)(?:/TXT/(.{0,33}))?", remittance)
                if match is None:
                    findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Opis split payment musi mieć układ /VAT/10n,2n/IDC/14x/INV/35x[/TXT/33x].", remittance_node if remittance_node is not None else tx, category="profile"))
                elif amount.value is not None:
                    vat = Decimal(match.group(1).replace(",", "."))
                    if vat <= 0 or vat > amount.value:
                        findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "Kwota /VAT/ musi być dodatnia i nie większa od InstdAmt.", remittance_node, category="profile"))
                    elif match.group(3) in ({"PRZEKAZANIE WLASNE", "OWN TRANSFER"} if swiftnet else {"PRZEKAZANIE WLASNE"}) and vat != amount.value:
                        findings.append(Finding(f"{prefix}_SPLIT_OWN_TRANSFER_AMOUNT", "Przy przekazaniu własnym kwota przelewu musi być równa kwocie /VAT/.", remittance_node, category="profile", source=rule_source(profile_id, "PDF tabela Split Payment, /VAT/ i /INV/", product="split_own_transfer")))
            if purpose == "TAXS":
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_TAX_CURRENCY", "Przelew podatkowy mBank wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                _required(findings, tx, adapter, "Tax/Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                _required(findings, tx, adapter, "Tax/Rcrd/Tp", f"{prefix}_TAX_PERIOD", "Tax/Rcrd/Tp")
                _required(findings, tx, adapter, "Tax/Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            white_list = _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Prtry")
            white_list_pattern = r"/WL!/IDC/\d{10}" if swiftnet else r"/WL!/(?:IDC/[0-9]{10}/)?"
            if white_list and white_list.startswith("/WL!") and not re.fullmatch(white_list_pattern, white_list):
                node = _node(tx, adapter, "PmtTpInf/LclInstrm/Prtry")
                if node is None:
                    node = _node(group, adapter, "PmtTpInf/LclInstrm/Prtry")
                message = "Biała Lista: /WL!/IDC/1111111111 (10 cyfr)." if swiftnet else "Biała Lista: /WL!/ albo /WL!/IDC/1111111111/ (10 cyfr i końcowy /)."
                findings.append(Finding(f"{prefix}_WHITE_LIST", message, node, category="profile", source=rule_source("mbank-swiftnet-2026" if swiftnet else "mbank-companynet-2026", "Tabela LclInstrm/Prtry — Biała Lista", product="white_list")))
    duplicates = {value for value, count in Counter(value for value, _ in instr).items() if count > 1}
    for value, node in instr:
        if value in duplicates:
            findings.append(Finding(f"{prefix}_INSTRID_DUPLICATE", f"InstrId powtarza się w pliku: {value}.", node, category="profile"))


def _validate_mbank_mail(findings, group, tx, adapter, header):
    source = rule_source("mbank-companynet-2026", "PDF s. 31–32 §6.8", product="MAIL")
    start = len(findings)
    if header is not None:
        _required(findings, header, adapter, "InitgPty/Nm", "MBANK_COMPANYNET_MAIL_INITIATING_NAME", "InitgPty/Nm")
    _required(findings, group, adapter, "DbtrAcct/Id/IBAN", "MBANK_COMPANYNET_MAIL_DEBTOR_IBAN", "DbtrAcct/Id/IBAN")
    clearing = _required(findings, group, adapter, "DbtrAgt/FinInstnId/ClrSysMmbId/ClrSysId/Cd", "MBANK_COMPANYNET_MAIL_CLEARING", "ClrSysId/Cd")
    if clearing is not None and clearing.text != "PLKNR":
        findings.append(Finding("MBANK_COMPANYNET_MAIL_CLEARING", "MAIL wymaga ClrSysId/Cd=PLKNR.", clearing, category="profile"))
    _required(findings, group, adapter, "DbtrAgt/FinInstnId/ClrSysMmbId/MmbId", "MBANK_COMPANYNET_MAIL_MEMBER", "MmbId")
    instruction = _required(findings, tx, adapter, "InstrForDbtrAgt", "MBANK_COMPANYNET_MAIL_ADDRESS", "InstrForDbtrAgt")
    if instruction is not None:
        parts = instruction.text.split("|")
        valid = len(parts) == 6 and parts[0] in {"510", "511"}
        if valid:
            valid = all(len(value) <= limit for value, limit in zip(parts[1:], (35, 7, 7, 6, 26)))
        if not valid:
            findings.append(Finding("MBANK_COMPANYNET_MAIL_ADDRESS", "MAIL: wymagane 6 podpól typ|ulica|dom|lokal|kod|poczta; typ 510/511, limity 35/7/7/6/26.", instruction, category="profile"))
    _required(findings, tx, adapter, "RmtInf/Ustrd", "MBANK_COMPANYNET_MAIL_REMITTANCE", "RmtInf/Ustrd")
    amount = read_amount(tx, adapter)
    if amount.currency != "PLN":
        findings.append(Finding("MBANK_COMPANYNET_MAIL_CURRENCY", "MAIL wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
    for i in range(start, len(findings)):
        item = findings[i]
        findings[i] = Finding(item.rule_id, item.message, item.node, item.severity, item.category, item.raw_message, source)


def _validate_ing_pl(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "ING_PL"
    profile_id = "ing-business-pl-2026"
    amount_source = rule_source(profile_id, "PDF 1.51C, tabela Amt/InstdAmt", product="transfer")
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        _required(findings, group, adapter, "NbOfTxs", f"{prefix}_COUNT", "NbOfTxs")
        debtor_currency = text_at(group, adapter, "DbtrAcct/Ccy")
        debtor_bic_checked = False
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            _require_instructed(findings, tx, amount, prefix, amount_source)
            if amount.value is not None and not (Decimal("0.01") <= amount.value <= Decimal("999999999999999.99")):
                findings.append(Finding(f"{prefix}_AMOUNT_RANGE", "Kwota jest poza zakresem ING Business.", amount.node if amount.node is not None else tx, category="profile"))
            if _is_sepa(group, tx, adapter, ing_pl=True):
                _check_sepa(findings, group, tx, adapter, prefix)
                _required(findings, tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_SEPA_BIC", "BIC banku odbiorcy")
                if not debtor_bic_checked:
                    _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_SEPA_DEBTOR_BIC", "BIC banku dłużnika")
                    debtor_bic_checked = True
            elif amount.currency == "PLN" and debtor_currency in {None, "PLN"} and creditor_bank_country(tx, adapter) in {None, "PL"}:
                debtor, debtor_node, _ = _account(group, adapter, "DbtrAcct")
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(debtor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_DEBTOR_NRB", "Krajowy rachunek dłużnika musi być poprawnym NRB/PL IBAN.", debtor_node if debtor_node is not None else group, category="profile"))
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_NRB", "Krajowy rachunek odbiorcy musi być poprawnym NRB/PL IBAN.", creditor_node if creditor_node is not None else tx, category="profile"))
                bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
                if bic is not None and (bic.text or "").strip():
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_BIC", "Dla przelewu krajowego pole BICFI banku odbiorcy ma być puste.", bic, category="profile"))
                member = _required(findings, tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId", f"{prefix}_DOMESTIC_CLEARING", "MmbId banku odbiorcy")
                if member is not None and not re.fullmatch(r"\d{8}", member.text or ""):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CLEARING", "MmbId dla przelewu krajowego musi mieć 8 cyfr.", member, category="profile"))
            if _is_split(group, tx, adapter):
                purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Prtry") or _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
                if purpose not in {"SPLT", "VATX"}:
                    findings.append(Finding(f"{prefix}_SPLIT_PURPOSE", "Split payment wymaga CtgyPurp SPLT albo VATX.", tx, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")


def _validate_santander(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "SANTANDER_IBIZNES24"
    amount_source = rule_source("santander-ibiznes24-2026", "iBiznes24 Wersja 2, tabele kwot XML .09", product="transfer", latest=True)
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            _check_minimum_cent(findings, tx, read_amount(tx, adapter), prefix, amount_source)
            _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if _is_sepa(group, tx, adapter):
                _check_sepa(findings, group, tx, adapter, prefix)
                _required(findings, tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_SEPA_BIC", "BIC banku odbiorcy")
                if _node(group, adapter, "ChrgBr") is not None:
                    findings.append(Finding(f"{prefix}_SEPA_CHARGE_LEVEL", "Dla SEPA Santander wymaga ChrgBr=SLEV na poziomie transakcji.", _node(group, adapter, "ChrgBr"), category="profile"))
            elif read_amount(tx, adapter).currency == "PLN":
                account, account_node, _ = _account(group, adapter, "DbtrAcct")
                compact = (account or "")[2:] if (account or "").startswith("PL") else account or ""
                if not _valid_polish_account(compact):
                    findings.append(Finding(f"{prefix}_DEBTOR_NRB", "Krajowy plik wymaga poprawnego 26-cyfrowego NRB rachunku dłużnika.", account_node if account_node is not None else group, category="profile"))
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_CREDITOR_NRB", "Krajowy plik wymaga poprawnego NRB rachunku odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                clearing = _required(findings, group, adapter, "DbtrAgt/FinInstnId/ClrSysMmbId/ClrSysId/Cd", f"{prefix}_CLEARING", "ClrSysId/Cd")
                if clearing is not None and clearing.text != "PLKNR":
                    findings.append(Finding(f"{prefix}_CLEARING", "Dla płatności krajowej ClrSysId/Cd musi być PLKNR.", clearing, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")


def _validate_bnp(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "BNP_GOONLINE"
    profile_id = "bnp-goonline-business-2026"
    amount_source = rule_source(profile_id, "PDF XML V2, tabele Amt/InstdAmt", product="transfer")
    remittance_source = rule_source(profile_id, "PDF XML V2 §5.1, s. 20", product="split")
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            _require_instructed(findings, tx, amount, prefix, amount_source)
            _check_minimum_cent(findings, tx, amount, prefix, amount_source)
            sepa = _is_sepa(group, tx, adapter)
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix, {"SLEV", "SHAR"})
            elif amount.currency == "PLN" and amount.value is not None and amount.value > Decimal("9999999999999.99"):
                findings.append(Finding(f"{prefix}_AMOUNT_RANGE", "Kwota przekracza limit GOonline Biznes.", amount.node if amount.node is not None else tx, category="profile"))
            local = _first_node(_node(tx, adapter, "PmtTpInf/LclInstrm"), _node(group, adapter, "PmtTpInf/LclInstrm"))
            if _is_split(group, tx, adapter) or (local is not None and amount.currency == "PLN" and not sepa):
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_SPLIT_CURRENCY", "Split payment BNP jest krajowym produktem w PLN.", amount.node if amount.node is not None else tx, category="profile", source=rule_source("bnp-goonline-business-2026", "PDF XML V2 s. 39", product="split")))
                purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
                if local is not None:
                    code, proprietary = text_at(local, adapter, "Cd"), text_at(local, adapter, "Prtry")
                    if (code and proprietary) or (code is not None and code not in BNP_SPLIT_CODES) or (proprietary is not None and proprietary not in BNP_SPLIT_PROPRIETARY):
                        findings.append(Finding(f"{prefix}_SPLIT_INSTRUMENT", "Opcjonalny LclInstrm: Cd OTHR/VAT53, VAT53, OTHR/VAT58, VAT58 lub OTHR albo Prtry 53/58/VAT53/VAT58; nigdy obie postacie.", local, category="profile", source=rule_source("bnp-goonline-business-2026", "PDF s. 38–39", product="split")))
                if purpose not in {"SPLI", "VATX"}:
                    purpose_node = _first_node(_node(tx, adapter, "PmtTpInf/CtgyPurp/Cd"), _node(group, adapter, "PmtTpInf/CtgyPurp/Cd"))
                    findings.append(Finding(f"{prefix}_SPLIT_PURPOSE", "Split payment wymaga CtgyPurp SPLI albo VATX; TAXS oznacza przelew do urzędu skarbowego.", purpose_node if purpose_node is not None else tx, category="profile", source=rule_source("bnp-goonline-business-2026", "PDF s. 39", product="split")))
                remittance = _node(tx, adapter, "RmtInf/Ustrd")
                ustrd = remittance.text or "" if remittance is not None else ""
                match = re.fullmatch(
                    r"/VAT/[0-9]{1,10}\.[0-9]{2}/IDC/([^/\r\n]{1,14})"
                    r"/INV/((?:(?!/TXT/).){1,35})(?:/TXT/.{0,33})?",
                    ustrd,
                )
                if match is None or not all(value.strip() for value in match.groups()):
                    findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Opis split payment XML V2 wymaga /VAT/10n.2n/IDC/14x/INV/35x z opcjonalnym /TXT/33x.", _first_node(remittance, tx), category="profile", source=remittance_source))
            _check_bnp_v2_address(findings, group, tx, adapter, amount.currency)


_EEA_COUNTRIES = frozenset("AT BE BG HR CY CZ DK EE FI FR DE GR HU IS IE IT LV LI LT LU MT NL NO PL PT RO SK SI ES SE".split())
_EEA_CURRENCIES = frozenset("CHF CZK DKK EUR HUF ISK NOK PLN RON SEK".split())


def _check_bnp_v2_address(findings, group, tx, adapter, currency):
    address = _node(tx, adapter, "Cdtr/PstlAdr")
    country = text_at(address, adapter, "Ctry")
    town = text_at(address, adapter, "TwnNm")
    iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN")
    bic = text_at(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
    recipient_location = country or (iban[:2] if iban else None) or (bic[4:6] if bic else None)
    domestic = currency == "PLN" and not _is_sepa(group, tx, adapter) and (
        recipient_location == "PL" or (not recipient_location and _valid_polish_account(_account(tx, adapter, "CdtrAcct")[0]))
    )
    _, _, iso_countries, _ = reference_data()
    known_outside_eea = recipient_location in iso_countries and recipient_location not in _EEA_COUNTRIES
    required = not domestic and (
        known_outside_eea or (currency is not None and currency not in _EEA_CURRENCIES)
    )
    profile = _manifest("bnp-goonline-business-2026")
    source = rule_source("bnp-goonline-business-2026", "Instrukcja importu 1552121, s. 1–3", product="XML_V2")
    source.update(profile["address_instruction"])
    if (address is not None or required) and not (country and country.strip() and town and town.strip()):
        findings.append(Finding(
            "BNP_GOONLINE_ADDRESS", "W GOonline Biznes XML V2 podany lub wymagany adres odbiorcy musi mieć kod kraju Ctry i miejscowość TwnNm.",
            address if address is not None else tx, category="profile", source=source,
        ))
    for line in adapter.children(address, "AdrLine") if address is not None else ():
        if (line.text or "").strip():
            findings.append(Finding(
                "BNP_GOONLINE_ADDRESS_LINE_IGNORED", "W GOonline Biznes XML V2 tekst z AdrLine nie jest przekazywany. Przenieś potrzebne dane do pól adresu ustrukturyzowanego.",
                line, severity="warning", category="profile", source=source | {"kind": "bank_data_transformation"},
            ))


def _citi_variant(group: etree._Element, tx: etree._Element, adapter: Adapter) -> str:
    instrument = _local_instrument(group, tx, adapter)
    explicit = {"CITI555": "555_PL_ACH", "CITI574": "574_PL_WIRE", "CITI592": "592_PL_TAX", "CITI795": "795_PL_SEPA", "CITI938": "938_PL_SEPA", "CITI984": "984_PL_VAT"}
    if instrument in explicit:
        return explicit[instrument]
    tax = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") == "TAXS" or _node(tx, adapter, "Tax/Dbtr/RegnId") is not None or _node(tx, adapter, "Tax/Rcrd/FrmsCd") is not None
    vat = _is_split(group, tx, adapter) or _node(tx, adapter, "Tax/Cdtr/TaxId") is not None or _node(tx, adapter, "Tax/TtlTaxAmt") is not None
    sepa_variant = "938_PL_SEPA" if _local_instrument(group, tx, adapter) == "SDCL" else "795_PL_SEPA"
    return "984_PL_VAT" if vat else "592_PL_TAX" if tax else sepa_variant if _is_sepa(group, tx, adapter) else "574_PL_WIRE" if read_amount(tx, adapter).currency not in {None, "PLN"} else "555_PL_ACH"


def _validate_citi(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], variants: Counter[str]) -> None:
    prefix = "CITI_PL"
    _check_common(findings, tree, adapter, groups, prefix)
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    _required(findings, header if header is not None else init, adapter, "InitgPty/Nm", f"{prefix}_INITIATING_NAME", "InitgPty/Nm")
    for group in groups:
        account, account_node, kind = _account(group, adapter, "DbtrAcct")
        if kind != "OTHR" or not re.fullmatch(r"\d{10}", account or ""):
            findings.append(Finding(f"{prefix}_DEBTOR_ACCOUNT", "CitiDirect PL wymaga 10-cyfrowego identyfikatora rachunku dłużnika w Othr/Id.", account_node if account_node is not None else group, category="profile"))
        bic = _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BIC banku dłużnika")
        if bic is not None and not (bic.text or "").startswith("CITIPLPX"):
            findings.append(Finding(f"{prefix}_DEBTOR_BIC", "Dla profilu CitiDirect Polska BIC dłużnika powinien zaczynać się od CITIPLPX.", bic, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            variant = _citi_variant(group, tx, adapter)
            sepa = _is_sepa(group, tx, adapter) or variant in {"795_PL_SEPA", "938_PL_SEPA"}
            tax = (
                variant == "592_PL_TAX"
                or
                _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") == "TAXS"
                or _node(tx, adapter, "Tax/Dbtr/RegnId") is not None
                or _node(tx, adapter, "Tax/Rcrd/FrmsCd") is not None
            )
            vat = (
                variant == "984_PL_VAT"
                or
                _is_split(group, tx, adapter)
                or _node(tx, adapter, "Tax/Cdtr/TaxId") is not None
                or _node(tx, adapter, "Tax/TtlTaxAmt") is not None
            )
            variants[variant] += 1
            _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            _required(findings, tx, adapter, "Cdtr/Nm", f"{prefix}_CREDITOR_NAME", "Cdtr/Nm")
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix)
                if read_amount(tx, adapter).value is not None and read_amount(tx, adapter).value > Decimal("999999999.99"):
                    findings.append(Finding(f"{prefix}_SEPA_AMOUNT_RANGE", "Kwota SEPA przekracza limit 999 999 999,99 CitiDirect PL.", read_amount(tx, adapter).node, category="profile"))
            if variant == "574_PL_WIRE":
                _, node, ckind = _account(tx, adapter, "CdtrAcct")
                if ckind != "OTHR":
                    findings.append(Finding(f"{prefix}_WIRE_ACCOUNT", "Format Citi PL WIRE wymaga rachunku odbiorcy w Othr/Id.", node if node is not None else tx, category="profile"))
                address = _node(tx, adapter, "Cdtr/PstlAdr")
                if address is not None and not text_at(address, adapter, "Ctry"):
                    findings.append(Finding(f"{prefix}_WIRE_CREDITOR_COUNTRY", "Podany adres odbiorcy Citi WIRE wymaga Ctry.", address, category="profile", source=rule_source("citidirect-pl-2026", "GOLD 574_PL_WIRE!O656", product="574_PL_WIRE")))
            elif variant in {"555_PL_ACH", "592_PL_TAX", "984_PL_VAT"}:
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_NRB", "Krajowa płatność Citi wymaga poprawnego 26-cyfrowego NRB/PL IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
                compact = (creditor or "").removeprefix("PL")
                if member is not None and len(compact) == 26 and (member.text or "") != compact[2:10]:
                    findings.append(Finding(f"{prefix}_DOMESTIC_ROUTING", "MmbId nie odpowiada 8 cyfrom rozliczeniowym rachunku odbiorcy.", member, category="profile"))
            if tax:
                _required(findings, tx, adapter, "Tax/Dbtr/TaxId", f"{prefix}_TAX_DEBTOR_ID", "Tax/Dbtr/TaxId")
                _required(findings, tx, adapter, "Tax/Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                _required(findings, tx, adapter, "Tax/Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            if vat:
                tax_root = _node(tx, adapter, "Tax")
                if tax_root is None:
                    tax_root = _node(tx, adapter, "RmtInf/Strd/TaxRmt")
                if tax_root is None:
                    findings.append(Finding(f"{prefix}_VAT_DETAILS", "Płatność VAT wymaga danych podatkowych Tax albo TaxRmt.", tx, category="profile"))
                else:
                    if not (text_at(tax_root, adapter, "Cdtr/TaxId") or "").strip():
                        findings.append(Finding(f"{prefix}_VAT_TAX_ID", "Płatność VAT wymaga identyfikatora podatkowego odbiorcy.", tax_root, category="profile"))
                    if not (text_at(tax_root, adapter, "TtlTaxAmt") or "").strip():
                        findings.append(Finding(f"{prefix}_VAT_AMOUNT", "Płatność VAT wymaga TtlTaxAmt.", tax_root, category="profile"))
                    _validate_citi_vat_invoice(findings, tx, adapter)


def _validate_citi_vat_invoice(findings, tx, adapter):
    source = rule_source("citidirect-pl-2026", "GOLD 984_PL_ACH!N765:O765, N776:O776, N834:O834", product="984_PL_VAT")
    primary = _node(tx, adapter, "Tax/RefNb")
    alternate = _node(tx, adapter, "RmtInf/Strd/RfrdDocInf/Nb")
    # Presence (not truthiness of stripped value) selects the first preference.
    # A blank/invalid first preference must not silently fall back to the second.
    invoice = primary if primary is not None else alternate
    if invoice is None or not (invoice.text or "").strip():
        findings.append(Finding("CITI_PL_VAT_INVOICE", "VAT wymaga niepustego Tax/RefNb albo RmtInf/Strd/RfrdDocInf/Nb (Tax/RefNb ma pierwszeństwo).", invoice if invoice is not None else tx, category="profile", source=source))
    elif any(token in invoice.text for token in ("/IDP/", "/TXT/")):
        findings.append(Finding("CITI_PL_VAT_INVOICE", "Numer faktury VAT nie może zawierać /IDP/ ani /TXT/.", invoice, category="profile", source=source))
    tax_id = _node(tx, adapter, "Tax/Cdtr/TaxId")
    if tax_id is not None and any(token in (tax_id.text or "") for token in ("/INV/", "/IDP/", "/TXT/")):
        findings.append(Finding("CITI_PL_VAT_TAX_ID", "Identyfikator podatkowy VAT nie może zawierać /INV/, /IDP/ ani /TXT/.", tax_id, category="profile", source=source))


def _pko_type_data(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[etree._Element | None, str | None, str | None, str | None]:
    info = _first_node(_node(tx, adapter, "PmtTpInf"), _node(group, adapter, "PmtTpInf"))
    if info is None:
        return None, None, None, None
    return (
        info,
        text_at(info, adapter, "SvcLvl/Cd"),
        text_at(info, adapter, "SvcLvl/Prtry"),
        text_at(info, adapter, "LclInstrm/Cd"),
    )


def _pko_payment_type(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[str, etree._Element | None]:
    info, code, proprietary, instrument = _pko_type_data(group, tx, adapter)
    if code == "INST" or proprietary == "8" or (code == "SEPA" and instrument == "INST"):
        return "instant_sepa", info
    if code in {"SEPA", "URGP"} or proprietary == "7":
        return "sepa", info
    return {
        "1": "domestic",
        "2": "domestic_express",
        "3": "split",
        "4": "split_express",
        "5": "tax",
        "6": "tax_express",
        "9": "foreign_swift",
        "10": "foreign_auto",
        "11": "foreign_gpi",
    }.get(proprietary, "unspecified"), info


def _valid_pko_tax_period(value: str) -> bool:
    match = re.fullmatch(r"\d{2}([MPRKDJ])(\d{0,4})", value)
    if match is None:
        return False
    period, suffix = match.groups()
    if period == "R":
        return suffix == ""
    if period in {"M", "P", "K"}:
        upper = {"M": 12, "P": 2, "K": 4}[period]
        return len(suffix) == 2 and 1 <= int(suffix) <= upper
    if len(suffix) != 4:
        return False
    first, month = int(suffix[:2]), int(suffix[2:])
    return 1 <= month <= 12 and 1 <= first <= (3 if period == "D" else 31)


def _validate_pko_split(findings: list[Finding], tx: etree._Element, adapter: Adapter) -> None:
    prefix = "PKO_IPKO_PL"
    amount = read_amount(tx, adapter)
    if amount.currency != "PLN":
        findings.append(Finding(f"{prefix}_SPLIT_CURRENCY", "Split Payment iPKO biznes wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
    remittance = _node(tx, adapter, "RmtInf")
    ustrd_nodes = remittance.findall(adapter.q("Ustrd")) if remittance is not None else []
    strd_nodes = remittance.findall(adapter.q("Strd")) if remittance is not None else []
    if len(ustrd_nodes) > 1 or len(strd_nodes) > 1 or (ustrd_nodes and strd_nodes):
        findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE_CHOICE", "Split Payment wymaga jednego tytułu: Ustrd albo Strd, bez łączenia obu wariantów.", remittance if remittance is not None else tx, category="profile"))
        return
    if not ustrd_nodes and not strd_nodes:
        findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Split Payment wymaga tytułu Ustrd albo struktury Strd/TaxRmt.", remittance if remittance is not None else tx, category="profile"))
        return

    if ustrd_nodes:
        raw = ustrd_nodes[0].text or ""
        match = re.fullmatch(r"/VAT/(\d{1,10},\d{2})/IDC/(.{1,14})/INV/(.{1,35}?)(?:/TXT/(.{1,33}))?", raw)
        if match is None:
            findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Tytuł Split Payment musi mieć układ /VAT/10n,2n/IDC/14x/INV/35x[/TXT/33x].", ustrd_nodes[0], category="profile"))
            return
        vat = Decimal(match.group(1).replace(",", "."))
        if vat < Decimal("0.01") or vat > Decimal("9999999999.99") or (amount.value is not None and vat > amount.value):
            findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "Kwota /VAT/ musi mieścić się od 0,01 do 9 999 999 999,99 PLN i nie może przekraczać InstdAmt.", ustrd_nodes[0], category="profile"))
        return

    structured = strd_nodes[0]
    tax_remittance = _node(structured, adapter, "TaxRmt")
    if tax_remittance is None:
        findings.append(Finding(f"{prefix}_SPLIT_TAX_REMITTANCE", "Strukturyzowany Split Payment wymaga sekcji TaxRmt.", structured, category="profile"))
        return
    _required(findings, tax_remittance, adapter, "Cdtr/TaxId", f"{prefix}_SPLIT_TAX_ID", "TaxRmt/Cdtr/TaxId")
    _required(findings, tax_remittance, adapter, "RefNb", f"{prefix}_SPLIT_REFERENCE", "TaxRmt/RefNb")
    vat_node = _required(findings, tax_remittance, adapter, "TtlTaxAmt", f"{prefix}_SPLIT_VAT_AMOUNT", "TaxRmt/TtlTaxAmt")
    if vat_node is not None:
        if vat_node.get("Ccy") != "PLN":
            findings.append(Finding(f"{prefix}_SPLIT_VAT_CURRENCY", "TtlTaxAmt dla Split Payment wymaga waluty PLN.", vat_node, category="profile"))
        try:
            vat = Decimal(vat_node.text or "")
        except InvalidOperation:
            findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "TtlTaxAmt nie jest poprawną kwotą dziesiętną.", vat_node, category="profile"))
        else:
            if vat < Decimal("0.01") or vat > Decimal("9999999999.99") or (amount.value is not None and vat > amount.value):
                findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "TtlTaxAmt musi mieścić się od 0,01 do 9 999 999 999,99 PLN i nie może przekraczać InstdAmt.", vat_node, category="profile"))


def _validate_pko_pl(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], variants: Counter[str]) -> None:
    prefix = "PKO_IPKO_PL"
    amount_source = rule_source("pko-ipko-business-pl-2026", "PDF iPKO PL 1.1, s. 20, Amt/InstdAmt", product="transfer")
    _check_common(findings, tree, adapter, groups, prefix)
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    _required(findings, header if header is not None else init, adapter, "InitgPty/Nm", f"{prefix}_INITIATING_NAME", "InitgPty/Nm")
    transaction_count = sum(len(group.findall(adapter.q("CdtTrfTxInf"))) for group in groups)
    if transaction_count > 5_000:
        findings.append(Finding(f"{prefix}_RECOMMENDED_LIMIT", "PKO Bank Polski zaleca najwyżej 5 000 przelewów w jednym pliku.", tree.getroot(), severity="warning", category="profile"))
    _, _, country_codes, _ = reference_data()

    unsupported = {
        "UltmtDbtr": "Pole UltmtDbtr jest obecnie nieobsługiwane przez iPKO biznes.",
        "UltmtCdtr": "Pole UltmtCdtr jest obecnie nieobsługiwane przez iPKO biznes.",
        "RgltryRptg": "Pole RgltryRptg jest obecnie nieobsługiwane przez iPKO biznes.",
    }
    for tag, message in unsupported.items():
        for node in tree.findall(f".//{adapter.q(tag)}"):
            findings.append(Finding(f"{prefix}_{tag.upper()}_UNSUPPORTED", message, node, category="profile"))

    for group in groups:
        _, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind != "IBAN":
            findings.append(Finding(f"{prefix}_DEBTOR_IBAN", "iPKO biznes wymaga rachunku dłużnika w formacie IBAN.", debtor_node if debtor_node is not None else group, category="profile"))
        _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BICFI banku dłużnika")
        batch = _node(group, adapter, "BtchBookg")
        if batch is not None and batch.text not in {"true", "false"}:
            findings.append(Finding(f"{prefix}_BATCH_BOOKING", "BtchBookg dopuszcza wyłącznie małe wartości true albo false.", batch, category="profile"))
        group_types = [_pko_payment_type(group, tx, adapter)[0] for tx in group.findall(adapter.q("CdtTrfTxInf"))]
        charge_account = _node(group, adapter, "ChrgsAcct")
        foreign_types = {"sepa", "instant_sepa", "foreign_swift", "foreign_auto", "foreign_gpi"}
        if charge_account is not None and group_types and not any(item in foreign_types or item == "unspecified" for item in group_types):
            findings.append(Finding(f"{prefix}_CHARGES_ACCOUNT_SCOPE", "ChrgsAcct dotyczy wyłącznie przelewów zagranicznych.", charge_account, category="profile"))

        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            payment_type, type_info = _pko_payment_type(group, tx, adapter)
            variants[payment_type] += 1
            _, service_code, proprietary, instrument = _pko_type_data(group, tx, adapter)
            if type_info is None:
                findings.append(Finding(f"{prefix}_PAYMENT_TYPE_UNSPECIFIED", "Typ przelewu nie jest podany w XML; iPKO biznes pozwala wybrać go na ekranie importu, więc kontrole zależne od typu są niepełne.", tx, severity="warning", category="profile"))
            else:
                service_node = _first_node(_node(type_info, adapter, "SvcLvl/Cd"), _node(type_info, adapter, "SvcLvl/Prtry"))
                if service_code is not None and service_code not in {"SEPA", "INST", "URGP"}:
                    findings.append(Finding(f"{prefix}_SERVICE_CODE", "SvcLvl/Cd dopuszcza wyłącznie SEPA, INST albo URGP.", service_node, category="profile"))
                if proprietary is not None and proprietary not in {str(value) for value in range(1, 12)}:
                    findings.append(Finding(f"{prefix}_SERVICE_PROPRIETARY", "SvcLvl/Prtry dopuszcza wartości od 1 do 11.", service_node, category="profile"))
                if service_code is None and proprietary is None:
                    findings.append(Finding(f"{prefix}_PAYMENT_TYPE_UNSPECIFIED", "PmtTpInf nie określa typu przelewu; iPKO biznes pozwala wybrać go na ekranie importu.", type_info, severity="warning", category="profile"))
                priority = _node(type_info, adapter, "InstrPrty")
                if priority is not None and priority.text not in {"NORM", "HIGH"}:
                    findings.append(Finding(f"{prefix}_PRIORITY", "InstrPrty dopuszcza wyłącznie NORM albo HIGH.", priority, category="profile"))
                instrument_node = _node(type_info, adapter, "LclInstrm/Cd")
                if instrument_node is not None and (instrument != "INST" or service_code != "SEPA"):
                    findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", "LclInstrm/Cd=INST jest dozwolone wyłącznie razem z SvcLvl/Cd=SEPA.", instrument_node, category="profile"))
                proprietary_instrument = _node(type_info, adapter, "LclInstrm/Prtry")
                if proprietary_instrument is not None:
                    findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", "Dokumentacja iPKO biznes dopuszcza w LclInstrm wyłącznie Cd=INST.", proprietary_instrument, category="profile"))

            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None and len(end.text or "") > 35:
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", "EndToEndId przekracza limit 35 znaków.", end, category="profile"))
            amount = read_amount(tx, adapter)
            _require_instructed(findings, tx, amount, prefix, amount_source)
            minimum = Decimal("100") if amount.currency in {"JPY", "HUF"} else Decimal("1.00")
            if amount.value is not None and amount.value < minimum:
                findings.append(Finding(f"{prefix}_AMOUNT_MINIMUM", f"Minimalna kwota dla {amount.currency or 'waluty'} wynosi {minimum}.", amount.node if amount.node is not None else tx, category="profile"))

            creditor, creditor_node, creditor_kind = _account(tx, adapter, "CdtrAcct")
            domestic = payment_type in {"domestic", "domestic_express", "split", "split_express", "tax", "tax_express"}
            foreign = payment_type in {"sepa", "instant_sepa", "foreign_swift", "foreign_auto", "foreign_gpi"}
            if domestic:
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_DOMESTIC_CURRENCY", "Krajowy przelew iPKO biznes wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                if creditor_kind != "IBAN" or not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_ACCOUNT", "Krajowy przelew iPKO biznes wymaga poprawnego polskiego IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
            if payment_type in {"sepa", "instant_sepa"}:
                if amount.currency != "EUR":
                    findings.append(Finding(f"{prefix}_SEPA_CURRENCY", "SEPA i SEPA Instant wymagają waluty EUR.", amount.node if amount.node is not None else tx, category="profile"))
                if creditor_kind != "IBAN":
                    findings.append(Finding(f"{prefix}_SEPA_CREDITOR_IBAN", "SEPA i SEPA Instant wymagają IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
            if payment_type in {"foreign_swift", "foreign_auto", "foreign_gpi"}:
                bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
                member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
                if bic is None and member is None:
                    findings.append(Finding(f"{prefix}_FOREIGN_CREDITOR_AGENT", "Przelew zagraniczny wymaga BICFI albo MmbId banku odbiorcy.", tx, category="profile"))
                if member is not None and not re.fullmatch(r"\d{9}", member.text or ""):
                    findings.append(Finding(f"{prefix}_FOREIGN_ABA", "MmbId jest kodem ABA/FW i musi zawierać 9 cyfr.", member, category="profile"))

            address = _node(_node(tx, adapter, "Cdtr"), adapter, "PstlAdr")
            if address is None:
                findings.append(Finding(f"{prefix}_CREDITOR_ADDRESS", "iPKO biznes wymaga adresu odbiorcy PstlAdr.", _node(tx, adapter, "Cdtr"), category="profile"))
            else:
                address_lines = address.findall(adapter.q("AdrLine"))
                structured = [child for child in address if isinstance(child.tag, str) and etree.QName(child).localname not in {"AdrLine", "Ctry"}]
                if len(address_lines) > 1 or (address_lines and structured):
                    findings.append(Finding(f"{prefix}_ADDRESS_MIXED", "Adres odbiorcy nie może łączyć AdrLine z polami strukturalnymi; iPKO biznes dopuszcza najwyżej jeden AdrLine.", address, category="profile"))
                if domestic and not address_lines:
                    findings.append(Finding(f"{prefix}_DOMESTIC_ADDRESS_LINE", "Przelew krajowy wymaga adresu odbiorcy w polu AdrLine.", address, category="profile"))
                if foreign:
                    if address_lines:
                        findings.append(Finding(f"{prefix}_FOREIGN_ADDRESS_LINE", "Przelew zagraniczny wymaga adresu strukturalnego, bez AdrLine.", address_lines[0], category="profile"))
                    _required(findings, address, adapter, "TwnNm", f"{prefix}_FOREIGN_ADDRESS_TOWN", "Cdtr/PstlAdr/TwnNm")
                    _required(findings, address, adapter, "Ctry", f"{prefix}_FOREIGN_ADDRESS_COUNTRY", "Cdtr/PstlAdr/Ctry")

            tax_root = _node(tx, adapter, "Tax")
            tax_remittance = _node(tx, adapter, "RmtInf/Strd/TaxRmt")
            if tax_root is not None and payment_type not in {"tax", "tax_express"}:
                findings.append(Finding(f"{prefix}_TAX_TYPE", "Sekcja Tax wymaga typu przelewu 5 albo 6.", tax_root, category="profile"))
            if tax_remittance is not None and payment_type not in {"split", "split_express"}:
                findings.append(Finding(f"{prefix}_SPLIT_TYPE", "Sekcja TaxRmt wymaga typu Split Payment 3 albo 4.", tax_remittance, category="profile"))
            if payment_type in {"split", "split_express"}:
                _validate_pko_split(findings, tx, adapter)
            elif payment_type in {"tax", "tax_express"}:
                tax = _node(tx, adapter, "Tax")
                if tax is None:
                    findings.append(Finding(f"{prefix}_TAX_DETAILS", "Przelew podatkowy wymaga sekcji Tax.", tx, category="profile"))
                else:
                    registration = _required(findings, tax, adapter, "Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                    if registration is not None and not re.fullmatch(r"[NRP123].{1,34}", registration.text or ""):
                        findings.append(Finding(f"{prefix}_TAX_REGISTRATION", "RegnId musi zaczynać się od N, R, P, 1, 2 albo 3 i mieć najwyżej 35 znaków.", registration, category="profile"))
                    period = _required(findings, tax, adapter, "Rcrd/Tp", f"{prefix}_TAX_PERIOD", "Tax/Rcrd/Tp")
                    if period is not None and not _valid_pko_tax_period(period.text or ""):
                        findings.append(Finding(f"{prefix}_TAX_PERIOD", "Okres podatkowy ma niepoprawny format dla M, P, R, K, D albo J.", period, category="profile"))
                    _required(findings, tax, adapter, "Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            else:
                _required(findings, tx, adapter, "RmtInf/Ustrd", f"{prefix}_REMITTANCE", "RmtInf/Ustrd")

            negotiated = _node(tx, adapter, "XchgRateInf/CtrctId")
            if negotiated is not None:
                if negotiated.text not in {"true", "false"}:
                    findings.append(Finding(f"{prefix}_NEGOTIATED", "CtrctId dopuszcza wyłącznie małe wartości true albo false.", negotiated, category="profile"))
                if not foreign and payment_type != "unspecified":
                    findings.append(Finding(f"{prefix}_NEGOTIATED_SCOPE", "CtrctId dotyczy wyłącznie przelewów zagranicznych.", negotiated, category="profile"))

            lei = _node(tx, adapter, "Cdtr/Id/OrgId/LEI")
            if lei is not None and not re.fullmatch(r"[A-Z0-9]{18}[0-9]{2}", lei.text or ""):
                findings.append(Finding(f"{prefix}_CREDITOR_LEI", "LEI odbiorcy musi mieć 18 wielkich znaków alfanumerycznych i 2 cyfry kontrolne.", lei, category="profile"))
            if lei is not None and domestic:
                findings.append(Finding(f"{prefix}_CREDITOR_LEI_SCOPE", "Dokumentacja iPKO biznes przewiduje LEI odbiorcy wyłącznie dla przelewów zagranicznych.", lei, category="profile"))
            email = _node(tx, adapter, "Cdtr/CtctDtls/EmailAdr")
            if email is not None:
                addresses = [value.strip() for value in (email.text or "").split(",") if value.strip()]
                if not addresses or len(addresses) > 5 or any(value.count("@") != 1 or any(char.isspace() for char in value) for value in addresses):
                    findings.append(Finding(f"{prefix}_EMAIL", "Podaj od 1 do 5 adresów e-mail oddzielonych przecinkami.", email, category="profile"))
                contact = _node(tx, adapter, "Cdtr/CtctDtls")
                language = _node(contact, adapter, "EmailPurp")
                if language is None or not (language.text or "").strip():
                    findings.append(Finding(f"{prefix}_EMAIL_PURPOSE", "Tabela pól v1.1 wskazuje EmailPurp jako wymagane przy EmailAdr, ale przykład SEPA je pomija; potwierdź język w banku.", contact, severity="warning", category="profile"))
                elif (language.text or "") not in country_codes:
                    findings.append(Finding(f"{prefix}_EMAIL_PURPOSE", "EmailPurp musi być aktywnym dwuliterowym kodem kraju ISO 3166-1.", language, category="profile"))

            creditor_country = text_at(tx, adapter, "Cdtr/PstlAdr/Ctry")
            if creditor_country in {"AE", "MY", "BH", "MM", "CN"} or amount.currency == "CNY":
                remittance_node = _node(tx, adapter, "RmtInf/Ustrd")
                codes = re.findall(r"/[A-Z0-9]+/", remittance_node.text or "") if remittance_node is not None else []
                if not 1 <= len(codes) <= 3:
                    findings.append(Finding(f"{prefix}_PURPOSE_CODE", "Przelew do AE, MY, BH, MM, CN albo w CNY wymaga w Ustrd od 1 do 3 kodów celu w formacie /KOD/; listę kodów udostępnia bank.", remittance_node if remittance_node is not None else tx, category="profile"))


def _validate_seb_equivalent(findings, group, tx, adapter, amount: Amount, currency_node, prefix, country, profile_id, sepa):
    source = rule_source(profile_id, "MIG 26.4.0.1, s. 20–21 i 47", product="equivalent_amount", current_seb=True)
    equivalent = _node(tx, adapter, "Amt/EqvtAmt")
    assert equivalent is not None
    if country != "SE":
        findings.append(Finding(f"{prefix}_EQUIVALENT_SCOPE", "SEB dopuszcza EqvtAmt dla przelewów z rachunku w Szwecji.", equivalent, category="profile", source=source))
        return

    if amount.currency != "SEK":
        findings.append(Finding(f"{prefix}_EQUIVALENT_SOURCE_CURRENCY", "Kwota źródłowa EqvtAmt musi być w SEK.", _first_node(amount.node, equivalent), category="profile", source=source))
    elif amount.value is not None and amount.value > Decimal("5000000"):
        findings.append(Finding(f"{prefix}_EQUIVALENT_MAXIMUM", "Kwota równoważna nie może przekraczać 5 mln SEK.", _first_node(amount.node, equivalent), category="profile", source=source))
    if currency_node is not None and currency_node.text == "SEK":
        findings.append(Finding(f"{prefix}_EQUIVALENT_TRANSFER_CURRENCY", "EqvtAmt wymaga przeliczenia z SEK na walutę przelewu.", currency_node, category="profile", source=source))
    batch = _node(group, adapter, "BtchBookg")
    if batch is None or (batch.text or "").strip() not in {"false", "0"}:
        findings.append(Finding(f"{prefix}_EQUIVALENT_BATCH_BOOKING", "EqvtAmt wymaga BtchBookg=false.", _first_node(batch, equivalent), category="profile", source=source))
    for structured in find_every(tx, f"{adapter.q('RmtInf')}/{adapter.q('Strd')}"):
        if not sepa or _node(structured, adapter, "RfrdDocAmt") is not None:
            findings.append(Finding(f"{prefix}_EQUIVALENT_REMITTANCE", "Przy EqvtAmt opis strukturyzowany jest dozwolony tylko dla SEPA i bez RfrdDocAmt.", structured, category="profile", source=source))


def _validate_seb_money_order(findings, group, tx, adapter, amount: Amount, expected, prefix, country, profile_id):
    source = rule_source(profile_id, "MIG 26.4.0.1, PmtMtd, §4 ChequeInstruction i krajowy Money Order", product="money_order", current_seb=True)
    cheque_type = _node(tx, adapter, "ChqInstr/ChqTp")
    if cheque_type is None or cheque_type.text != "BCHQ" or _local_instrument(group, tx, adapter) == "IN":
        findings.append(Finding(f"{prefix}_MONEY_ORDER_TYPE", "Krajowy Money Order wymaga ChqInstr/ChqTp=BCHQ. SEB nie obsługuje czeków międzynarodowych.", _first_node(cheque_type, tx), category="profile", source=source))
    address = _node(tx, adapter, "Cdtr/PstlAdr")
    town = text_at(address, adapter, "TwnNm")
    address_country = text_at(address, adapter, "Ctry")
    if not (town or "").strip() or address_country not in {None, country}:
        findings.append(Finding(f"{prefix}_MONEY_ORDER_ADDRESS", f"Money Order wymaga adresu odbiorcy z miejscowością na terenie {country}.", _first_node(address, tx), category="profile", source=source))
    if amount.kind != "instructed" or amount.currency != expected:
        findings.append(Finding(f"{prefix}_MONEY_ORDER_CURRENCY", f"Money Order wymaga InstdAmt w walucie {expected}.", _first_node(amount.node, tx), category="profile", source=source))


def _validate_seb(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], country: str) -> None:
    prefix = f"SEB_{country}"
    profile_id = {"NO": "seb-norway-2026", "DK": "seb-denmark-2026", "SE": "seb-sweden-2026"}[country]
    reference_source = rule_source(profile_id, "MIG 26.4.0.1, s. 20 i 79, wzorce krajowe", product="end_to_end_reference", current_seb=True)
    expected = {"NO": "NOK", "DK": "DKK", "SE": "SEK"}[country]
    money_orders = country in {"NO", "SE"}
    _check_common(findings, tree, adapter, groups, prefix, money_orders=money_orders)
    leaves = [node for node in tree.iter() if isinstance(node.tag, str) and len(node) == 0 and not (node.text or "").strip()]
    for node in leaves:
        findings.append(Finding(f"{prefix}_EMPTY_ELEMENT", "SEB nie przyjmuje pustych elementów XML.", node, category="profile"))
    ids: list[tuple[str, etree._Element]] = []
    if sum(len(group.findall(adapter.q("CdtTrfTxInf"))) for group in groups) > 50_000:
        findings.append(Finding(f"{prefix}_TRANSACTION_LIMIT", "Plik przekracza limit 50 000 transakcji SEB.", tree.getroot(), category="profile"))
    for group in groups:
        money_order = money_orders and text_at(group, adapter, "PmtMtd") == "CHK"
        debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind == "IBAN" and debtor and not debtor.startswith(country):
            findings.append(Finding(f"{prefix}_DEBTOR_COUNTRY", f"Profil SEB {country} wymaga rachunku dłużnika z prefiksem {country}.", debtor_node, category="profile"))
        if country == "SE" and (bban_finding := validate_swedish_bban(group, None, adapter)) is not None:
            findings.append(bban_finding)
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None:
                ids.append((end.text or "", end))
                if not re.fullmatch(r"[A-Za-z0-9-]{1,35}", end.text or ""):
                    findings.append(Finding(f"{prefix}_ENDTOEND_FORMAT", "Dla EndToEndId zweryfikowano do 35 znaków: litery ASCII, cyfry i myślnik.", end, category="profile", source=reference_source))
            tx_type = _node(tx, adapter, "PmtTpInf")
            if tx_type is not None and text_at(tx, adapter, "PmtTpInf/SvcLvl/Cd") != "SEPA":
                findings.append(Finding(f"{prefix}_TYPE_LEVEL", "SEB wymaga PmtTpInf na poziomie grupy; w transakcji dopuszcza tylko oznaczenie SvcLvl=SEPA.", tx_type, category="profile"))
            amount = read_amount(tx, adapter)
            sepa = _is_sepa(group, tx, adapter)
            if money_order:
                _validate_seb_money_order(findings, group, tx, adapter, amount, expected, prefix, country, profile_id)
            equivalent_currency = None
            if amount.kind == "equivalent":
                equivalent_currency = _node(tx, adapter, "Amt/EqvtAmt/CcyOfTrf")
                _validate_seb_equivalent(findings, group, tx, adapter, amount, equivalent_currency, prefix, country, profile_id, sepa)
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix, equivalent_currency=equivalent_currency)
            instrument = _local_instrument(group, tx, adapter)
            if country == "DK" and instrument and instrument not in {"SDCL", "INST", "IBK01", "IBK04", "IBK15", "IBK71", "IBK73", "IBK75"}:
                findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", f"Nieobsługiwany duński LclInstrm: {instrument}.", tx, category="profile"))
            if not money_order and amount.kind == "instructed" and amount.currency != expected and seb_domestic(group, tx, adapter, country):
                findings.append(Finding(f"{prefix}_DOMESTIC_CURRENCY", f"Krajowa płatność SEB {country} wymaga waluty {expected}.", _first_node(amount.node, tx), category="profile", source=rule_source(profile_id, "MIG 26.4 PDF s. 86–88; XLSX pain.001.001.09!BC244", product="domestic", current_seb=True)))
            if country == "SE" and (bban_finding := validate_swedish_bban(group, tx, adapter)) is not None:
                findings.append(bban_finding)
            if not money_order:
                _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")
    duplicate = {value for value, count in Counter(value for value, _ in ids).items() if value and count > 1}
    for value, node in ids:
        if value in duplicate:
            findings.append(Finding(f"{prefix}_ENDTOEND_DUPLICATE", f"EndToEndId powtarza się w pliku: {value}.", node, category="profile"))


def _inside_sepa(group, tx, adapter):
    service_path = f"{adapter.q('PmtTpInf')}/{adapter.q('SvcLvl')}"
    services = find_every(tx, service_path) or find_every(group, service_path)
    return any(text_at(service, adapter, "Cd") == "SEPA" for service in services)


def _validate_insidebusiness(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], country: str) -> None:
    prefix = f"ING_INSIDE_{country}"
    profile_id = f"ing-insidebusiness-{country.lower()}-2026"
    amount_source = rule_source(profile_id, "OneXML 5.2, PDF s. 8, Amt/InstdAmt", product="transfer", latest=True)
    charge_source = rule_source(profile_id, "OneXML 5.2, PDF s. 7–8, ChrgBr", product="domestic", latest=True)
    address_source = rule_source(profile_id, "OneXML 5.2, PDF s. 4, adres odbiorcy", product="international_or_sepa_outside_eea", latest=True)
    batch_source = rule_source(profile_id, "OneXML 5.2, PDF s. 5, BtchBookg", product="batch", latest=True)
    domestic_currency = {"NO": "NOK", "DK": "DKK", "SE": "SEK", "BE": "EUR", "NL": "EUR"}[country]
    _check_common(findings, tree, adapter, groups, prefix)
    today = date.today()
    for group in groups:
        debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind == "IBAN" and debtor and not debtor.startswith(country):
            findings.append(Finding(f"{prefix}_DEBTOR_COUNTRY", f"Profil manual upload {country} wymaga rachunku dłużnika z prefiksem {country}.", debtor_node, category="profile"))
        _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BICFI banku dłużnika")
        raw_date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        if raw_date:
            try:
                requested = date.fromisoformat(raw_date[:10])
            except ValueError:
                requested = None
            if requested is not None and not (today - timedelta(days=5) <= requested <= today + timedelta(days=370)):
                requested_node = _node(group, adapter, adapter.execution_date_paths[0])
                findings.append(Finding(f"{prefix}_EXECUTION_DATE_RANGE", "ReqdExctnDt musi mieścić się od 5 dni wstecz do 370 dni naprzód.", requested_node if requested_node is not None else group, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            _require_instructed(findings, tx, amount, prefix, amount_source)
            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None and len(end.text or "") > 35:
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", "EndToEndId przekracza limit 35 znaków OneXML.", end, category="profile"))
            group_charge = _node(group, adapter, "ChrgBr")
            tx_charge = _node(tx, adapter, "ChrgBr")
            if group_charge is not None and tx_charge is not None:
                findings.append(Finding(f"{prefix}_CHARGE_LEVEL", "ChrgBr może wystąpić na poziomie grupy albo transakcji, ale nie na obu.", tx_charge, category="profile"))
            sepa = _inside_sepa(group, tx, adapter)
            bank_country = creditor_bank_country(tx, adapter)
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix, {"SLEV", "SHAR"})
            elif bank_country == country and amount.currency == domestic_currency:
                charge, charge_node = _charge(group, tx, adapter)
                if charge is not None and charge not in {"SHAR", "SLEV"}:
                    findings.append(Finding(f"{prefix}_DOMESTIC_CHARGE", "W krajowym przelewie OneXML dozwolone są tylko SHAR i SLEV.", charge_node, category="profile", source=charge_source))
            creditor_bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
            creditor_member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
            if creditor_bic is None and creditor_member is None:
                findings.append(Finding(f"{prefix}_CREDITOR_AGENT", "OneXML wymaga identyfikacji banku odbiorcy przez BICFI albo numer rozliczeniowy MmbId.", tx, category="profile"))
            creditor = _node(tx, adapter, "Cdtr")
            _check_address(findings, creditor, adapter, f"{prefix}_ADDRESS")
            address = _node(creditor, adapter, "PstlAdr")
            recipient_country = text_at(address, adapter, "Ctry") or bank_country
            country_outside_eea = recipient_country is not None and recipient_country not in _EEA_COUNTRIES
            # OneXML describes international routing. Currency alone does not
            # establish that a payment between local banks is international.
            international = (bank_country or recipient_country) not in {None, country}
            if (country_outside_eea if sepa else international) and (address is None or not any(value.strip() for value in address.itertext())):
                findings.append(Finding(f"{prefix}_CREDITOR_ADDRESS_REQUIRED", "Ten produkt OneXML wymaga adresu odbiorcy.", _first_node(address, creditor, tx), category="profile", source=address_source))
        batch_node = _node(group, adapter, "BtchBookg")
        if batch_node is not None:
            if batch_node.text not in {"true", "false"}:
                findings.append(Finding(f"{prefix}_BATCH_BOOKING", "OneXML dopuszcza BtchBookg wyłącznie w postaci true albo false.", batch_node, category="profile", source=batch_source))
            elif batch_node.text == "true" and (country in {"NO", "DK"} or not all(_inside_sepa(group, tx, adapter) for tx in adapter.children(group, "CdtTrfTxInf"))):
                message = f"BtchBookg=true nie jest wspierane dla {country}." if country in {"NO", "DK"} else "BtchBookg=true jest wspierane tu wyłącznie dla SEPA."
                findings.append(Finding(f"{prefix}_BATCH_BOOKING", message, batch_node, category="profile", source=batch_source))


def validate_bank_profile(
    tree: etree._ElementTree,
    adapter: Adapter,
    groups: list[etree._Element],
    transactions: list[etree._Element],
    profile_id: str,
) -> tuple[list[Finding], dict[str, object]]:
    manifest = _manifest(profile_id)
    supported = set(manifest["message_identifiers"])
    scope: dict[str, object] = {
        "profile_id": profile_id,
        "assessed": 0,
        "not_applicable": 0,
        "total": len(transactions),
        "bundle_id": profile_bundle()["bundle_id"],
        "document_version": manifest["document_version"],
        "source_sha256": manifest["source_sha256"],
        "coverage": "static_file_validation",
        "external_checks_not_performed": profile_bundle()["external_checks_not_performed"],
    }
    for key in ("source_examples_sha256", "scope_notice", "latest_published_source", "address_instruction"):
        if manifest.get(key):
            scope[key] = manifest[key]
    if adapter.message_identifier not in supported:
        return [Finding(
            "PROFILE_VERSION_UNSUPPORTED",
            f"Profil {manifest['name']} obsługuje {', '.join(sorted(supported))}, a dokument ma wersję {adapter.message_identifier}.",
            tree.getroot(),
            category="profile",
        )], scope

    effective_from = manifest.get("effective_from")
    findings: list[Finding] = []
    if effective_from and date.today() < date.fromisoformat(str(effective_from)):
        findings.append(Finding(
            "PROFILE_SOURCE_NOT_YET_EFFECTIVE",
            f"Dokumentacja profilu zaczyna obowiązywać {effective_from}; wynik przed tą datą ma charakter przygotowawczy.",
            tree.getroot(),
            severity="warning",
            category="profile",
        ))

    scope["assessed"] = len(transactions)
    if profile_id == "mbank-companynet-2026":
        _validate_mbank(findings, tree, adapter, groups, False)
    elif profile_id == "mbank-swiftnet-2026":
        _validate_mbank(findings, tree, adapter, groups, True)
    elif profile_id == "ing-business-pl-2026":
        _validate_ing_pl(findings, tree, adapter, groups)
    elif profile_id == "santander-ibiznes24-2026":
        _validate_santander(findings, tree, adapter, groups)
    elif profile_id == "bnp-goonline-business-2026":
        _validate_bnp(findings, tree, adapter, groups)
    elif profile_id == "citidirect-pl-2026":
        variants: Counter[str] = Counter()
        _validate_citi(findings, tree, adapter, groups, variants)
        scope["variants"] = dict(sorted(variants.items()))
    elif profile_id == "pko-ipko-business-pl-2026":
        variants = Counter()
        _validate_pko_pl(findings, tree, adapter, groups, variants)
        scope["variants"] = dict(sorted(variants.items()))
    elif profile_id.startswith("seb-"):
        country = {"seb-norway-2026": "NO", "seb-denmark-2026": "DK", "seb-sweden-2026": "SE"}[profile_id]
        _validate_seb(findings, tree, adapter, groups, country)
    elif profile_id.startswith("ing-insidebusiness-"):
        country = profile_id.removeprefix("ing-insidebusiness-").removesuffix("-2026").upper()
        _validate_insidebusiness(findings, tree, adapter, groups, country)
    else:  # pragma: no cover - guarded by profile_ids()
        raise ValueError(f"Nieznany profil bankowy: {profile_id}")
    from .bank_lengths import bank_length_constraints, length_source, validate_bank_lengths
    from .bank_charsets import validate_bank_charsets
    from .bank_references import validate_seb_references

    scope["text_length_audit"] = length_source(profile_id)
    findings.extend(validate_bank_charsets(tree, adapter, groups, profile_id))
    if profile_id.startswith("seb-"):
        findings.extend(validate_seb_references(adapter, groups, profile_id))
        scope["audited_rule_sources"] = profile_bundle()["audited_seb_rule_groups"]
        scope["scope_notice"] = "Baza MIG 26.1.0.3. Reguły wskazane w audited_rule_sources pochodzą z 26.4.0.1. Algorytm KID i tryb długości OCR zależą od umowy."
    if profile_id == "citidirect-pl-2026":
        scope["scope_notice"] += " Zestawy CharSet potwierdzono dla 555/574/592/984. GOLD nie wskazuje zestawu dla 795/938. Liczby linii N/O wymagają interpretacji Citi."
    existing = {(item.rule_id, item.node) for item in findings}
    findings.extend(item for item in validate_bank_lengths(bank_length_constraints(tree, adapter, profile_id), adapter.namespace) if (item.rule_id, item.node) not in existing)
    return findings, scope
