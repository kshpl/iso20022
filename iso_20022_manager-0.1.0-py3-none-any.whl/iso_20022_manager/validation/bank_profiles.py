from __future__ import annotations

import json
import re
from collections import Counter
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from functools import lru_cache
from importlib.resources import files

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at
from iso_20022_manager.core.totals import read_amount

from .code_sets import reference_data
from .findings import Finding


BANK_PROFILE_PREFIXES = ("mbank-", "ing-", "santander-", "bnp-", "citidirect-", "pko-", "seb-")
LATIN_BASIC = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/-?:().,'+ ")
SWIFTNET_BASIC = LATIN_BASIC | set("{}")
NORDIC = LATIN_BASIC | set("åäæöøÅÄÆÖØ")
POLISH = LATIN_BASIC | set("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ_")
PKO_POLISH = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/ -().,ąćęłńóśźżĄĆĘŁŃÓŚŹŻ")
TEXT_TAGS = {
    "Id", "InstrId", "EndToEndId", "Nm", "StrtNm", "BldgNb", "BldgNm", "Flr", "Room",
    "PstCd", "TwnNm", "TwnLctnNm", "DstrctNm", "CtrySubDvsn", "AdrLine", "Ustrd",
    "AddtlRmtInf", "Ref", "TaxId", "RegnId", "Nb", "PmtInfId", "MsgId",
}


@lru_cache(maxsize=1)
def profile_bundle() -> dict[str, object]:
    path = files("iso_20022_manager").joinpath("resources", "profiles", "bank-profiles.json")
    return json.loads(path.read_text(encoding="utf-8"))


def profile_catalog() -> list[dict[str, object]]:
    return list(profile_bundle()["profiles"])


def profile_ids() -> set[str]:
    return {str(profile["profile_id"]) for profile in profile_catalog()}


def _manifest(profile_id: str) -> dict[str, object]:
    return next(profile for profile in profile_catalog() if profile["profile_id"] == profile_id)


def _node(parent: etree._Element | None, adapter: Adapter, path: str) -> etree._Element | None:
    if parent is None:
        return None
    return parent.find("/".join(adapter.q(part) for part in path.split("/")))


def _effective(group: etree._Element, tx: etree._Element, adapter: Adapter, path: str) -> str | None:
    return text_at(tx, adapter, path) or text_at(group, adapter, path)


def _first_node(*nodes: etree._Element | None) -> etree._Element | None:
    return next((node for node in nodes if node is not None), None)


def _required(findings: list[Finding], parent: etree._Element, adapter: Adapter, path: str, rule: str, label: str) -> etree._Element | None:
    node = _node(parent, adapter, path)
    if node is None or not (node.text or "").strip():
        findings.append(Finding(rule, f"Profil bankowy wymaga pola {label} ({path}).", node if node is not None else parent, category="profile"))
        return None
    return node


def _account(parent: etree._Element, adapter: Adapter, prefix: str) -> tuple[str | None, etree._Element | None, str | None]:
    iban = _node(parent, adapter, f"{prefix}/Id/IBAN")
    other = _node(parent, adapter, f"{prefix}/Id/Othr/Id")
    node = iban if iban is not None else other
    return ((node.text or "").replace(" ", "") if node is not None else None, node, "IBAN" if iban is not None else "OTHR" if other is not None else None)


def _service(group: etree._Element, tx: etree._Element, adapter: Adapter) -> str | None:
    return _effective(group, tx, adapter, "PmtTpInf/SvcLvl/Cd")


def _local_instrument(group: etree._Element, tx: etree._Element, adapter: Adapter) -> str | None:
    return _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Cd") or _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Prtry")


def _charge(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[str | None, etree._Element | None]:
    tx_node = _node(tx, adapter, "ChrgBr")
    group_node = _node(group, adapter, "ChrgBr")
    node = tx_node if tx_node is not None else group_node
    return (node.text if node is not None else None, node)


def _is_sepa(group: etree._Element, tx: etree._Element, adapter: Adapter, *, ing_pl: bool = False) -> bool:
    service = _service(group, tx, adapter)
    return service == "SEPA" or (ing_pl and service == "URGP" and read_amount(tx, adapter).currency == "EUR")


def _is_split(group: etree._Element, tx: etree._Element, adapter: Adapter) -> bool:
    purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") or _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Prtry")
    instrument = _local_instrument(group, tx, adapter) or ""
    return purpose in {"VATX", "SPLI", "SPLT"} or "VAT" in instrument or _node(tx, adapter, "RmtInf/Strd/TaxRmt") is not None


def _check_text_charset(findings: list[Finding], root: etree._Element, allowed: set[str], rule: str, label: str) -> None:
    for node in root.iter():
        if not isinstance(node.tag, str) or len(node) or etree.QName(node).localname not in TEXT_TAGS or not node.text:
            continue
        invalid = sorted(set(node.text) - allowed)
        if invalid:
            shown = " ".join(repr(char) for char in invalid[:8])
            findings.append(Finding(rule, f"{label}: pole zawiera niedozwolone znaki: {shown}.", node, category="profile"))


def _check_address(findings: list[Finding], party: etree._Element | None, adapter: Adapter, rule: str) -> None:
    address = _node(party, adapter, "PstlAdr")
    if address is None or len(address) == 0:
        return
    if _node(address, adapter, "Ctry") is None:
        findings.append(Finding(rule, "Adres pocztowy wymaga kodu kraju Ctry.", address, category="profile"))
    structured = any(_node(address, adapter, name) is not None for name in ("StrtNm", "BldgNb", "TwnNm"))
    if structured and _node(address, adapter, "TwnNm") is None:
        findings.append(Finding(rule, "Adres strukturalny lub hybrydowy wymaga TwnNm.", address, category="profile"))


def _valid_polish_account(value: str | None) -> bool:
    compact = (value or "").replace(" ", "").upper()
    if compact.startswith("PL"):
        compact = compact[2:]
    if not re.fullmatch(r"\d{26}", compact):
        return False
    rearranged = compact[2:] + "2521" + compact[:2]
    remainder = 0
    for digit in rearranged:
        remainder = (remainder * 10 + int(digit)) % 97
    return remainder == 1


def _check_sepa(findings: list[Finding], group: etree._Element, tx: etree._Element, adapter: Adapter, prefix: str, charge_values: set[str] = frozenset({"SLEV"})) -> None:
    amount = read_amount(tx, adapter)
    account, account_node, kind = _account(tx, adapter, "CdtrAcct")
    if amount.currency != "EUR":
        findings.append(Finding(f"{prefix}_SEPA_CURRENCY", "Przelew SEPA wymaga waluty EUR.", amount.node if amount.node is not None else tx, category="profile"))
    if kind != "IBAN":
        findings.append(Finding(f"{prefix}_SEPA_CREDITOR_IBAN", "Przelew SEPA wymaga rachunku odbiorcy w formacie IBAN.", account_node if account_node is not None else tx, category="profile"))
    charge, charge_node = _charge(group, tx, adapter)
    if charge not in charge_values:
        findings.append(Finding(f"{prefix}_SEPA_CHARGE", f"Dla SEPA ChrgBr musi mieć wartość: {', '.join(sorted(charge_values))}.", charge_node if charge_node is not None else tx, category="profile"))


def _check_common(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], prefix: str) -> None:
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    if header is not None:
        _required(findings, header, adapter, "MsgId", f"{prefix}_MSG_ID", "MsgId")
    for group in groups:
        method = _required(findings, group, adapter, "PmtMtd", f"{prefix}_PAYMENT_METHOD", "PmtMtd")
        if method is not None and method.text != "TRF":
            findings.append(Finding(f"{prefix}_PAYMENT_METHOD", "Kanał przyjmuje PmtMtd=TRF.", method, category="profile"))
        _required(findings, group, adapter, "PmtInfId", f"{prefix}_PMTINF_ID", "PmtInfId")
        if not any(text_at(group, adapter, path) for path in adapter.execution_date_paths):
            findings.append(Finding(f"{prefix}_EXECUTION_DATE", "Profil wymaga żądanej daty realizacji ReqdExctnDt.", group, category="profile"))
        _required(findings, group, adapter, "Dbtr/Nm", f"{prefix}_DEBTOR_NAME", "Dbtr/Nm")
        debtor_account, _, _ = _account(group, adapter, "DbtrAcct")
        if not debtor_account:
            findings.append(Finding(f"{prefix}_DEBTOR_ACCOUNT", "Profil wymaga rachunku dłużnika DbtrAcct.", group, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            _required(findings, tx, adapter, "Cdtr/Nm", f"{prefix}_CREDITOR_NAME", "Cdtr/Nm")
            creditor_account, _, _ = _account(tx, adapter, "CdtrAcct")
            if not creditor_account:
                findings.append(Finding(f"{prefix}_CREDITOR_ACCOUNT", "Profil wymaga rachunku odbiorcy CdtrAcct.", tx, category="profile"))


def _validate_mbank(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], swiftnet: bool) -> None:
    prefix = "MBANK_SWIFTNET" if swiftnet else "MBANK_COMPANYNET"
    _check_common(findings, tree, adapter, groups, prefix)
    header = _node(_node(tree.getroot(), adapter, "CstmrCdtTrfInitn"), adapter, "GrpHdr")
    msg_id = _node(header, adapter, "MsgId")
    if swiftnet and msg_id is not None and re.search(r"\s", msg_id.text or ""):
        findings.append(Finding(f"{prefix}_MSG_ID_SPACE", "MsgId dla SWIFTNET nie może zawierać spacji.", msg_id, category="profile"))
    if swiftnet:
        init_id = _node(header, adapter, f"InitgPty/Id/OrgId/{'AnyBIC' if adapter.message_identifier.endswith('.09') else 'BICOrBEI'}")
        if init_id is None:
            findings.append(Finding(f"{prefix}_INITIATING_BIC", "SWIFTNET wymaga identyfikatora BIC strony inicjującej.", header, category="profile"))
        _check_text_charset(findings, tree.getroot(), SWIFTNET_BASIC, f"{prefix}_CHARSET", "Zestaw znaków mBank SWIFTNET")
    else:
        forbidden = set(":*;‘“!+?|#")
        for node in tree.iter():
            if isinstance(node.tag, str) and etree.QName(node).localname in TEXT_TAGS and node.text and set(node.text) & forbidden:
                findings.append(Finding(f"{prefix}_FORBIDDEN_CHAR", "Pole zawiera znak zabroniony przez CompanyNet.", node, category="profile"))
    instr: list[tuple[str, etree._Element]] = []
    for group in groups:
        _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BIC banku dłużnika")
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            end = _node(tx, adapter, "PmtId/EndToEndId")
            if end is None or (not swiftnet and (end.text or "") == "") or (swiftnet and not (end.text or "").strip()):
                findings.append(Finding(f"{prefix}_ENDTOEND", "Profil bankowy wymaga pola EndToEndId.", end if end is not None else tx, category="profile"))
            sepa = _is_sepa(group, tx, adapter)
            if end is not None and len(end.text or "") > (35 if sepa else 16):
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", f"EndToEndId przekracza limit {'35' if sepa else '16'} znaków.", end, category="profile"))
            ins = _node(tx, adapter, "PmtId/InstrId")
            if ins is not None and ins.text:
                instr.append((ins.text, ins))
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix)
            elif read_amount(tx, adapter).currency not in {None, "PLN"}:
                charge, charge_node = _charge(group, tx, adapter)
                if charge not in {"SHAR", "SLEV", "DEBT", "CRED"}:
                    findings.append(Finding(f"{prefix}_FOREIGN_CHARGE", "Przelew zagraniczny wymaga poprawnego ChrgBr.", charge_node if charge_node is not None else tx, category="profile"))
            purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
            remittance_node = _node(tx, adapter, "RmtInf/Ustrd")
            remittance = remittance_node.text or "" if remittance_node is not None else ""
            split = purpose == "VATX" or remittance.startswith("/VAT/")
            if split:
                amount = read_amount(tx, adapter)
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_SPLIT_CURRENCY", "Płatność podzielona mBank wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
                creditor, creditor_node, creditor_kind = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(debtor) or (swiftnet and debtor_kind != "IBAN"):
                    findings.append(Finding(f"{prefix}_SPLIT_DEBTOR_ACCOUNT", "Split payment wymaga poprawnego polskiego rachunku rozliczeniowego dłużnika.", debtor_node if debtor_node is not None else group, category="profile"))
                if not _valid_polish_account(creditor) or (swiftnet and creditor_kind != "IBAN"):
                    findings.append(Finding(f"{prefix}_SPLIT_CREDITOR_ACCOUNT", "Split payment wymaga poprawnego polskiego rachunku rozliczeniowego odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                match = re.fullmatch(r"/VAT/(\d{1,10},\d{2})/IDC/(.{1,14})/INV/(.{1,35}?)(?:/TXT/(.{0,33}))?", remittance)
                if match is None:
                    findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Opis split payment musi mieć układ /VAT/10n,2n/IDC/14x/INV/35x[/TXT/33x].", remittance_node if remittance_node is not None else tx, category="profile"))
                elif amount.value is not None:
                    vat = Decimal(match.group(1).replace(",", "."))
                    if vat <= 0 or vat > amount.value:
                        findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "Kwota /VAT/ musi być dodatnia i nie większa od InstdAmt.", remittance_node, category="profile"))
            if purpose == "TAXS":
                amount = read_amount(tx, adapter)
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_TAX_CURRENCY", "Przelew podatkowy mBank wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                _required(findings, tx, adapter, "Tax/Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                _required(findings, tx, adapter, "Tax/Rcrd/Tp", f"{prefix}_TAX_PERIOD", "Tax/Rcrd/Tp")
                _required(findings, tx, adapter, "Tax/Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            white_list = _effective(group, tx, adapter, "PmtTpInf/LclInstrm/Prtry")
            if white_list and white_list.startswith("/WL!/") and not re.fullmatch(r"/WL!/IDC/\d{10}", white_list):
                node = _node(tx, adapter, "PmtTpInf/LclInstrm/Prtry")
                if node is None:
                    node = _node(group, adapter, "PmtTpInf/LclInstrm/Prtry")
                findings.append(Finding(f"{prefix}_WHITE_LIST", "Instrukcja Białej Listy musi mieć format /WL!/IDC/ i 10-cyfrowy NIP.", node, category="profile"))
    duplicates = {value for value, count in Counter(value for value, _ in instr).items() if count > 1}
    for value, node in instr:
        if value in duplicates:
            findings.append(Finding(f"{prefix}_INSTRID_DUPLICATE", f"InstrId powtarza się w pliku: {value}.", node, category="profile"))


def _validate_ing_pl(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "ING_PL"
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        _required(findings, group, adapter, "NbOfTxs", f"{prefix}_COUNT", "NbOfTxs")
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            if amount.value is not None and not (Decimal("0.01") <= amount.value <= Decimal("999999999999999.99")):
                findings.append(Finding(f"{prefix}_AMOUNT_RANGE", "Kwota jest poza zakresem ING Business.", amount.node if amount.node is not None else tx, category="profile"))
            if _is_sepa(group, tx, adapter, ing_pl=True):
                _check_sepa(findings, group, tx, adapter, prefix)
                _required(findings, tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_SEPA_BIC", "BIC banku odbiorcy")
            elif amount.currency == "PLN":
                debtor, debtor_node, _ = _account(group, adapter, "DbtrAcct")
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(debtor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_DEBTOR_NRB", "Krajowy rachunek dłużnika musi być poprawnym NRB/PL IBAN.", debtor_node if debtor_node is not None else group, category="profile"))
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_NRB", "Krajowy rachunek odbiorcy musi być poprawnym NRB/PL IBAN.", creditor_node if creditor_node is not None else tx, category="profile"))
                bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
                if bic is not None and (bic.text or "").strip():
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_BIC", "Dla przelewu krajowego pole BICFI banku odbiorcy ma być puste.", bic, category="profile"))
                member = _required(findings, tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId", f"{prefix}_DOMESTIC_CLEARING", "MmbId banku odbiorcy")
                if member is not None and not re.fullmatch(r"\d{8}", member.text or ""):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CLEARING", "MmbId dla przelewu krajowego musi mieć 8 cyfr.", member, category="profile"))
            if _is_split(group, tx, adapter):
                purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Prtry") or _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
                if purpose not in {"SPLT", "VATX"}:
                    findings.append(Finding(f"{prefix}_SPLIT_PURPOSE", "Split payment wymaga CtgyPurp SPLT albo VATX.", tx, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")


def _validate_santander(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "SANTANDER_IBIZNES24"
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if _is_sepa(group, tx, adapter):
                _check_sepa(findings, group, tx, adapter, prefix)
                _required(findings, tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_SEPA_BIC", "BIC banku odbiorcy")
                if _node(group, adapter, "ChrgBr") is not None:
                    findings.append(Finding(f"{prefix}_SEPA_CHARGE_LEVEL", "Dla SEPA Santander wymaga ChrgBr=SLEV na poziomie transakcji.", _node(group, adapter, "ChrgBr"), category="profile"))
            elif read_amount(tx, adapter).currency == "PLN":
                account, account_node, _ = _account(group, adapter, "DbtrAcct")
                compact = (account or "")[2:] if (account or "").startswith("PL") else account or ""
                if not _valid_polish_account(compact):
                    findings.append(Finding(f"{prefix}_DEBTOR_NRB", "Krajowy plik wymaga poprawnego 26-cyfrowego NRB rachunku dłużnika.", account_node if account_node is not None else group, category="profile"))
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_CREDITOR_NRB", "Krajowy plik wymaga poprawnego NRB rachunku odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                clearing = _required(findings, group, adapter, "DbtrAgt/FinInstnId/ClrSysMmbId/ClrSysId/Cd", f"{prefix}_CLEARING", "ClrSysId/Cd")
                if clearing is not None and clearing.text != "PLKNR":
                    findings.append(Finding(f"{prefix}_CLEARING", "Dla płatności krajowej ClrSysId/Cd musi być PLKNR.", clearing, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")


def _validate_bnp(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element]) -> None:
    prefix = "BNP_GOONLINE"
    _check_common(findings, tree, adapter, groups, prefix)
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            amount = read_amount(tx, adapter)
            if _is_sepa(group, tx, adapter):
                _check_sepa(findings, group, tx, adapter, prefix, {"SLEV", "SHAR"})
            elif amount.currency == "PLN" and amount.value is not None and amount.value > Decimal("9999999999999.99"):
                findings.append(Finding(f"{prefix}_AMOUNT_RANGE", "Kwota przekracza limit GOonline Biznes.", amount.node if amount.node is not None else tx, category="profile"))
            elif amount.currency not in {None, "PLN"}:
                _check_text_charset(findings, tx, LATIN_BASIC, f"{prefix}_FOREIGN_CHARSET", "Przelew zagraniczny GOonline")
            if _is_split(group, tx, adapter):
                instrument = _local_instrument(group, tx, adapter)
                purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
                if instrument not in {"OTHR", "VAT53", "VAT58"}:
                    findings.append(Finding(f"{prefix}_SPLIT_INSTRUMENT", "Split payment wymaga LclInstrm OTHR, VAT53 albo VAT58.", tx, category="profile"))
                if purpose not in {"TAXS", "SPLI", "VATX"}:
                    findings.append(Finding(f"{prefix}_SPLIT_PURPOSE", "Split payment wymaga CtgyPurp TAXS, SPLI albo VATX.", tx, category="profile"))
                ustrd = text_at(tx, adapter, "RmtInf/Ustrd") or ""
                if not re.fullmatch(r"/VAT/[^/]+/IDC/[^/]+/INV/[^/]+/TXT/.*", ustrd):
                    remittance = _node(tx, adapter, "RmtInf/Ustrd")
                    findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Opis split payment nie ma wymaganego układu /VAT/.../IDC/.../INV/.../TXT/....", remittance if remittance is not None else tx, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")


def _validate_citi(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], variants: Counter[str]) -> None:
    prefix = "CITI_PL"
    _check_common(findings, tree, adapter, groups, prefix)
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    _required(findings, header if header is not None else init, adapter, "InitgPty/Nm", f"{prefix}_INITIATING_NAME", "InitgPty/Nm")
    for group in groups:
        account, account_node, kind = _account(group, adapter, "DbtrAcct")
        if kind != "OTHR" or not re.fullmatch(r"\d{10}", account or ""):
            findings.append(Finding(f"{prefix}_DEBTOR_ACCOUNT", "CitiDirect PL wymaga 10-cyfrowego identyfikatora rachunku dłużnika w Othr/Id.", account_node if account_node is not None else group, category="profile"))
        bic = _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BIC banku dłużnika")
        if bic is not None and not (bic.text or "").startswith("CITIPLPX"):
            findings.append(Finding(f"{prefix}_DEBTOR_BIC", "Dla profilu CitiDirect Polska BIC dłużnika powinien zaczynać się od CITIPLPX.", bic, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            sepa = _is_sepa(group, tx, adapter)
            tax = (
                _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") == "TAXS"
                or _node(tx, adapter, "Tax/Dbtr/RegnId") is not None
                or _node(tx, adapter, "Tax/Rcrd/FrmsCd") is not None
            )
            vat = (
                _is_split(group, tx, adapter)
                or _node(tx, adapter, "Tax/Cdtr/TaxId") is not None
                or _node(tx, adapter, "Tax/TtlTaxAmt") is not None
            )
            sepa_variant = "938_PL_SEPA" if _local_instrument(group, tx, adapter) == "SDCL" else "795_PL_SEPA"
            variant = "984_PL_VAT" if vat else "592_PL_TAX" if tax else sepa_variant if sepa else "574_PL_WIRE" if read_amount(tx, adapter).currency not in {None, "PLN"} else "555_PL_ACH"
            variants[variant] += 1
            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None and len(end.text or "") > 16:
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", "EndToEndId przekracza limit 16 znaków CitiDirect PL.", end, category="profile"))
            if end is not None and "_" in (end.text or ""):
                findings.append(Finding(f"{prefix}_REFERENCE_UNDERSCORE", "Citi nie dopuszcza podkreślenia w referencji transakcji.", end, category="profile"))
            _required(findings, tx, adapter, "Cdtr/Nm", f"{prefix}_CREDITOR_NAME", "Cdtr/Nm")
            if sepa:
                _check_sepa(findings, group, tx, adapter, prefix)
                if read_amount(tx, adapter).value is not None and read_amount(tx, adapter).value > Decimal("999999999.99"):
                    findings.append(Finding(f"{prefix}_SEPA_AMOUNT_RANGE", "Kwota SEPA przekracza limit 999 999 999,99 CitiDirect PL.", read_amount(tx, adapter).node, category="profile"))
            if variant == "574_PL_WIRE":
                _, node, ckind = _account(tx, adapter, "CdtrAcct")
                if ckind != "OTHR":
                    findings.append(Finding(f"{prefix}_WIRE_ACCOUNT", "Format Citi PL WIRE wymaga rachunku odbiorcy w Othr/Id.", node if node is not None else tx, category="profile"))
                if end is not None and not re.fullmatch(r"[A-Z0-9 /\-?():.,'+]*", end.text or ""):
                    findings.append(Finding(f"{prefix}_WIRE_REFERENCE_CHARSET", "Referencja WIRE dopuszcza wyłącznie wielkie litery i zestaw znaków Citi CBFT.", end, category="profile"))
            elif variant in {"555_PL_ACH", "592_PL_TAX", "984_PL_VAT"}:
                creditor, creditor_node, _ = _account(tx, adapter, "CdtrAcct")
                if not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_NRB", "Krajowa płatność Citi wymaga poprawnego 26-cyfrowego NRB/PL IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
                member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
                compact = (creditor or "").removeprefix("PL")
                if member is not None and len(compact) == 26 and (member.text or "") != compact[2:10]:
                    findings.append(Finding(f"{prefix}_DOMESTIC_ROUTING", "MmbId nie odpowiada 8 cyfrom rozliczeniowym rachunku odbiorcy.", member, category="profile"))
            if tax:
                _required(findings, tx, adapter, "Tax/Dbtr/TaxId", f"{prefix}_TAX_DEBTOR_ID", "Tax/Dbtr/TaxId")
                _required(findings, tx, adapter, "Tax/Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                _required(findings, tx, adapter, "Tax/Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            if vat:
                tax_root = _node(tx, adapter, "Tax")
                if tax_root is None:
                    tax_root = _node(tx, adapter, "RmtInf/Strd/TaxRmt")
                if tax_root is None:
                    findings.append(Finding(f"{prefix}_VAT_DETAILS", "Płatność VAT wymaga danych podatkowych Tax albo TaxRmt.", tx, category="profile"))
                else:
                    if not any(etree.QName(node).localname == "TaxId" and (node.text or "").strip() for node in tax_root.iter() if isinstance(node.tag, str)):
                        findings.append(Finding(f"{prefix}_VAT_TAX_ID", "Płatność VAT wymaga identyfikatora podatkowego odbiorcy.", tax_root, category="profile"))
                    if not any(etree.QName(node).localname == "TtlTaxAmt" and (node.text or "").strip() for node in tax_root.iter() if isinstance(node.tag, str)):
                        findings.append(Finding(f"{prefix}_VAT_AMOUNT", "Płatność VAT wymaga TtlTaxAmt.", tax_root, category="profile"))
                    if not any(etree.QName(node).localname in {"RefNb", "TaxRefNo"} and (node.text or "").strip() for node in tax_root.iter() if isinstance(node.tag, str)):
                        findings.append(Finding(f"{prefix}_VAT_REFERENCE", "Płatność VAT wymaga numeru referencyjnego faktury.", tax_root, category="profile"))
                    if not any(etree.QName(node).localname == "Nb" and (node.text or "").strip() for node in tax_root.iter() if isinstance(node.tag, str)):
                        findings.append(Finding(f"{prefix}_VAT_INVOICE", "Płatność VAT wymaga numeru faktury Nb.", tax_root, category="profile"))
            allowed = LATIN_BASIC if variant in {"574_PL_WIRE", "795_PL_SEPA", "938_PL_SEPA"} else POLISH
            _check_text_charset(findings, tx, allowed, f"{prefix}_CHARSET", "Zestaw znaków Citi PL")


def _pko_type_data(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[etree._Element | None, str | None, str | None, str | None]:
    info = _first_node(_node(tx, adapter, "PmtTpInf"), _node(group, adapter, "PmtTpInf"))
    if info is None:
        return None, None, None, None
    return (
        info,
        text_at(info, adapter, "SvcLvl/Cd"),
        text_at(info, adapter, "SvcLvl/Prtry"),
        text_at(info, adapter, "LclInstrm/Cd"),
    )


def _pko_payment_type(group: etree._Element, tx: etree._Element, adapter: Adapter) -> tuple[str, etree._Element | None]:
    info, code, proprietary, instrument = _pko_type_data(group, tx, adapter)
    if code == "INST" or proprietary == "8" or (code == "SEPA" and instrument == "INST"):
        return "instant_sepa", info
    if code in {"SEPA", "URGP"} or proprietary == "7":
        return "sepa", info
    return {
        "1": "domestic",
        "2": "domestic_express",
        "3": "split",
        "4": "split_express",
        "5": "tax",
        "6": "tax_express",
        "9": "foreign_swift",
        "10": "foreign_auto",
        "11": "foreign_gpi",
    }.get(proprietary, "unspecified"), info


def _valid_pko_tax_period(value: str) -> bool:
    match = re.fullmatch(r"\d{2}([MPRKDJ])(\d{0,4})", value)
    if match is None:
        return False
    period, suffix = match.groups()
    if period == "R":
        return suffix == ""
    if period in {"M", "P", "K"}:
        upper = {"M": 12, "P": 2, "K": 4}[period]
        return len(suffix) == 2 and 1 <= int(suffix) <= upper
    if len(suffix) != 4:
        return False
    first, month = int(suffix[:2]), int(suffix[2:])
    return 1 <= month <= 12 and 1 <= first <= (3 if period == "D" else 31)


def _validate_pko_split(findings: list[Finding], tx: etree._Element, adapter: Adapter) -> None:
    prefix = "PKO_IPKO_PL"
    amount = read_amount(tx, adapter)
    if amount.currency != "PLN":
        findings.append(Finding(f"{prefix}_SPLIT_CURRENCY", "Split Payment iPKO biznes wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
    remittance = _node(tx, adapter, "RmtInf")
    ustrd_nodes = remittance.findall(adapter.q("Ustrd")) if remittance is not None else []
    strd_nodes = remittance.findall(adapter.q("Strd")) if remittance is not None else []
    if len(ustrd_nodes) > 1 or len(strd_nodes) > 1 or (ustrd_nodes and strd_nodes):
        findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE_CHOICE", "Split Payment wymaga jednego tytułu: Ustrd albo Strd, bez łączenia obu wariantów.", remittance if remittance is not None else tx, category="profile"))
        return
    if not ustrd_nodes and not strd_nodes:
        findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Split Payment wymaga tytułu Ustrd albo struktury Strd/TaxRmt.", remittance if remittance is not None else tx, category="profile"))
        return

    if ustrd_nodes:
        raw = ustrd_nodes[0].text or ""
        match = re.fullmatch(r"/VAT/(\d{1,10},\d{2})/IDC/(.{1,14})/INV/(.{1,35}?)(?:/TXT/(.{1,33}))?", raw)
        if match is None:
            findings.append(Finding(f"{prefix}_SPLIT_REMITTANCE", "Tytuł Split Payment musi mieć układ /VAT/10n,2n/IDC/14x/INV/35x[/TXT/33x].", ustrd_nodes[0], category="profile"))
            return
        vat = Decimal(match.group(1).replace(",", "."))
        if vat < Decimal("0.01") or vat > Decimal("9999999999.99") or (amount.value is not None and vat > amount.value):
            findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "Kwota /VAT/ musi mieścić się od 0,01 do 9 999 999 999,99 PLN i nie może przekraczać InstdAmt.", ustrd_nodes[0], category="profile"))
        return

    structured = strd_nodes[0]
    tax_remittance = _node(structured, adapter, "TaxRmt")
    if tax_remittance is None:
        findings.append(Finding(f"{prefix}_SPLIT_TAX_REMITTANCE", "Strukturyzowany Split Payment wymaga sekcji TaxRmt.", structured, category="profile"))
        return
    _required(findings, tax_remittance, adapter, "Cdtr/TaxId", f"{prefix}_SPLIT_TAX_ID", "TaxRmt/Cdtr/TaxId")
    _required(findings, tax_remittance, adapter, "RefNb", f"{prefix}_SPLIT_REFERENCE", "TaxRmt/RefNb")
    vat_node = _required(findings, tax_remittance, adapter, "TtlTaxAmt", f"{prefix}_SPLIT_VAT_AMOUNT", "TaxRmt/TtlTaxAmt")
    if vat_node is not None:
        if vat_node.get("Ccy") != "PLN":
            findings.append(Finding(f"{prefix}_SPLIT_VAT_CURRENCY", "TtlTaxAmt dla Split Payment wymaga waluty PLN.", vat_node, category="profile"))
        try:
            vat = Decimal(vat_node.text or "")
        except InvalidOperation:
            findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "TtlTaxAmt nie jest poprawną kwotą dziesiętną.", vat_node, category="profile"))
        else:
            if vat < Decimal("0.01") or vat > Decimal("9999999999.99") or (amount.value is not None and vat > amount.value):
                findings.append(Finding(f"{prefix}_SPLIT_VAT_AMOUNT", "TtlTaxAmt musi mieścić się od 0,01 do 9 999 999 999,99 PLN i nie może przekraczać InstdAmt.", vat_node, category="profile"))


def _validate_pko_pl(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], variants: Counter[str]) -> None:
    prefix = "PKO_IPKO_PL"
    _check_common(findings, tree, adapter, groups, prefix)
    init = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    header = _node(init, adapter, "GrpHdr")
    _required(findings, header if header is not None else init, adapter, "InitgPty/Nm", f"{prefix}_INITIATING_NAME", "InitgPty/Nm")
    transaction_count = sum(len(group.findall(adapter.q("CdtTrfTxInf"))) for group in groups)
    if transaction_count > 5_000:
        findings.append(Finding(f"{prefix}_RECOMMENDED_LIMIT", "PKO Bank Polski zaleca najwyżej 5 000 przelewów w jednym pliku.", tree.getroot(), severity="warning", category="profile"))
    _check_text_charset(findings, tree.getroot(), PKO_POLISH, f"{prefix}_CHARSET", "Zestaw znaków iPKO biznes")
    _, _, country_codes, _ = reference_data()

    unsupported = {
        "UltmtDbtr": "Pole UltmtDbtr jest obecnie nieobsługiwane przez iPKO biznes.",
        "UltmtCdtr": "Pole UltmtCdtr jest obecnie nieobsługiwane przez iPKO biznes.",
        "RgltryRptg": "Pole RgltryRptg jest obecnie nieobsługiwane przez iPKO biznes.",
    }
    for tag, message in unsupported.items():
        for node in tree.findall(f".//{adapter.q(tag)}"):
            findings.append(Finding(f"{prefix}_{tag.upper()}_UNSUPPORTED", message, node, category="profile"))

    for group in groups:
        _, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind != "IBAN":
            findings.append(Finding(f"{prefix}_DEBTOR_IBAN", "iPKO biznes wymaga rachunku dłużnika w formacie IBAN.", debtor_node if debtor_node is not None else group, category="profile"))
        _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BICFI banku dłużnika")
        batch = _node(group, adapter, "BtchBookg")
        if batch is not None and batch.text not in {"true", "false"}:
            findings.append(Finding(f"{prefix}_BATCH_BOOKING", "BtchBookg dopuszcza wyłącznie małe wartości true albo false.", batch, category="profile"))
        group_types = [_pko_payment_type(group, tx, adapter)[0] for tx in group.findall(adapter.q("CdtTrfTxInf"))]
        charge_account = _node(group, adapter, "ChrgsAcct")
        foreign_types = {"sepa", "instant_sepa", "foreign_swift", "foreign_auto", "foreign_gpi"}
        if charge_account is not None and group_types and not any(item in foreign_types or item == "unspecified" for item in group_types):
            findings.append(Finding(f"{prefix}_CHARGES_ACCOUNT_SCOPE", "ChrgsAcct dotyczy wyłącznie przelewów zagranicznych.", charge_account, category="profile"))

        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            payment_type, type_info = _pko_payment_type(group, tx, adapter)
            variants[payment_type] += 1
            _, service_code, proprietary, instrument = _pko_type_data(group, tx, adapter)
            if type_info is None:
                findings.append(Finding(f"{prefix}_PAYMENT_TYPE_UNSPECIFIED", "Typ przelewu nie jest podany w XML; iPKO biznes pozwala wybrać go na ekranie importu, więc kontrole zależne od typu są niepełne.", tx, severity="warning", category="profile"))
            else:
                service_node = _first_node(_node(type_info, adapter, "SvcLvl/Cd"), _node(type_info, adapter, "SvcLvl/Prtry"))
                if service_code is not None and service_code not in {"SEPA", "INST", "URGP"}:
                    findings.append(Finding(f"{prefix}_SERVICE_CODE", "SvcLvl/Cd dopuszcza wyłącznie SEPA, INST albo URGP.", service_node, category="profile"))
                if proprietary is not None and proprietary not in {str(value) for value in range(1, 12)}:
                    findings.append(Finding(f"{prefix}_SERVICE_PROPRIETARY", "SvcLvl/Prtry dopuszcza wartości od 1 do 11.", service_node, category="profile"))
                if service_code is None and proprietary is None:
                    findings.append(Finding(f"{prefix}_PAYMENT_TYPE_UNSPECIFIED", "PmtTpInf nie określa typu przelewu; iPKO biznes pozwala wybrać go na ekranie importu.", type_info, severity="warning", category="profile"))
                priority = _node(type_info, adapter, "InstrPrty")
                if priority is not None and priority.text not in {"NORM", "HIGH"}:
                    findings.append(Finding(f"{prefix}_PRIORITY", "InstrPrty dopuszcza wyłącznie NORM albo HIGH.", priority, category="profile"))
                instrument_node = _node(type_info, adapter, "LclInstrm/Cd")
                if instrument_node is not None and (instrument != "INST" or service_code != "SEPA"):
                    findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", "LclInstrm/Cd=INST jest dozwolone wyłącznie razem z SvcLvl/Cd=SEPA.", instrument_node, category="profile"))
                proprietary_instrument = _node(type_info, adapter, "LclInstrm/Prtry")
                if proprietary_instrument is not None:
                    findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", "Dokumentacja iPKO biznes dopuszcza w LclInstrm wyłącznie Cd=INST.", proprietary_instrument, category="profile"))

            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None and len(end.text or "") > 35:
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", "EndToEndId przekracza limit 35 znaków.", end, category="profile"))
            amount = read_amount(tx, adapter)
            minimum = Decimal("100") if amount.currency in {"JPY", "HUF"} else Decimal("1.00")
            if amount.value is not None and amount.value < minimum:
                findings.append(Finding(f"{prefix}_AMOUNT_MINIMUM", f"Minimalna kwota dla {amount.currency or 'waluty'} wynosi {minimum}.", amount.node if amount.node is not None else tx, category="profile"))

            creditor, creditor_node, creditor_kind = _account(tx, adapter, "CdtrAcct")
            domestic = payment_type in {"domestic", "domestic_express", "split", "split_express", "tax", "tax_express"}
            foreign = payment_type in {"sepa", "instant_sepa", "foreign_swift", "foreign_auto", "foreign_gpi"}
            if domestic:
                if amount.currency != "PLN":
                    findings.append(Finding(f"{prefix}_DOMESTIC_CURRENCY", "Krajowy przelew iPKO biznes wymaga waluty PLN.", amount.node if amount.node is not None else tx, category="profile"))
                if creditor_kind != "IBAN" or not _valid_polish_account(creditor):
                    findings.append(Finding(f"{prefix}_DOMESTIC_CREDITOR_ACCOUNT", "Krajowy przelew iPKO biznes wymaga poprawnego polskiego IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
            if payment_type in {"sepa", "instant_sepa"}:
                if amount.currency != "EUR":
                    findings.append(Finding(f"{prefix}_SEPA_CURRENCY", "SEPA i SEPA Instant wymagają waluty EUR.", amount.node if amount.node is not None else tx, category="profile"))
                if creditor_kind != "IBAN":
                    findings.append(Finding(f"{prefix}_SEPA_CREDITOR_IBAN", "SEPA i SEPA Instant wymagają IBAN odbiorcy.", creditor_node if creditor_node is not None else tx, category="profile"))
            if payment_type in {"foreign_swift", "foreign_auto", "foreign_gpi"}:
                bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
                member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
                if bic is None and member is None:
                    findings.append(Finding(f"{prefix}_FOREIGN_CREDITOR_AGENT", "Przelew zagraniczny wymaga BICFI albo MmbId banku odbiorcy.", tx, category="profile"))
                if member is not None and not re.fullmatch(r"\d{9}", member.text or ""):
                    findings.append(Finding(f"{prefix}_FOREIGN_ABA", "MmbId jest kodem ABA/FW i musi zawierać 9 cyfr.", member, category="profile"))

            address = _node(_node(tx, adapter, "Cdtr"), adapter, "PstlAdr")
            if address is None:
                findings.append(Finding(f"{prefix}_CREDITOR_ADDRESS", "iPKO biznes wymaga adresu odbiorcy PstlAdr.", _node(tx, adapter, "Cdtr"), category="profile"))
            else:
                address_lines = address.findall(adapter.q("AdrLine"))
                structured = [child for child in address if isinstance(child.tag, str) and etree.QName(child).localname not in {"AdrLine", "Ctry"}]
                if len(address_lines) > 1 or (address_lines and structured):
                    findings.append(Finding(f"{prefix}_ADDRESS_MIXED", "Adres odbiorcy nie może łączyć AdrLine z polami strukturalnymi; iPKO biznes dopuszcza najwyżej jeden AdrLine.", address, category="profile"))
                if domestic and not address_lines:
                    findings.append(Finding(f"{prefix}_DOMESTIC_ADDRESS_LINE", "Przelew krajowy wymaga adresu odbiorcy w polu AdrLine.", address, category="profile"))
                if foreign:
                    if address_lines:
                        findings.append(Finding(f"{prefix}_FOREIGN_ADDRESS_LINE", "Przelew zagraniczny wymaga adresu strukturalnego, bez AdrLine.", address_lines[0], category="profile"))
                    _required(findings, address, adapter, "TwnNm", f"{prefix}_FOREIGN_ADDRESS_TOWN", "Cdtr/PstlAdr/TwnNm")
                    _required(findings, address, adapter, "Ctry", f"{prefix}_FOREIGN_ADDRESS_COUNTRY", "Cdtr/PstlAdr/Ctry")

            tax_root = _node(tx, adapter, "Tax")
            tax_remittance = _node(tx, adapter, "RmtInf/Strd/TaxRmt")
            if tax_root is not None and payment_type not in {"tax", "tax_express"}:
                findings.append(Finding(f"{prefix}_TAX_TYPE", "Sekcja Tax wymaga typu przelewu 5 albo 6.", tax_root, category="profile"))
            if tax_remittance is not None and payment_type not in {"split", "split_express"}:
                findings.append(Finding(f"{prefix}_SPLIT_TYPE", "Sekcja TaxRmt wymaga typu Split Payment 3 albo 4.", tax_remittance, category="profile"))
            if payment_type in {"split", "split_express"}:
                _validate_pko_split(findings, tx, adapter)
            elif payment_type in {"tax", "tax_express"}:
                tax = _node(tx, adapter, "Tax")
                if tax is None:
                    findings.append(Finding(f"{prefix}_TAX_DETAILS", "Przelew podatkowy wymaga sekcji Tax.", tx, category="profile"))
                else:
                    registration = _required(findings, tax, adapter, "Dbtr/RegnId", f"{prefix}_TAX_REGISTRATION", "Tax/Dbtr/RegnId")
                    if registration is not None and not re.fullmatch(r"[NRP123].{1,34}", registration.text or ""):
                        findings.append(Finding(f"{prefix}_TAX_REGISTRATION", "RegnId musi zaczynać się od N, R, P, 1, 2 albo 3 i mieć najwyżej 35 znaków.", registration, category="profile"))
                    period = _required(findings, tax, adapter, "Rcrd/Tp", f"{prefix}_TAX_PERIOD", "Tax/Rcrd/Tp")
                    if period is not None and not _valid_pko_tax_period(period.text or ""):
                        findings.append(Finding(f"{prefix}_TAX_PERIOD", "Okres podatkowy ma niepoprawny format dla M, P, R, K, D albo J.", period, category="profile"))
                    _required(findings, tax, adapter, "Rcrd/FrmsCd", f"{prefix}_TAX_FORM", "Tax/Rcrd/FrmsCd")
            else:
                _required(findings, tx, adapter, "RmtInf/Ustrd", f"{prefix}_REMITTANCE", "RmtInf/Ustrd")

            negotiated = _node(tx, adapter, "XchgRateInf/CtrctId")
            if negotiated is not None:
                if negotiated.text not in {"true", "false"}:
                    findings.append(Finding(f"{prefix}_NEGOTIATED", "CtrctId dopuszcza wyłącznie małe wartości true albo false.", negotiated, category="profile"))
                if not foreign and payment_type != "unspecified":
                    findings.append(Finding(f"{prefix}_NEGOTIATED_SCOPE", "CtrctId dotyczy wyłącznie przelewów zagranicznych.", negotiated, category="profile"))

            lei = _node(tx, adapter, "Cdtr/Id/OrgId/LEI")
            if lei is not None and not re.fullmatch(r"[A-Z0-9]{18}[0-9]{2}", lei.text or ""):
                findings.append(Finding(f"{prefix}_CREDITOR_LEI", "LEI odbiorcy musi mieć 18 wielkich znaków alfanumerycznych i 2 cyfry kontrolne.", lei, category="profile"))
            if lei is not None and domestic:
                findings.append(Finding(f"{prefix}_CREDITOR_LEI_SCOPE", "Dokumentacja iPKO biznes przewiduje LEI odbiorcy wyłącznie dla przelewów zagranicznych.", lei, category="profile"))
            email = _node(tx, adapter, "Cdtr/CtctDtls/EmailAdr")
            if email is not None:
                addresses = [value.strip() for value in (email.text or "").split(",") if value.strip()]
                if not addresses or len(addresses) > 5 or any(value.count("@") != 1 or any(char.isspace() for char in value) for value in addresses):
                    findings.append(Finding(f"{prefix}_EMAIL", "Podaj od 1 do 5 adresów e-mail oddzielonych przecinkami.", email, category="profile"))
                contact = _node(tx, adapter, "Cdtr/CtctDtls")
                language = _node(contact, adapter, "EmailPurp")
                if language is None or not (language.text or "").strip():
                    findings.append(Finding(f"{prefix}_EMAIL_PURPOSE", "Tabela pól v1.1 wskazuje EmailPurp jako wymagane przy EmailAdr, ale przykład SEPA je pomija; potwierdź język w banku.", contact, severity="warning", category="profile"))
                elif (language.text or "") not in country_codes:
                    findings.append(Finding(f"{prefix}_EMAIL_PURPOSE", "EmailPurp musi być aktywnym dwuliterowym kodem kraju ISO 3166-1.", language, category="profile"))

            creditor_country = text_at(tx, adapter, "Cdtr/PstlAdr/Ctry")
            if creditor_country in {"AE", "MY", "BH", "MM", "CN"} or amount.currency == "CNY":
                remittance_node = _node(tx, adapter, "RmtInf/Ustrd")
                codes = re.findall(r"/[A-Z0-9]+/", remittance_node.text or "") if remittance_node is not None else []
                if not 1 <= len(codes) <= 3:
                    findings.append(Finding(f"{prefix}_PURPOSE_CODE", "Przelew do AE, MY, BH, MM, CN albo w CNY wymaga w Ustrd od 1 do 3 kodów celu w formacie /KOD/; listę kodów udostępnia bank.", remittance_node if remittance_node is not None else tx, category="profile"))


def _validate_seb(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], country: str) -> None:
    prefix = f"SEB_{country}"
    _check_common(findings, tree, adapter, groups, prefix)
    leaves = [node for node in tree.iter() if isinstance(node.tag, str) and len(node) == 0 and not (node.text or "").strip()]
    for node in leaves:
        findings.append(Finding(f"{prefix}_EMPTY_ELEMENT", "SEB nie przyjmuje pustych elementów XML.", node, category="profile"))
    ids: list[tuple[str, etree._Element]] = []
    if sum(len(group.findall(adapter.q("CdtTrfTxInf"))) for group in groups) > 50_000:
        findings.append(Finding(f"{prefix}_TRANSACTION_LIMIT", "Plik przekracza limit 50 000 transakcji SEB.", tree.getroot(), category="profile"))
    for group in groups:
        debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind == "IBAN" and debtor and not debtor.startswith(country):
            findings.append(Finding(f"{prefix}_DEBTOR_COUNTRY", f"Profil SEB {country} wymaga rachunku dłużnika z prefiksem {country}.", debtor_node, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None:
                ids.append((end.text or "", end))
                if len(end.text or "") > 35 or not re.fullmatch(r"[A-Za-z0-9]+", end.text or ""):
                    findings.append(Finding(f"{prefix}_ENDTOEND_FORMAT", "SEB wymaga EndToEndId do 35 znaków, wyłącznie litery i cyfry.", end, category="profile"))
            tx_type = _node(tx, adapter, "PmtTpInf")
            if tx_type is not None and text_at(tx, adapter, "PmtTpInf/SvcLvl/Cd") != "SEPA":
                findings.append(Finding(f"{prefix}_TYPE_LEVEL", "SEB wymaga PmtTpInf na poziomie grupy; w transakcji dopuszcza tylko oznaczenie SvcLvl=SEPA.", tx_type, category="profile"))
            if _is_sepa(group, tx, adapter):
                _check_sepa(findings, group, tx, adapter, prefix)
            instrument = _local_instrument(group, tx, adapter)
            if country == "DK" and instrument and instrument not in {"SDCL", "INST", "IBK01", "IBK04", "IBK15", "IBK71", "IBK73", "IBK75"}:
                findings.append(Finding(f"{prefix}_LOCAL_INSTRUMENT", f"Nieobsługiwany duński LclInstrm: {instrument}.", tx, category="profile"))
            amount = read_amount(tx, adapter)
            creditor, _, _ = _account(tx, adapter, "CdtrAcct")
            if creditor and creditor.startswith(country) and not _is_sepa(group, tx, adapter):
                expected = {"NO": "NOK", "DK": "DKK", "SE": "SEK"}[country]
                if amount.currency != expected:
                    findings.append(Finding(f"{prefix}_DOMESTIC_CURRENCY", f"Krajowa płatność SEB {country} wymaga waluty {expected}.", amount.node if amount.node is not None else tx, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")
    duplicate = {value for value, count in Counter(value for value, _ in ids).items() if value and count > 1}
    for value, node in ids:
        if value in duplicate:
            findings.append(Finding(f"{prefix}_ENDTOEND_DUPLICATE", f"EndToEndId powtarza się w pliku: {value}.", node, category="profile"))
    _check_text_charset(findings, tree.getroot(), NORDIC, f"{prefix}_CHARSET", f"Zestaw znaków SEB {country}")


def _validate_insidebusiness(findings: list[Finding], tree: etree._ElementTree, adapter: Adapter, groups: list[etree._Element], country: str) -> None:
    prefix = f"ING_INSIDE_{country}"
    _check_common(findings, tree, adapter, groups, prefix)
    _check_text_charset(findings, tree.getroot(), LATIN_BASIC, f"{prefix}_CHARSET", "Zestaw znaków OneXML")
    today = date.today()
    for group in groups:
        debtor, debtor_node, debtor_kind = _account(group, adapter, "DbtrAcct")
        if debtor_kind == "IBAN" and debtor and not debtor.startswith(country):
            findings.append(Finding(f"{prefix}_DEBTOR_COUNTRY", f"Profil manual upload {country} wymaga rachunku dłużnika z prefiksem {country}.", debtor_node, category="profile"))
        _required(findings, group, adapter, f"DbtrAgt/FinInstnId/{adapter.bic_tag}", f"{prefix}_DEBTOR_BIC", "BICFI banku dłużnika")
        raw_date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        if raw_date:
            try:
                requested = date.fromisoformat(raw_date[:10])
            except ValueError:
                requested = None
            if requested is not None and not (today - timedelta(days=5) <= requested <= today + timedelta(days=370)):
                requested_node = _node(group, adapter, adapter.execution_date_paths[0])
                findings.append(Finding(f"{prefix}_EXECUTION_DATE_RANGE", "ReqdExctnDt musi mieścić się od 5 dni wstecz do 370 dni naprzód.", requested_node if requested_node is not None else group, category="profile"))
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            end = _required(findings, tx, adapter, "PmtId/EndToEndId", f"{prefix}_ENDTOEND", "EndToEndId")
            if end is not None and len(end.text or "") > 35:
                findings.append(Finding(f"{prefix}_ENDTOEND_LENGTH", "EndToEndId przekracza limit 35 znaków OneXML.", end, category="profile"))
            group_charge = _node(group, adapter, "ChrgBr")
            tx_charge = _node(tx, adapter, "ChrgBr")
            if group_charge is not None and tx_charge is not None:
                findings.append(Finding(f"{prefix}_CHARGE_LEVEL", "ChrgBr może wystąpić na poziomie grupy albo transakcji, ale nie na obu.", tx_charge, category="profile"))
            if _is_sepa(group, tx, adapter):
                _check_sepa(findings, group, tx, adapter, prefix, {"SLEV", "SHAR"})
            creditor_bic = _node(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
            creditor_member = _node(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
            if creditor_bic is None and creditor_member is None:
                findings.append(Finding(f"{prefix}_CREDITOR_AGENT", "OneXML wymaga identyfikacji banku odbiorcy przez BICFI albo numer rozliczeniowy MmbId.", tx, category="profile"))
            _check_address(findings, _node(tx, adapter, "Cdtr"), adapter, f"{prefix}_ADDRESS")
        batch = text_at(group, adapter, "BtchBookg")
        if batch == "true" and country in {"NO", "DK"}:
            batch_node = _node(group, adapter, "BtchBookg")
            findings.append(Finding(f"{prefix}_BATCH_BOOKING", f"BatchBooking=true nie jest wspierane dla {country}.", batch_node if batch_node is not None else group, category="profile"))
        elif batch == "true" and country in {"SE", "BE", "NL"}:
            if not all(_is_sepa(group, tx, adapter) for tx in group.findall(adapter.q("CdtTrfTxInf"))):
                batch_node = _node(group, adapter, "BtchBookg")
                findings.append(Finding(f"{prefix}_BATCH_BOOKING", "BatchBooking=true jest wspierane tu wyłącznie dla SEPA.", batch_node if batch_node is not None else group, category="profile"))


def validate_bank_profile(
    tree: etree._ElementTree,
    adapter: Adapter,
    groups: list[etree._Element],
    transactions: list[etree._Element],
    profile_id: str,
) -> tuple[list[Finding], dict[str, object]]:
    manifest = _manifest(profile_id)
    supported = set(manifest["message_identifiers"])
    scope: dict[str, object] = {
        "profile_id": profile_id,
        "assessed": 0,
        "not_applicable": 0,
        "total": len(transactions),
        "bundle_id": profile_bundle()["bundle_id"],
        "document_version": manifest["document_version"],
        "source_sha256": manifest["source_sha256"],
        "coverage": "static_file_validation",
        "external_checks_not_performed": profile_bundle()["external_checks_not_performed"],
    }
    for key in ("source_examples_sha256", "scope_notice"):
        if manifest.get(key):
            scope[key] = manifest[key]
    if adapter.message_identifier not in supported:
        return [Finding(
            "PROFILE_VERSION_UNSUPPORTED",
            f"Profil {manifest['name']} obsługuje {', '.join(sorted(supported))}, a dokument ma wersję {adapter.message_identifier}.",
            tree.getroot(),
            category="profile",
        )], scope

    effective_from = manifest.get("effective_from")
    findings: list[Finding] = []
    if effective_from and date.today() < date.fromisoformat(str(effective_from)):
        findings.append(Finding(
            "PROFILE_SOURCE_NOT_YET_EFFECTIVE",
            f"Dokumentacja profilu zaczyna obowiązywać {effective_from}; wynik przed tą datą ma charakter przygotowawczy.",
            tree.getroot(),
            severity="warning",
            category="profile",
        ))

    scope["assessed"] = len(transactions)
    if profile_id == "mbank-companynet-2026":
        _validate_mbank(findings, tree, adapter, groups, False)
    elif profile_id == "mbank-swiftnet-2026":
        _validate_mbank(findings, tree, adapter, groups, True)
    elif profile_id == "ing-business-pl-2026":
        _validate_ing_pl(findings, tree, adapter, groups)
    elif profile_id == "santander-ibiznes24-2026":
        _validate_santander(findings, tree, adapter, groups)
    elif profile_id == "bnp-goonline-business-2026":
        _validate_bnp(findings, tree, adapter, groups)
    elif profile_id == "citidirect-pl-2026":
        variants: Counter[str] = Counter()
        _validate_citi(findings, tree, adapter, groups, variants)
        scope["variants"] = dict(sorted(variants.items()))
    elif profile_id == "pko-ipko-business-pl-2026":
        variants = Counter()
        _validate_pko_pl(findings, tree, adapter, groups, variants)
        scope["variants"] = dict(sorted(variants.items()))
    elif profile_id.startswith("seb-"):
        country = {"seb-norway-2026": "NO", "seb-denmark-2026": "DK", "seb-sweden-2026": "SE"}[profile_id]
        _validate_seb(findings, tree, adapter, groups, country)
    elif profile_id.startswith("ing-insidebusiness-"):
        country = profile_id.removeprefix("ing-insidebusiness-").removesuffix("-2026").upper()
        _validate_insidebusiness(findings, tree, adapter, groups, country)
    else:  # pragma: no cover - guarded by profile_ids()
        raise ValueError(f"Nieznany profil bankowy: {profile_id}")
    return findings, scope
