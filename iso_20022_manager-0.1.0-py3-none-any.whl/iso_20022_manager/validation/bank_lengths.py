"""Audited bank text limits, shared by validation and editor metadata.

These are restrictions on the original XML, not replacement XSD facets. Paths
are namespace-qualified; bank limits never leak to extensions or another version.
"""
from __future__ import annotations

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at
from iso_20022_manager.core.totals import read_amount

from .bank_profiles import _citi_variant, _effective, _is_sepa, _local_instrument, _manifest, _node, _pko_payment_type
from .bank_context import is_mail, seb_country, seb_domestic
from .findings import Finding


LENGTH_AUDIT_ID = "bank-text-lengths-2026-10-05"
SEB_LENGTH_SOURCE = {
    "document_version": "26.4.0.0 (obowiązuje od 2026-10-05), audyt długości",
    "source_sha256": "1d44df69125a559ad6011984fad9b5ec0708e18d8cb90eb041279ad2aa4d1721",
}


def length_source(profile_id: str) -> dict[str, str]:
    manifest = _manifest(profile_id)
    return {
        "audit_id": LENGTH_AUDIT_ID,
        "document_version": str(manifest["document_version"]),
        "source_sha256": str(manifest["source_sha256"]),
        **(SEB_LENGTH_SOURCE if profile_id.startswith("seb-") else {}),
    }


def bank_length_constraints(tree: etree._ElementTree, adapter: Adapter, profile_id: str) -> dict[etree._Element, list[dict[str, object]]]:
    from .bank_profiles import profile_ids

    if profile_id not in profile_ids():
        return {}
    manifest = _manifest(profile_id)
    if adapter.message_identifier not in manifest["message_identifiers"]:
        return {}
    source = f"{manifest['name']} {length_source(profile_id)['document_version']}"
    result: dict[etree._Element, list[dict[str, object]]] = {}

    def add(parent: etree._Element, path: str, limit: int | None = None, *, ref: str, rule: str = "BANK_FIELD_LENGTH", minimum: int | None = None, total: int | None = None, count: int | None = None, tags: tuple[str, ...] = (), severity: str = "error", notice: str = "") -> None:
        nodes = parent.findall("/".join(adapter.q(part) for part in path.split("/"))) if path else [parent]
        descriptions = []
        if limit is not None:
            descriptions.append(f"Maksymalnie {limit} znaków")
        if minimum is not None:
            descriptions.append(f"co najmniej {minimum} znaków")
        if total is not None:
            descriptions.append(f"łącznie maksymalnie {total} znaków w {', '.join(tags)}")
        if count is not None:
            descriptions.append(f"najwyżej {count} wystąpień {', '.join(tags)}")
        protection = profile_id == "mbank-swiftnet-2026" and rule in {"MBANK_SWIFTNET_DEBTOR_NAME_LENGTH", "MBANK_SWIFTNET_ENDTOEND_LENGTH"}
        protection |= profile_id == "bnp-goonline-business-2026" and total == 70 and path == "Cdtr/PstlAdr"
        if protection:
            notice = "Polityka aplikacji chroniąca przed udokumentowanym obcięciem przez bank, nie potwierdzony bankowy hard reject. " + notice
        kind = "application_data_loss_policy" if protection else "bank_data_transformation" if severity == "warning" else "bank_requirement"
        constraint = {"rule_id": rule, "source": source, "source_ref": ref, "source_sha256": length_source(profile_id)["source_sha256"], "document_version": length_source(profile_id)["document_version"], "profile_id": profile_id, "message_identifier": adapter.message_identifier, "xml_path": f"{etree.QName(parent).localname}/{path}", "kind": kind, "severity": severity, "description": "; ".join(descriptions) + "." + (f" {notice}" if notice else "")}
        constraint.update({key: value for key, value in {"max_length": limit, "min_length": minimum, "max_total": total, "max_occurs": count}.items() if value is not None})
        if tags:
            constraint["child_tags"] = list(tags)
        for node in nodes:
            constraints = result.setdefault(node, [])
            if constraint not in constraints:
                constraints.append(constraint)

    def fields(parent: etree._Element, limits: dict[str, int], ref: str) -> None:
        for path, limit in limits.items():
            add(parent, path, limit, ref=ref)

    initiation = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn")
    if initiation is None:
        return result
    groups = initiation.findall(adapter.q("PmtInf"))
    header = _node(initiation, adapter, "GrpHdr")
    if header is not None:
        add(header, "InitgPty/Nm", 35 if profile_id.startswith("citidirect-") else 70, ref="Citi: wiersz 12 / pozostałe: tabela GrpHdr/InitgPty", rule="MBANK_SWIFTNET_INITIATING_NAME_LENGTH" if profile_id == "mbank-swiftnet-2026" else "MBANK_COMPANYNET_INITIATING_NAME_LENGTH" if profile_id == "mbank-companynet-2026" else "BANK_FIELD_LENGTH")

    for group in groups:
        transactions = group.findall(adapter.q("CdtTrfTxInf"))
        if profile_id.startswith("mbank-"):
            swift = profile_id == "mbank-swiftnet-2026"
            prefix = "MBANK_SWIFTNET" if swift else "MBANK_COMPANYNET"
            tax_group = any(_effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd") == "TAXS" for tx in transactions)
            mail_group = not swift and any(is_mail(tx, adapter) for tx in transactions)
            add(group, "Dbtr/Nm", 30 if mail_group else 35 if tax_group and not swift else 70, ref="PDF s. 31 §6.8 MAIL" if mail_group else "Tabela Dbtr/Nm; krajowe/podatkowe", rule=f"{prefix}_DEBTOR_NAME_LENGTH")
            if not swift:
                add(group, "Dbtr/CtctDtls/EmailAdr", 200, ref="Dbtr/CtctDtls/EmailAdr", rule=f"{prefix}_EMAIL_LENGTH")
            for address in group.iter(adapter.q("PstlAdr")):
                if not swift:
                    add(address, "AdrLine", 35, ref="PstlAdr/AdrLine", rule=f"{prefix}_ADDRESS_LINE_LENGTH")
                    add(address, "", count=2, tags=("AdrLine",), ref="PstlAdr/AdrLine", rule=f"{prefix}_ADDRESS_LINES")
            for member in group.findall(f".//{adapter.q('ClrSysMmbId')}/{adapter.q('MmbId')}"):
                add(member, "", 8, minimum=8, ref="ClrSysMmbId/MmbId", rule=f"{prefix}_CLEARING_MEMBER")
        elif profile_id == "citidirect-pl-2026":
            fields(group, {"Dbtr/Nm": 35, "DbtrAcct/Id/Othr/Id": 10}, "GOLD, wiersze 114, 160")
        elif not profile_id.startswith("seb-") and profile_id != "pko-ipko-business-pl-2026":
            add(group, "Dbtr/Nm", 70, ref="Tabela Dbtr/Nm")

        if profile_id == "ing-business-pl-2026":
            add(group, "Dbtr/PstlAdr", total=70, count=2, tags=("AdrLine",), ref="ING PL, s. 25")
        elif profile_id == "santander-ibiznes24-2026":
            fields(group, {f"Dbtr/PstlAdr/{tag}": length for tag, length in {"StrtNm": 25, "BldgNb": 10, "PstCd": 10, "TwnNm": 25}.items()}, "Santander, tabele .09, s. 130, 141, 153, 164, 178, 187")
        elif profile_id.startswith("ing-insidebusiness-"):
            add(group, "UltmtDbtr/Nm", 70, ref="OneXML, s. 6")
        elif profile_id == "pko-ipko-business-pl-2026":
            add(group, "UltmtDbtr/Nm", 70, ref="iPKO PL, s. 15 (pole obecnie nieobsługiwane)")

        if profile_id.startswith("seb-"):
            for party in ("Dbtr", "UltmtDbtr"):
                add(group, f"{party}/PstlAdr", total=70, count=5, tags=("AdrLine",), ref="SEB, s. 16–18")
            if any(_is_sepa(group, tx, adapter) for tx in transactions):
                add(group, "UltmtDbtr/Nm", 70, ref="SEB, s. 18", severity="warning", notice="XSD przyjmuje 140, ale do banku odbiorcy SEPA przekazywane jest najwyżej 70 znaków nazwy.")

        for tx in transactions:
            sepa = _is_sepa(group, tx, adapter)
            currency = read_amount(tx, adapter).currency
            creditor_iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN") or ""
            foreign = sepa or currency not in {None, "PLN"} or (len(creditor_iban) >= 2 and creditor_iban[:2].isalpha() and not creditor_iban.startswith("PL"))
            if profile_id.startswith("mbank-"):
                purpose = _effective(group, tx, adapter, "PmtTpInf/CtgyPurp/Cd")
                mail = not swift and is_mail(tx, adapter)
                add(tx, "Cdtr/Nm", 35 if not swift and (purpose == "TAXS" or mail) else 70, ref="PDF s. 31 §6.8 MAIL" if mail else "Tabela Cdtr/Nm; krajowe/podatkowe", rule=f"{prefix}_CREDITOR_NAME_LENGTH")
                add(tx, "PmtId/EndToEndId", 35 if sepa else 16, ref="Tabela EndToEndId", rule=f"{prefix}_ENDTOEND_LENGTH")
                if purpose == "TAXS":
                    add(tx, "Tax/Dbtr/RegnId", 15, ref="Przelewy podatkowe, RegnId", rule=f"{prefix}_TAX_REGISTRATION_LENGTH")
                    add(tx, "Tax/Rcrd/AddtlInf", 40, ref="Przelewy podatkowe, AddtlInf", rule=f"{prefix}_TAX_ADDITIONAL_INFO_LENGTH")
                address = _node(tx, adapter, "Cdtr/PstlAdr")
                if address is not None and currency == "PLN" and any(_node(address, adapter, tag) is not None for tag in ("StrtNm", "BldgNb", "TwnNm")):
                    add(address, "", total=70, tags=tuple(etree.QName(child).localname for child in address if isinstance(child.tag, str) and etree.QName(child).namespace == adapter.namespace), ref="Adres strukturalny krajowy PLN", rule=f"{prefix}_CREDITOR_ADDRESS_LENGTH")
            elif profile_id == "ing-business-pl-2026":
                fields(tx, {"Cdtr/Nm": 140 if foreign else 70, "UltmtCdtr/Nm": 70, "UltmtDbtr/Nm": 70, "Cdtr/PstlAdr/Room": 12}, "ING PL, s. 33–34, 38, 41")
                add(tx, "Cdtr/PstlAdr", total=140 if foreign else 70, count=2, tags=("AdrLine",), ref="ING PL, s. 33")
            elif profile_id == "santander-ibiznes24-2026":
                fields(tx, {"Cdtr/Nm": 70, "UltmtDbtr/Nm": 70, "UltmtCdtr/Nm": 70, "Cdtr/CtctDtls/EmailPurp": 3}, "Santander, tabele .09, s. 132–137, 143–149, 155–160, 166–173, 179–183, 189–192")
                fields(tx, {f"UltmtDbtr/PstlAdr/{tag}": length for tag, length in {"StrtNm": 25, "BldgNb": 10, "PstCd": 10, "TwnNm": 25}.items()}, "Santander, UltmtDbtr/PstlAdr, tabele .09")
                fields(tx, {f"Cdtr/PstlAdr/{tag}": length for tag, length in {"StrtNm": 24, "BldgNb": 8, "PstCd": 8, "TwnNm": 24}.items()}, "Santander, Cdtr/PstlAdr, tabele .09")
                if not foreign:
                    add(group, "DbtrAcct/Id/Othr/Id", 26, ref="Santander, s. 130, 141: NRB")
                    add(tx, "CdtrAcct/Id/Othr/Id", 26, ref="Santander, s. 136, 147: NRB")
            elif profile_id == "bnp-goonline-business-2026":
                fields(tx, {"Cdtr/Nm": 66 if foreign else 70, "UltmtCdtr/Nm": 70}, "BNP XML V2, s. 39, 49, 61, 63")
                add(tx, "PmtId/EndToEndId", 16, ref="BNP XML V2, s. 38, 48, 60", severity="warning", notice="Bank przyjmuje do 35 znaków, lecz przetwarza tylko pierwszych 16; ryzyko utraty części referencji.")
                add(group, "Dbtr/PstlAdr/AdrLine", 70 if sepa else 66, ref="BNP XML V2, s. 38, 47, 60 (pole ignorowane)")
                add(tx, "Cdtr/PstlAdr", total=63 if foreign else 70, count=2, tags=("AdrLine",), ref="BNP XML V2, s. 40, 49, 61")
                if foreign:
                    fields(tx, {"CdtrAgt/FinInstnId/Nm": 70, "CdtrAgt/FinInstnId/PstlAdr/AdrLine": 35}, "BNP XML V2, s. 49")
                    address = _node(tx, adapter, "Cdtr/PstlAdr")
                    if address is not None:
                        for position, line in enumerate(address.findall(adapter.q("AdrLine"))):
                            add(line, "", 33 if position == 0 else 30, ref="BNP XML V2, s. 49, 61: 33+30")
                if sepa:
                    add(group, "UltmtDbtr/Nm", 70, ref="BNP XML V2, s. 60")
                    for parent, party in ((group, "Dbtr"), (group, "UltmtDbtr"), (tx, "Cdtr"), (tx, "UltmtCdtr")):
                        for kind in ("OrgId", "PrvtId"):
                            add(parent, f"{party}/Id/{kind}/Othr/SchmeNm/Cd", 3, ref="BNP XML V2, s. 65–66")
                elif foreign:
                    add(tx, "RmtInf/Strd/AddtlRmtInf", 105, ref="BNP XML V2, s. 52")
                else:
                    add(tx, "Tax/Rcrd/AddtlInf", 14, ref="BNP XML V2, s. 43")
            elif profile_id == "citidirect-pl-2026":
                variant = _citi_variant(group, tx, adapter)
                ref = f"GOLD, arkusz {variant} (592/984: nazwa arkusza PL_ACH)"
                citi_sepa = variant in {"795_PL_SEPA", "938_PL_SEPA"}
                add(group, "PmtInfId", 35 if citi_sepa else 34, ref=ref)
                add(group, "PmtTpInf/LclInstrm/Prtry", 7, ref=ref)
                if variant in {"555_PL_ACH", "795_PL_SEPA", "938_PL_SEPA"}:
                    add(group, "PmtTpInf/LclInstrm/Cd", 6 if variant == "795_PL_SEPA" else 4, ref=ref)
                add(tx, "PmtId/EndToEndId", 35 if citi_sepa else 16, ref=ref, rule="CITI_PL_ENDTOEND_LENGTH")
                if citi_sepa:
                    fields(group, {"UltmtDbtr/Nm": 70, "Dbtr/PstlAdr/AdrLine": 35}, ref)
                    fields(tx, {"Cdtr/Nm": 70, "UltmtCdtr/Nm": 70, "Cdtr/PstlAdr/AdrLine": 35, "RgltryRptg/Dtls/Inf": 3}, ref + "!N645: maksymalnie 70 znaków")
                    for parent, path in ((group, "Dbtr/PstlAdr"), (tx, "Cdtr/PstlAdr")):
                        add(parent, path, count=4, tags=("AdrLine",), ref=ref)
                    add(tx, "RmtInf", total=140, tags=("Ustrd",), ref=ref)
                else:
                    fields(tx, {"Cdtr/Nm": 35, "CdtrAcct/Nm": 35, "CdtrAgt/FinInstnId/Nm": 35, "Cdtr/PstlAdr/AdrLine": 35}, ref)
                    wire = variant == "574_PL_WIRE"
                    add(tx, "Cdtr/PstlAdr", count=3 if wire else 2, tags=("AdrLine",), ref=ref)
                    if wire:
                        fields(group, {"Dbtr/PstlAdr/AdrLine": 35, "ChrgsAcct/Id/Othr/Id": 32}, ref)
                        add(group, "Dbtr/PstlAdr", count=3, tags=("AdrLine",), ref=ref)
                        for agent in ("IntrmyAgt1", "CdtrAgt"):
                            fields(tx, {f"{agent}/FinInstnId/Nm": 35, f"{agent}/FinInstnId/PstlAdr/AdrLine": 35}, ref)
                            add(tx, f"{agent}/FinInstnId/PstlAdr", count=3, tags=("AdrLine",), ref=ref)
                        add(tx, "RmtInf/Ustrd", 35, ref=ref)
                        add(tx, "RmtInf", total=315, count=9, tags=("Ustrd",), ref=ref)
                    else:
                        fields(tx, {"CdtrAcct/Id/IBAN": 28, "CdtrAcct/Id/Othr/Id": 26, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId": 8}, ref)
                    if variant == "592_PL_TAX":
                        fields(group, {"Dbtr/Id/PrvtId/Othr/Id": 14, "Dbtr/Id/PrvtId/Othr/SchmeNm/Cd": 1, "Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry": 1}, ref)
                        fields(tx, {"Tax/Dbtr/RegnId": 34, "Tax/Rcrd/FrmsCd": 7}, ref)
                    elif variant == "984_PL_VAT":
                        fields(tx, {"Tax/Cdtr/TaxId": 14, "Tax/AdmstnZn": 1, "Tax/RefNb": 35, "Tax/Rcrd/AddtlInf": 33}, ref)
                    elif variant == "555_PL_ACH":
                        add(tx, "Tax/AdmstnZn", 1, ref=ref + ", uwaga specyficzna dla ISOXML v3")
            elif profile_id == "pko-ipko-business-pl-2026":
                if _pko_payment_type(group, tx, adapter)[0] in {"split", "split_express"}:
                    fields(tx, {"RmtInf/Strd/TaxRmt/Cdtr/TaxId": 14, "RmtInf/Strd/TaxRmt/RefNb": 35, "RmtInf/Strd/AddtlRmtInf": 33}, "iPKO PL, s. 6–7: strukturyzowany Split Payment (tabela ogólna s. 29 nie zastępuje limitów produktu)")
                fields(tx, {"Cdtr/Nm": 70, "UltmtDbtr/Nm": 70, "UltmtCdtr/Nm": 70}, "iPKO PL, s. 21, 23, 26")
                add(tx, "Cdtr/CtctDtls/EmailPurp", 2, minimum=2, ref="iPKO PL, s. 25: dwuliterowy kod kraju")
                add(tx, "Cdtr/PstlAdr", count=1, tags=("AdrLine",), ref="iPKO PL, s. 24")
            elif profile_id.startswith("seb-"):
                add(tx, "Cdtr/Nm", 70, ref="SEB, s. 22: Limited to 70 characters")
                for party in ("Cdtr", "UltmtDbtr", "UltmtCdtr"):
                    add(tx, f"{party}/PstlAdr", total=70, count=5, tags=("AdrLine",), ref="SEB, s. 20, 23–24")
                if sepa:
                    add(tx, "UltmtDbtr/Nm", 70, ref="SEB, s. 20", severity="warning", notice="Do banku odbiorcy SEPA przekazywane jest najwyżej 70 znaków nazwy; XSD dopuszcza 140.")
                for reference in tx.findall("/".join(adapter.q(tag) for tag in ("RmtInf", "Strd", "CdtrRefInf"))):
                    if text_at(reference, adapter, "Tp/Issr") == "ISO":
                        add(reference, "Ref", 25, ref="SEB, s. 58: ISO 11649")
                    elif sepa:
                        add(reference, "Ref", 26, ref="SEB, s. 58: SEPA")
                    elif text_at(reference, adapter, "Tp/CdOrPrtry/Cd") == "SCOR":
                        country = seb_country(profile_id)
                        if seb_domestic(group, tx, adapter, country) and country in {"NO", "SE"}:
                            add(reference, "Ref", 25, minimum=2, ref="SEB, s. 58: KID/OCR")
                        elif country == "DK" and _local_instrument(group, tx, adapter) in {"IBK04", "IBK15", "IBK71", "IBK75"}:
                            instrument = _local_instrument(group, tx, adapter)
                            maximum = 15 if instrument == "IBK71" else 16
                            minimum = 15 if instrument in {"IBK71", "IBK75"} else 16
                            add(reference, "Ref", maximum, minimum=minimum, ref="SEB, s. 86 §7.2: GIK04/15 = 16; FIK71 = 15; FIK75 = 15–16")
                giro = text_at(tx, adapter, "CdtrAcct/Prxy/Tp/Prtry") in {"BGNR", "PGNR"} or text_at(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId") in {"9900", "9960"}
                if profile_id == "seb-sweden-2026" and currency == "SEK" and giro:
                    add(tx, "RmtInf/Strd", total=315, count=3, tags=("AddtlRmtInf",), ref="SEB, s. 59: szwedzkie giro")
            elif profile_id.startswith("ing-insidebusiness-"):
                fields(tx, {"Cdtr/Nm": 70, "UltmtCdtr/Nm": 70, "CdtrAcct/Id/Othr/Id": 34, "Tax/Rcrd/AddtlInf": 40, "RmtInf/Strd/CdtrRefInf/Tp/CdOrPrtry/Prtry": 3}, "OneXML, s. 8–10")
    return result


def validate_bank_lengths(constraints: dict[etree._Element, list[dict[str, object]]], namespace: str) -> list[Finding]:
    findings = []
    reported = set()
    for node, rules in constraints.items():
        for rule in rules:
            length = len(node.text or "")
            children = [child for child in node if isinstance(child.tag, str) and etree.QName(child).namespace == namespace and etree.QName(child).localname in rule.get("child_tags", [])]
            exceeded = (
                ("max_length" in rule and length > rule["max_length"])
                or ("min_length" in rule and length < rule["min_length"])
                or ("max_total" in rule and sum(len(child.text or "") for child in children) > rule["max_total"])
                or ("max_occurs" in rule and len(children) > rule["max_occurs"])
            )
            identity = (node, rule["rule_id"], rule["severity"])
            if exceeded and identity not in reported:
                reported.add(identity)
                findings.append(Finding(str(rule["rule_id"]), f"{etree.QName(node).localname}: {rule['description']} Źródło: {rule['source']} · {rule['source_ref']}.", node, severity=str(rule["severity"]), category="profile", source={key: rule[key] for key in ("kind", "source_ref", "source_sha256", "document_version", "profile_id", "message_identifier", "xml_path")}))
    return findings
