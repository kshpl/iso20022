"""Small, shared product predicates for audited bank rules (not XML rewriting)."""
import re

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, find_every, find_first, text_at
from iso_20022_manager.core.xml_nodes import ancestor_named


BNP_SPLIT_CODES = {"OTHR", "OTHR/VAT53", "VAT53", "OTHR/VAT58", "VAT58"}
BNP_SPLIT_PROPRIETARY = {"53", "58", "VAT53", "VAT58"}


def documented_external_code(node, adapter, profile_id):
    """A documented bank deviation, not a new ISO dictionary entry."""
    if profile_id != "bnp-goonline-business-2026" or node.tag != adapter.q("Cd") or node.text not in BNP_SPLIT_CODES:
        return None
    parent = node.getparent()
    if parent is None or parent.tag != adapter.q("LclInstrm"):
        return None
    info = parent.getparent()
    owner = info.getparent() if info is not None else None
    if info is None or info.tag != adapter.q("PmtTpInf") or owner is None or owner.tag not in {adapter.q("PmtInf"), adapter.q("CdtTrfTxInf")}:
        return None
    from iso_20022_manager.core.totals import read_amount
    from .bank_profiles import _is_sepa

    group = owner if owner.tag == adapter.q("PmtInf") else owner.getparent()
    transactions = owner.findall(adapter.q("CdtTrfTxInf")) if owner is group else [owner]
    if not transactions or any(read_amount(tx, adapter).currency != "PLN" or _is_sepa(group, tx, adapter) for tx in transactions):
        return None
    return rule_source(profile_id, "PDF XML V2 s. 38–39", product="split", kind="bank_documented_code_deviation")


def rule_source(profile_id, ref, *, product, kind="bank_requirement", current_seb=False, latest=False):
    from .bank_profiles import _manifest, profile_bundle

    manifest = profile_bundle()["audited_seb_rule_groups"] if current_seb else _manifest(profile_id)
    if latest:
        manifest = manifest["latest_published_source"]
    return {
        "kind": kind, "profile_id": profile_id, "document_version": manifest["document_version"],
        "source_sha256": manifest["source_sha256"], "source_ref": ref, "product": product,
    }


def is_mail(tx, adapter):
    return text_at(tx, adapter, "Purp/Prtry") == "MAIL"


def creditor_bank_country(tx, adapter):
    iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN") or ""
    if len(iban) >= 2 and iban[:2].isalpha():
        return iban[:2]
    bic = text_at(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}") or ""
    if len(bic) in {8, 11}:
        return bic[4:6]
    return text_at(tx, adapter, "CdtrAgt/FinInstnId/PstlAdr/Ctry")


def iban_format_hint(node: etree._Element, adapter: Adapter, profile_id: str) -> str | None:
    if profile_id != "seb-norway-2026" or adapter.message_identifier != "pain.001.001.09":
        return None
    if not re.fullmatch(r"[0-9]{11}", re.sub(r"[\s.]", "", node.text or "")):
        return None

    tx = ancestor_named(node, adapter.namespace, "CdtTrfTxInf")
    account_path = "/".join(adapter.q(tag) for tag in ("CdtrAcct", "Id", "IBAN"))
    if tx is None or find_first(tx, account_path) is not node:
        return None
    group = tx.getparent()
    if group is None or text_at(group, adapter, "PmtMtd") != "TRF":
        return None

    amount = find_first(tx, f"{adapter.q('Amt')}/{adapter.q('InstdAmt')}")
    if amount is None or amount.get("Ccy") != "NOK":
        return None
    service_path = "/".join(adapter.q(tag) for tag in ("PmtTpInf", "SvcLvl", "Cd"))
    if any(code.text == "SEPA" for owner in (group, tx) for code in find_every(owner, service_path)):
        return None
    country = creditor_bank_country(tx, adapter) or text_at(tx, adapter, "Cdtr/PstlAdr/Ctry")
    if country not in {None, "NO"}:
        return None

    return ("Jeśli to norweski numer lokalny, w „Wszystkie pola” rozwiń CdtrAcct → Id. "
            "Zastąp <IBAN> elementem <Othr>, w Othr → Id wpisz 11 cyfr bez kropek i spacji, "
            "a w Othr → SchmeNm → Cd ustaw BBAN.")


def seb_country(profile_id):
    return {"seb-norway-2026": "NO", "seb-sweden-2026": "SE", "seb-denmark-2026": "DK"}[profile_id]


def seb_domestic(group, tx, adapter, country):
    """Positive identification; currency alone never establishes locality.

    BBAN is country-neutral: combine it with the bank BIC / explicit address.
    A recognised foreign IBAN/BIC wins over the sender's country. Giro proxies
    and NETS/cards identify domestic products even with NOTPROVIDED in Id.
    """
    from .bank_profiles import _is_sepa, _local_instrument

    if _is_sepa(group, tx, adapter):
        return False
    if country in {"NO", "SE"} and text_at(group, adapter, "PmtMtd") == "CHK":
        return True
    proxy = text_at(tx, adapter, "CdtrAcct/Prxy/Tp/Prtry")
    member = text_at(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
    if country == "SE" and (proxy in {"BGNR", "PGNR"} or member in {"9900", "9960"}):
        return True
    if country == "DK" and (proxy == "NETS" or _local_instrument(group, tx, adapter) in {"IBK01", "IBK04", "IBK15", "IBK71", "IBK73", "IBK75"}):
        return True
    iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN")
    if iban:
        return iban.startswith(country)
    scheme = text_at(tx, adapter, "CdtrAcct/Id/Othr/SchmeNm/Cd")
    other = text_at(tx, adapter, "CdtrAcct/Id/Othr/Id")
    bic = text_at(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
    creditor_country = text_at(tx, adapter, "Cdtr/PstlAdr/Ctry")
    if bic:
        return bool(scheme == "BBAN" and other and bic[4:6] == country)
    return bool(scheme == "BBAN" and other and creditor_country == country)
