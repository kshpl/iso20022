"""Small, shared product predicates for audited bank rules (not XML rewriting)."""
from iso_20022_manager.core.adapters import text_at


SEB_CURRENT_SOURCE = {
    "document_version": "26.4.0.0 (2026-10-05)",
    "source_sha256": "1d44df69125a559ad6011984fad9b5ec0708e18d8cb90eb041279ad2aa4d1721",
}
BNP_SPLIT_CODES = {"OTHR", "OTHR/VAT53", "VAT53", "OTHR/VAT58", "VAT58"}
BNP_SPLIT_PROPRIETARY = {"53", "58", "VAT53", "VAT58"}


def documented_external_code(node, adapter, profile_id):
    """A documented bank deviation, not a new ISO dictionary entry."""
    if profile_id != "bnp-goonline-business-2026" or node.tag != adapter.q("Cd") or node.text not in BNP_SPLIT_CODES:
        return None
    parent = node.getparent()
    if parent is None or parent.tag != adapter.q("LclInstrm"):
        return None
    info = parent.getparent()
    owner = info.getparent() if info is not None else None
    if info is None or info.tag != adapter.q("PmtTpInf") or owner is None or owner.tag not in {adapter.q("PmtInf"), adapter.q("CdtTrfTxInf")}:
        return None
    from iso_20022_manager.core.totals import read_amount
    from .bank_profiles import _is_sepa

    group = owner if owner.tag == adapter.q("PmtInf") else owner.getparent()
    transactions = owner.findall(adapter.q("CdtTrfTxInf")) if owner is group else [owner]
    if not transactions or any(read_amount(tx, adapter).currency != "PLN" or _is_sepa(group, tx, adapter) for tx in transactions):
        return None
    return rule_source(profile_id, "PDF XML V2 s. 38–39", product="split", kind="bank_documented_code_deviation")


def rule_source(profile_id, ref, *, product, kind="bank_requirement", current_seb=False):
    from .bank_profiles import _manifest

    manifest = _manifest(profile_id)
    return {
        "kind": kind, "profile_id": profile_id, "document_version": manifest["document_version"],
        "source_sha256": manifest["source_sha256"], "source_ref": ref, "product": product,
        **(SEB_CURRENT_SOURCE if current_seb else {}),
    }


def is_mail(tx, adapter):
    return text_at(tx, adapter, "Purp/Prtry") == "MAIL"


def seb_country(profile_id):
    return {"seb-norway-2026": "NO", "seb-sweden-2026": "SE", "seb-denmark-2026": "DK"}[profile_id]


def seb_domestic(group, tx, adapter, country):
    """Positive identification; currency alone never establishes locality.

    BBAN is country-neutral: combine it with the bank BIC / explicit address.
    A recognised foreign IBAN/BIC wins over the sender's country. Giro proxies
    and NETS/cards identify domestic products even with NOTPROVIDED in Id.
    """
    from .bank_profiles import _is_sepa, _local_instrument

    if _is_sepa(group, tx, adapter):
        return False
    proxy = text_at(tx, adapter, "CdtrAcct/Prxy/Tp/Prtry")
    member = text_at(tx, adapter, "CdtrAgt/FinInstnId/ClrSysMmbId/MmbId")
    if country == "SE" and (proxy in {"BGNR", "PGNR"} or member in {"9900", "9960"}):
        return True
    if country == "DK" and (proxy == "NETS" or _local_instrument(group, tx, adapter) in {"IBK01", "IBK04", "IBK15", "IBK71", "IBK73", "IBK75"}):
        return True
    iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN")
    if iban:
        return iban.startswith(country)
    scheme = text_at(tx, adapter, "CdtrAcct/Id/Othr/SchmeNm/Cd")
    other = text_at(tx, adapter, "CdtrAcct/Id/Othr/Id")
    bic = text_at(tx, adapter, f"CdtrAgt/FinInstnId/{adapter.bic_tag}")
    creditor_country = text_at(tx, adapter, "Cdtr/PstlAdr/Ctry")
    if bic:
        return bool(scheme == "BBAN" and other and bic[4:6] == country)
    return bool(scheme == "BBAN" and other and creditor_country == country)
