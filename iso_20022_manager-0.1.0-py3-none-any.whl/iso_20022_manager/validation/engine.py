from __future__ import annotations

import hashlib
import re
from collections import Counter
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation
from uuid import uuid4

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at
from iso_20022_manager.core.projections import document_nodes
from iso_20022_manager.core.totals import calculate, read_amount
from iso_20022_manager.core.xml_nodes import NodeIndex, ancestor_named
from iso_20022_manager.schemas.registry import entries, validate_document
from iso_20022_manager.schemas.metadata import schema_model

from .code_sets import external_code_sets

# Static, packaged snapshot used offline. Minor units absent from SPECIAL_MINOR_UNITS
# are 2 only for codes present in this list. Metals/test/supranational codes are
# intentionally included where they are valid ISO 4217 alphabetic codes.
CURRENCY_CODES = set("""AED AFN ALL AMD AOA ARS AUD AWG AZN BAM BBD BDT BGN BHD BIF BMD BND BOB BOV BRL BSD BTN BWP BYN BZD CAD CDF CHE CHF CHW CLF CLP CNY COP COU CRC CUC CUP CVE CZK DJF DKK DOP DZD EGP ERN ETB EUR FJD FKP GBP GEL GHS GIP GMD GNF GTQ GYD HKD HNL HTG HUF IDR ILS INR IQD IRR ISK JMD JOD JPY KES KGS KHR KMF KPW KRW KWD KYD KZT LAK LBP LKR LRD LSL LYD MAD MDL MGA MKD MMK MNT MOP MRU MUR MVR MWK MXN MXV MYR MZN NAD NGN NIO NOK NPR NZD OMR PAB PEN PGK PHP PKR PLN PYG QAR RON RSD RUB RWF SAR SBD SCR SDG SEK SGD SHP SLE SLL SOS SRD SSP STN SVC SYP SZL THB TJS TMT TND TOP TRY TTD TWD TZS UAH UGX USD USN UYI UYU UYW UZS VED VES VND VUV WST XAF XAG XAU XBA XBB XBC XBD XCD XDR XOF XPD XPF XPT XSU XTS XUA XXX YER ZAR ZMW ZWG""".split())
SPECIAL_MINOR_UNITS = {
    "BHD": 3, "BIF": 0, "BYN": 2, "CLF": 4, "CLP": 0, "DJF": 0,
    "GNF": 0, "IQD": 3, "ISK": 0, "JOD": 3, "JPY": 0, "KMF": 0,
    "KRW": 0, "KWD": 3, "LYD": 3, "MGA": 2, "MRU": 2, "OMR": 3,
    "PYG": 0, "RWF": 0, "TND": 3, "UGX": 0, "UYI": 0, "UYW": 4,
    "VND": 0, "VUV": 0, "XAF": 0, "XOF": 0, "XPF": 0,
}
IBAN_LENGTHS = {
    "AD": 24, "AE": 23, "AL": 28, "AT": 20, "AZ": 28, "BA": 20, "BE": 16,
    "BG": 22, "BH": 22, "BI": 27, "BR": 29, "BY": 28, "CH": 21, "CR": 22,
    "CY": 28, "CZ": 24, "DE": 22, "DJ": 27, "DK": 18, "DO": 28, "EE": 20,
    "EG": 29, "ES": 24, "FI": 18, "FK": 18, "FO": 18, "FR": 27, "GB": 22,
    "GE": 22, "GI": 23, "GL": 18, "GR": 27, "GT": 28, "HR": 21, "HU": 28,
    "IE": 22, "IL": 23, "IQ": 23, "IS": 26, "IT": 27, "JO": 30, "KW": 30,
    "KZ": 20, "LB": 28, "LC": 32, "LI": 21, "LT": 20, "LU": 20, "LV": 21,
    "LY": 25, "MC": 27, "MD": 24, "ME": 22, "MK": 19, "MN": 20, "MR": 27,
    "MT": 31, "MU": 30, "NI": 32, "NL": 18, "NO": 15, "OM": 23, "PK": 24,
    "PL": 28, "PS": 29, "PT": 25, "QA": 29, "RO": 24, "RS": 22, "RU": 33,
    "SA": 24, "SC": 31, "SD": 18, "SE": 24, "SI": 19, "SK": 24, "SM": 27,
    "SO": 23, "ST": 25, "SV": 28, "TL": 23, "TN": 24, "TR": 26, "UA": 29,
    "VA": 22, "VG": 24, "XK": 20,
}


def _issue(
    rule_id: str,
    message: str,
    revision: int,
    *,
    severity: str = "error",
    category: str = "business",
    node: etree._Element | None = None,
    tree: etree._ElementTree | None = None,
    index: NodeIndex | None = None,
    namespace: str | None = None,
    raw_message: str | None = None,
    line: int | None = None,
) -> dict[str, object]:
    tx = ancestor_named(node, namespace, "CdtTrfTxInf") if node is not None and namespace else None
    group = ancestor_named(node, namespace, "PmtInf") if node is not None and namespace else None
    return {
        "issue_id": str(uuid4()),
        "rule_id": rule_id,
        "severity": severity,
        "category": category,
        "document_revision": revision,
        "transaction_id": index.id_for(tx) if index else None,
        "group_id": index.id_for(group) if index else None,
        "node_id": index.id_for(node) if index else None,
        "field_id": None,
        "xpath": tree.getpath(node) if tree is not None and node is not None else None,
        "location": {"view": "working", "line": line or (node.sourceline if node is not None else None), "column": None},
        "message_pl": message,
        "raw_message": raw_message,
        "source": {"kind": category},
        "expected": None,
        "actual_summary": None,
        "suggestion": None,
        "auto_fixable": False,
    }


def _node_for_error(tree: etree._ElementTree, error: etree._LogEntry) -> etree._Element | None:
    if error.path:
        try:
            nodes = tree.xpath(error.path)
            if nodes and isinstance(nodes[0], etree._Element):
                return nodes[0]
        except etree.XPathError:
            pass
    candidates = [node for node in tree.iter() if node.sourceline == error.line]
    return candidates[-1] if len(candidates) == 1 else None


def valid_iban(value: str) -> tuple[bool, str | None]:
    compact = re.sub(r"\s+", "", value).upper()
    if not re.fullmatch(r"[A-Z]{2}[0-9]{2}[A-Z0-9]+", compact):
        return False, "format"
    expected = IBAN_LENGTHS.get(compact[:2])
    if expected is not None and len(compact) != expected:
        return False, "length"
    rearranged = compact[4:] + compact[:4]
    numeric = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    return (int(numeric) % 97 == 1, None if int(numeric) % 97 == 1 else "checksum")


def valid_rf(value: str) -> bool:
    compact = re.sub(r"\s+", "", value).upper()
    if not re.fullmatch(r"RF[0-9]{2}[A-Z0-9]{1,21}", compact):
        return False
    rearranged = compact[4:] + compact[:4]
    numeric = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    return int(numeric) % 97 == 1


def validate_tree(
    tree: etree._ElementTree,
    namespace: str | None,
    adapter: Adapter | None,
    index: NodeIndex,
    revision: int,
    payload: bytes,
    *,
    validated_view: str = "working",
    profile_id: str = "iso-base",
    document_id: str | None = None,
) -> dict[str, object]:
    issues: list[dict[str, object]] = []
    layers: list[dict[str, object]] = [
        {"id": "L0", "name": "Bezpieczeństwo wejścia", "status": "pass", "checked": 1},
        {"id": "L1", "name": "Składnia XML", "status": "pass", "checked": 1},
    ]
    entry = entries().get(namespace or "")
    if entry is None or adapter is None:
        issues.append(_issue("SCHEMA_UNKNOWN", "Namespace wiadomości nie jest obsługiwany przez edytor.", revision, category="application"))
        layers.extend([
            {"id": "L2", "name": "Identyfikacja", "status": "unsupported", "checked": 1},
            {"id": "L3", "name": "ISO XSD", "status": "unsupported", "checked": 0},
            {"id": "L4", "name": "Kontrole podstawowe", "status": "not_run", "checked": 0},
            {"id": "L5", "name": "Profil bankowy", "status": "not_configured", "checked": 0},
        ])
        return _report(issues, layers, revision, payload, validated_view, None, profile_id, document_id, None)

    root_expected = f"{{{namespace}}}Document"
    root_ok = tree.getroot().tag == root_expected
    if not root_ok:
        issues.append(_issue("ROOT_QNAME", "Korzeń dokumentu nie jest elementem Document właściwej wiadomości.", revision, node=tree.getroot(), tree=tree, index=index, namespace=namespace))
    layers.append({"id": "L2", "name": "Identyfikacja", "status": "pass" if root_ok else "fail", "checked": 2})

    schema_ok, schema_errors = validate_document(namespace, tree)
    for error in schema_errors:
        node = _node_for_error(tree, error)
        issues.append(_issue(
            f"XSD_{error.type_name or 'VALIDATION'}",
            "Naruszenie schemy ISO: " + error.message,
            revision,
            category="iso_xsd",
            node=node,
            tree=tree,
            index=index,
            namespace=namespace,
            raw_message=error.message,
            line=error.line,
        ))
    layers.append({"id": "L3", "name": "ISO XSD", "status": "pass" if schema_ok else "fail", "checked": 1, "schema_sha256": entry.sha256})

    init, groups, transactions = document_nodes(tree, adapter)
    business_before = len(issues)
    all_totals = calculate(transactions, adapter)
    if not all_totals.complete:
        issues.append(_issue("TOTAL_INCOMPLETE", f"Nie można policzyć pełnej sumy: {all_totals.excluded} płatności nie ma jednoznacznej kwoty i waluty.", revision, node=init, tree=tree, index=index, namespace=namespace))
    header = adapter.child(init, "GrpHdr") if init is not None else None
    _compare_aggregates(header, all_totals, "GROUP", issues, tree, index, namespace, revision, adapter)
    for group in groups:
        _compare_aggregates(group, calculate(adapter.children(group, "CdtTrfTxInf"), adapter), "PAYMENT_INFO", issues, tree, index, namespace, revision, adapter)

    ibans = tree.findall(f".//{adapter.q('IBAN')}")
    for node in ibans:
        ok, reason = valid_iban(node.text or "")
        if not ok:
            label = "format lub długość" if reason != "checksum" else "sumę kontrolną MOD-97"
            issues.append(_issue("ACCOUNT_IBAN_CHECKSUM" if reason == "checksum" else "ACCOUNT_IBAN_FORMAT", f"IBAN ma niepoprawny {label}.", revision, node=node, tree=tree, index=index, namespace=namespace))

    for tx in transactions:
        amount = read_amount(tx, adapter)
        if amount.currency and amount.currency not in CURRENCY_CODES:
            issues.append(_issue("CURRENCY_CODE", f"Nieznany kod waluty: {amount.currency}.", revision, node=amount.node, tree=tree, index=index, namespace=namespace))
        if amount.value is not None:
            if amount.value <= 0:
                issues.append(_issue("AMOUNT_NONPOSITIVE", "Kwota płatności nie jest dodatnia.", revision, severity="warning", category="application", node=amount.node, tree=tree, index=index, namespace=namespace))
            if amount.currency in CURRENCY_CODES:
                allowed = SPECIAL_MINOR_UNITS.get(amount.currency, 2)
                fraction = max(0, -amount.value.as_tuple().exponent)
                if fraction > allowed:
                    issues.append(_issue("AMOUNT_MINOR_UNIT", f"Waluta {amount.currency} dopuszcza najwyżej {allowed} miejsc dziesiętnych.", revision, node=amount.node, tree=tree, index=index, namespace=namespace))
        ref = text_at(tx, adapter, "RmtInf/Strd/CdtrRefInf/Ref")
        if ref and ref.upper().startswith("RF") and not valid_rf(ref):
            ref_node = tx.find("/".join(adapter.q(p) for p in "RmtInf/Strd/CdtrRefInf/Ref".split("/")))
            issues.append(_issue("REFERENCE_RF_CHECKSUM", "Referencja RF ma niepoprawny format lub sumę kontrolną.", revision, node=ref_node, tree=tree, index=index, namespace=namespace))

    identifiers: list[tuple[str, etree._Element]] = []
    for tx in transactions:
        node = tx.find("/".join(adapter.q(p) for p in "PmtId/EndToEndId".split("/")))
        if node is not None and node.text and node.text != "NOTPROVIDED":
            identifiers.append((node.text, node))
    duplicate_values = {value for value, count in Counter(value for value, _ in identifiers).items() if count > 1}
    for value, node in identifiers:
        if value in duplicate_values:
            issues.append(_issue("IDENTIFIER_DUPLICATE", f"EndToEndId powtarza się w dokumencie: {value}.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    signatures: list[tuple[tuple[str, ...], etree._Element]] = []
    for tx in transactions:
        amount = read_amount(tx, adapter)
        values = (
            text_at(tx, adapter, "Cdtr/Nm") or "",
            text_at(tx, adapter, "CdtrAcct/Id/IBAN") or text_at(tx, adapter, "CdtrAcct/Id/Othr/Id") or "",
            amount.raw or "",
            amount.currency or "",
            text_at(tx, adapter, "RmtInf/Strd/CdtrRefInf/Ref") or "",
            "|".join((node.text or "") for node in tx.findall("/".join(adapter.q(part) for part in "RmtInf/Ustrd".split("/")))),
        )
        if all(values[:4]):
            signatures.append((values, tx))
    duplicate_signatures = {value for value, count in Counter(value for value, _ in signatures).items() if count > 1}
    for value, tx in signatures:
        if value in duplicate_signatures:
            issues.append(_issue("PAYMENT_POSSIBLE_DUPLICATE", "Płatność ma ten sam rachunek odbiorcy, kwotę, walutę i referencję/opis co inna pozycja.", revision, severity="warning", category="application", node=tx, tree=tree, index=index, namespace=namespace))

    suspicious = 0
    for node in tree.iter():
        if not isinstance(node.tag, str) or len(node) or node.text is None:
            continue
        value = node.text
        if "\u00a0" in value or "\t" in value or "\n" in value or value != value.strip():
            suspicious += 1
            issues.append(_issue("TEXT_SUSPICIOUS_WHITESPACE", "Pole zawiera NBSP, tabulator, nową linię albo skrajne spacje. Wartość nie została automatycznie zmieniona.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    past_dates = 0
    for group in groups:
        raw_date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        if not raw_date:
            continue
        try:
            requested = date.fromisoformat(raw_date[:10])
        except ValueError:
            continue
        if requested < date.today():
            past_dates += 1
            issues.append(_issue("DATE_IN_PAST", f"Żądana data realizacji {raw_date} jest wcześniejsza niż data analizy {date.today().isoformat()}.", revision, severity="warning", category="application", node=group, tree=tree, index=index, namespace=namespace))

    code_sets, code_metadata = external_code_sets()
    model = schema_model(namespace)
    external_checked = 0
    for node in tree.iter():
        if not isinstance(node.tag, str) or node.text is None:
            continue
        type_name = model.type_for_node(node)
        allowed = code_sets.get(type_name or "")
        if allowed is None:
            continue
        external_checked += 1
        if node.text not in allowed:
            issues.append(_issue("CODE_EXTERNAL", f"Wartość {node.text!r} nie występuje w dołączonym częściowym snapshotcie typu {type_name}. Snapshot nie ma potwierdzonego numeru wydania, dlatego wynik jest ostrzeżeniem, a nie deklaracją błędu ISO.", revision, severity="warning", category="code_set", node=node, tree=tree, index=index, namespace=namespace))

    extension_nodes = []
    for envelope in tree.findall(f".//{adapter.q('SplmtryData')}/{adapter.q('Envlp')}"):
        extension_nodes.extend(child for child in envelope if isinstance(child.tag, str) and etree.QName(child).namespace != namespace)
    for node in extension_nodes:
        issues.append(_issue("SCOPE_EXTENSION_UNVALIDATED", f"Rozszerzenie {etree.QName(node).localname!r} zostało zachowane, ale jego obca schema nie należy do pakietu walidacyjnego.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    business_errors = any(issue["severity"] == "error" for issue in issues[business_before:])
    layers.append({"id": "L4", "name": "Kontrole podstawowe", "status": "fail" if business_errors else "partial", "checked": 4 + len(ibans) + len(transactions) + external_checked, "reason": f"Zewnętrzne kody: {code_metadata['status']}; brak potwierdzonego wydania oficjalnego snapshotu."})
    if profile_id == "iso-base":
        profile_status = "not_configured"
        profile_reason = "Nie wybrano profilu bankowego; eksport obejmuje zakres ISO i kontroli podstawowych."
    elif profile_id == "epc-sct-2025-partial":
        profile_status = "partial"
        profile_reason = "Profil EPC jest częściowy i nie stanowi pełnego potwierdzenia SCT."
    else:
        profile_status = "not_configured"
        profile_reason = "Reguły tego kanału bankowego są niezweryfikowane i należą do P1."
    layers.append({"id": "L5", "name": "Profil bankowy", "status": profile_status, "checked": 0, "reason": profile_reason})
    quality_warnings = len(duplicate_signatures) + suspicious + past_dates + len(extension_nodes)
    layers.append({"id": "L6", "name": "Jakość danych", "status": "partial" if quality_warnings else "pass", "checked": len(identifiers) + len(signatures) + sum(1 for node in tree.iter() if isinstance(node.tag, str) and not len(node))})
    return _report(issues, layers, revision, payload, validated_view, entry.sha256, profile_id, document_id, code_metadata)


def _compare_aggregates(parent: etree._Element | None, totals: object, suffix: str, issues: list[dict[str, object]], tree: etree._ElementTree, index: NodeIndex, namespace: str, revision: int, adapter: Adapter) -> None:
    if parent is None:
        return
    declared_count = adapter.child(parent, "NbOfTxs")
    if declared_count is not None and declared_count.text != str(totals.count):
        issues.append(_issue(f"TOTAL_COUNT_{suffix}", f"NbOfTxs ma wartość {declared_count.text!r}, a dokument zawiera {totals.count} płatności w tym zakresie.", revision, node=declared_count, tree=tree, index=index, namespace=namespace))
    declared_sum = adapter.child(parent, "CtrlSum")
    if declared_sum is not None and totals.control_sum is not None:
        try:
            matches = Decimal(declared_sum.text or "") == totals.control_sum
        except InvalidOperation:
            matches = False
        if not matches:
            issues.append(_issue(f"TOTAL_SUM_{suffix}", f"CtrlSum ma wartość {declared_sum.text!r}, a wyliczona suma wynosi {format(totals.control_sum, 'f')}.", revision, node=declared_sum, tree=tree, index=index, namespace=namespace))


def _report(issues: list[dict[str, object]], layers: list[dict[str, object]], revision: int, payload: bytes, validated_view: str, schema_sha256: str | None, profile_id: str, document_id: str | None, code_metadata: dict[str, str] | None) -> dict[str, object]:
    errors = sum(issue["severity"] == "error" for issue in issues)
    warnings = sum(issue["severity"] == "warning" for issue in issues)
    return {
        "report_id": str(uuid4()),
        "document_id": document_id,
        "revision": revision,
        "validated_view": validated_view,
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "created_at": datetime.now(UTC).isoformat(),
        "schema_sha256": schema_sha256,
        "engine_versions": {"lxml": ".".join(map(str, etree.LXML_VERSION)), "libxml2": ".".join(map(str, etree.LIBXML_VERSION))},
        "code_set_versions": [] if code_metadata is None else [code_metadata],
        "validation_context": {"analysis_date": date.today().isoformat(), "requested_execution_date": None, "expected_inter_psp_settlement_date": None},
        "rule_bundle_id": "iso-base-2026.09",
        "profiles": [
            {"profile_id": "iso-base", "status": "implemented"},
            *([] if profile_id == "iso-base" else [{"profile_id": profile_id, "status": "partial" if profile_id == "epc-sct-2025-partial" else "unverified_p1"}]),
        ],
        "layers": layers,
        "issues": issues,
        "error_count": errors,
        "warning_count": warnings,
        "incomplete": False,
        "can_export_in_scope": errors == 0,
        "blocking_reasons": sorted({issue["rule_id"] for issue in issues if issue["severity"] == "error"}),
        "coverage": {
            "implemented": ["XML_SYNTAX", "XML_UNSAFE", "XSD_*", "TOTAL_*", "ACCOUNT_IBAN_*", "REFERENCE_RF_CHECKSUM", "CURRENCY_CODE", "AMOUNT_MINOR_UNIT", "AMOUNT_NONPOSITIVE", "IDENTIFIER_DUPLICATE", "PAYMENT_POSSIBLE_DUPLICATE", "DATE_IN_PAST", "TEXT_SUSPICIOUS_WHITESPACE", "SCOPE_EXTENSION_UNVALIDATED"],
            "not_configured": ["PROFILE_BANK", "EPC_SCT_FULL"],
            "partial": ["external_code_sets", "historical_currency_context", "iban_registry_release"],
        },
    }
