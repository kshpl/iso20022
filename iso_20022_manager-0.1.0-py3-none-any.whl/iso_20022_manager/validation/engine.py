from __future__ import annotations

import hashlib
import re
from collections import Counter
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation
from uuid import uuid4

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at
from iso_20022_manager.core.projections import document_nodes
from iso_20022_manager.core.totals import calculate, read_amount
from iso_20022_manager.core.xml_nodes import NodeIndex, ancestor_named
from iso_20022_manager.schemas.registry import entries, validate_document
from iso_20022_manager.schemas.metadata import schema_model

from .code_sets import external_code_sets, reference_data
from .bank_profiles import profile_ids as bank_profile_ids
from .bank_profiles import validate_bank_profile
from .epc import PROFILE_ID as EPC_PROFILE_ID
from .epc import validate_epc
from .mdr import validate_mdr
IBAN_LENGTHS = {
    "AD": 24, "AE": 23, "AL": 28, "AT": 20, "AZ": 28, "BA": 20, "BE": 16,
    "BG": 22, "BH": 22, "BI": 27, "BR": 29, "BY": 28, "CH": 21, "CR": 22,
    "CY": 28, "CZ": 24, "DE": 22, "DJ": 27, "DK": 18, "DO": 28, "EE": 20,
    "EG": 29, "ES": 24, "FI": 18, "FK": 18, "FO": 18, "FR": 27, "GB": 22,
    "GE": 22, "GI": 23, "GL": 18, "GR": 27, "GT": 28, "HR": 21, "HU": 28,
    "IE": 22, "IL": 23, "IQ": 23, "IS": 26, "IT": 27, "JO": 30, "KW": 30,
    "KZ": 20, "LB": 28, "LC": 32, "LI": 21, "LT": 20, "LU": 20, "LV": 21,
    "LY": 25, "MC": 27, "MD": 24, "ME": 22, "MK": 19, "MN": 20, "MR": 27,
    "MT": 31, "MU": 30, "NI": 32, "NL": 18, "NO": 15, "OM": 23, "PK": 24,
    "PL": 28, "PS": 29, "PT": 25, "QA": 29, "RO": 24, "RS": 22, "RU": 33,
    "SA": 24, "SC": 31, "SD": 18, "SE": 24, "SI": 19, "SK": 24, "SM": 27,
    "SO": 23, "ST": 25, "SV": 28, "TL": 23, "TN": 24, "TR": 26, "UA": 29,
    "VA": 22, "VG": 24, "XK": 20,
}
XMLDSIG_NAMESPACE = "http://www.w3.org/2000/09/xmldsig#"


def _issue(
    rule_id: str,
    message: str,
    revision: int,
    *,
    severity: str = "error",
    category: str = "business",
    node: etree._Element | None = None,
    tree: etree._ElementTree | None = None,
    index: NodeIndex | None = None,
    namespace: str | None = None,
    raw_message: str | None = None,
    line: int | None = None,
) -> dict[str, object]:
    tx = ancestor_named(node, namespace, "CdtTrfTxInf") if node is not None and namespace else None
    group = ancestor_named(node, namespace, "PmtInf") if node is not None and namespace else None
    return {
        "issue_id": str(uuid4()),
        "rule_id": rule_id,
        "severity": severity,
        "category": category,
        "document_revision": revision,
        "transaction_id": index.id_for(tx) if index else None,
        "group_id": index.id_for(group) if index else None,
        "node_id": index.id_for(node) if index else None,
        "field_id": None,
        "xpath": tree.getpath(node) if tree is not None and node is not None else None,
        "location": {"view": "working", "line": line or (node.sourceline if node is not None else None), "column": None},
        "message_pl": message,
        "raw_message": raw_message,
        "source": {"kind": category},
        "expected": None,
        "actual_summary": None,
        "suggestion": None,
        "auto_fixable": False,
    }


def _node_for_error(tree: etree._ElementTree, error: etree._LogEntry) -> etree._Element | None:
    if error.path:
        try:
            namespaces = {prefix: uri for prefix, uri in tree.getroot().nsmap.items() if prefix and uri}
            nodes = tree.xpath(error.path, namespaces=namespaces)
            if nodes and isinstance(nodes[0], etree._Element):
                return nodes[0]
        except etree.XPathError:
            pass
    candidates = [node for node in tree.iter() if node.sourceline == error.line]
    return candidates[-1] if len(candidates) == 1 else None


def valid_iban(value: str) -> tuple[bool, str | None]:
    compact = re.sub(r"\s+", "", value).upper()
    if not re.fullmatch(r"[A-Z]{2}[0-9]{2}[A-Z0-9]+", compact):
        return False, "format"
    expected = IBAN_LENGTHS.get(compact[:2])
    if len(compact) > 34 or (expected is not None and len(compact) != expected):
        return False, "length"
    rearranged = compact[4:] + compact[:4]
    valid = _alphanumeric_mod97(rearranged) == 1
    return valid, None if valid else "checksum"


def valid_rf(value: str) -> bool:
    compact = re.sub(r"\s+", "", value).upper()
    if not re.fullmatch(r"RF[0-9]{2}[A-Z0-9]{1,21}", compact):
        return False
    rearranged = compact[4:] + compact[:4]
    return _alphanumeric_mod97(rearranged) == 1


def _alphanumeric_mod97(value: str) -> int:
    remainder = 0
    for char in value:
        digits = str(ord(char) - 55) if char.isalpha() else char
        for digit in digits:
            remainder = (remainder * 10 + int(digit)) % 97
    return remainder


def validate_tree(
    tree: etree._ElementTree,
    namespace: str | None,
    adapter: Adapter | None,
    index: NodeIndex,
    revision: int,
    payload: bytes,
    *,
    validated_view: str = "working",
    profile_id: str = "iso-base",
    document_id: str | None = None,
    expected_inter_psp_settlement_date: date | None = None,
) -> dict[str, object]:
    issues: list[dict[str, object]] = []
    layers: list[dict[str, object]] = [
        {"id": "L0", "name": "Bezpieczeństwo wejścia", "status": "pass", "checked": 1},
        {"id": "L1", "name": "Składnia XML", "status": "pass", "checked": 1},
    ]
    entry = entries().get(namespace or "")
    if entry is None or adapter is None:
        issues.append(_issue("SCHEMA_UNKNOWN", "Namespace wiadomości nie jest obsługiwany przez edytor.", revision, category="application"))
        layers.extend([
            {"id": "L2", "name": "Identyfikacja", "status": "unsupported", "checked": 1},
            {"id": "L3", "name": "ISO XSD", "status": "unsupported", "checked": 0},
            {"id": "L4", "name": "Kontrole podstawowe", "status": "not_run", "checked": 0},
            {"id": "L5", "name": "Profil bankowy", "status": "not_configured", "checked": 0},
        ])
        return _report(issues, layers, revision, payload, validated_view, None, profile_id, document_id, None, [], None, expected_inter_psp_settlement_date)

    root_expected = f"{{{namespace}}}Document"
    root_ok = tree.getroot().tag == root_expected
    if not root_ok:
        issues.append(_issue("ROOT_QNAME", "Korzeń dokumentu nie jest elementem Document właściwej wiadomości.", revision, node=tree.getroot(), tree=tree, index=index, namespace=namespace))
    layers.append({"id": "L2", "name": "Identyfikacja", "status": "pass" if root_ok else "fail", "checked": 2})

    schema_ok, schema_errors = validate_document(namespace, tree)
    for error in schema_errors:
        node = _node_for_error(tree, error)
        issues.append(_issue(
            f"XSD_{error.type_name or 'VALIDATION'}",
            "Naruszenie schemy ISO: " + error.message,
            revision,
            category="iso_xsd",
            node=node,
            tree=tree,
            index=index,
            namespace=namespace,
            raw_message=error.message,
            line=error.line,
        ))
    layers.append({"id": "L3", "name": "ISO XSD", "status": "pass" if schema_ok else "fail", "checked": 1, "schema_sha256": entry.sha256})

    init, groups, transactions = document_nodes(tree, adapter)
    business_before = len(issues)
    for finding in validate_mdr(groups, adapter):
        issues.append(_issue(finding.rule_id, finding.message, revision, severity=finding.severity, category=finding.category, node=finding.node, tree=tree, index=index, namespace=namespace, raw_message=finding.raw_message))
    all_totals = calculate(transactions, adapter)
    if not all_totals.complete:
        issues.append(_issue("TOTAL_INCOMPLETE", f"Nie można policzyć pełnej sumy: {all_totals.excluded} płatności nie ma jednoznacznej kwoty i waluty.", revision, node=init, tree=tree, index=index, namespace=namespace))
    header = adapter.child(init, "GrpHdr") if init is not None else None
    _compare_aggregates(header, all_totals, "GROUP", issues, tree, index, namespace, revision, adapter)
    for group in groups:
        _compare_aggregates(group, calculate(adapter.children(group, "CdtTrfTxInf"), adapter), "PAYMENT_INFO", issues, tree, index, namespace, revision, adapter)

    ibans = tree.findall(f".//{adapter.q('IBAN')}")
    for node in ibans:
        ok, reason = valid_iban(node.text or "")
        if not ok:
            label = "format lub długość" if reason != "checksum" else "sumę kontrolną MOD-97"
            issues.append(_issue("ACCOUNT_IBAN_CHECKSUM" if reason == "checksum" else "ACCOUNT_IBAN_FORMAT", f"IBAN ma niepoprawny {label}.", revision, node=node, tree=tree, index=index, namespace=namespace))

    active_currencies, historic_currencies, countries, reference_versions = reference_data()
    known_currencies = set(active_currencies) | set(historic_currencies)
    for tx in transactions:
        amount = read_amount(tx, adapter)
        if amount.currency and amount.currency not in known_currencies:
            issues.append(_issue("CURRENCY_CODE", f"Nieznany kod waluty: {amount.currency}.", revision, node=amount.node, tree=tree, index=index, namespace=namespace))
        elif amount.currency in historic_currencies and amount.currency not in active_currencies:
            issues.append(_issue("CURRENCY_HISTORIC", f"Kod waluty {amount.currency} jest historyczny według ISO 4217 z 2026-01-01.", revision, severity="warning", category="code_set", node=amount.node, tree=tree, index=index, namespace=namespace))
        if amount.value is not None:
            if amount.value <= 0:
                issues.append(_issue("AMOUNT_NONPOSITIVE", "Kwota płatności nie jest dodatnia.", revision, severity="warning", category="application", node=amount.node, tree=tree, index=index, namespace=namespace))
            if amount.currency in active_currencies and active_currencies[amount.currency].get("minor_unit") is not None:
                allowed = int(active_currencies[amount.currency]["minor_unit"])
                fraction = max(0, -amount.value.normalize().as_tuple().exponent)
                if fraction > allowed:
                    issues.append(_issue("AMOUNT_MINOR_UNIT", f"Waluta {amount.currency} dopuszcza najwyżej {allowed} miejsc dziesiętnych.", revision, node=amount.node, tree=tree, index=index, namespace=namespace))
        reference_path = "/".join(adapter.q(part) for part in "RmtInf/Strd/CdtrRefInf/Ref".split("/"))
        for ref_node in tx.findall(reference_path):
            ref = ref_node.text or ""
            if ref.upper().startswith("RF") and not valid_rf(ref):
                issues.append(_issue("REFERENCE_RF_CHECKSUM", "Referencja RF ma niepoprawny format lub sumę kontrolną.", revision, node=ref_node, tree=tree, index=index, namespace=namespace))

    model = schema_model(namespace)
    country_checked = 0
    for node in tree.iter():
        if not isinstance(node.tag, str) or node.text is None or model.type_for_node(node) != "CountryCode":
            continue
        country_checked += 1
        if node.text not in countries:
            issues.append(_issue("COUNTRY_CODE", f"Kod kraju {node.text!r} nie występuje w aktywnym wykazie ISO 3166-1.", revision, category="code_set", node=node, tree=tree, index=index, namespace=namespace))

    identifiers: list[tuple[str, etree._Element]] = []
    for tx in transactions:
        node = tx.find("/".join(adapter.q(p) for p in "PmtId/EndToEndId".split("/")))
        if node is not None and node.text and node.text != "NOTPROVIDED":
            identifiers.append((node.text, node))
    duplicate_values = {value for value, count in Counter(value for value, _ in identifiers).items() if count > 1}
    for value, node in identifiers:
        if value in duplicate_values:
            issues.append(_issue("IDENTIFIER_DUPLICATE", f"EndToEndId powtarza się w dokumencie: {value}.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    signatures: list[tuple[tuple[str, ...], etree._Element]] = []
    for tx in transactions:
        amount = read_amount(tx, adapter)
        values = (
            text_at(tx, adapter, "Cdtr/Nm") or "",
            text_at(tx, adapter, "CdtrAcct/Id/IBAN") or text_at(tx, adapter, "CdtrAcct/Id/Othr/Id") or "",
            amount.raw or "",
            amount.currency or "",
            text_at(tx, adapter, "RmtInf/Strd/CdtrRefInf/Ref") or "",
            "|".join((node.text or "") for node in tx.findall("/".join(adapter.q(part) for part in "RmtInf/Ustrd".split("/")))),
        )
        if all(values[:4]):
            signatures.append((values, tx))
    duplicate_signatures = {value for value, count in Counter(value for value, _ in signatures).items() if count > 1}
    for value, tx in signatures:
        if value in duplicate_signatures:
            issues.append(_issue("PAYMENT_POSSIBLE_DUPLICATE", "Płatność ma ten sam rachunek odbiorcy, kwotę, walutę i referencję/opis co inna pozycja.", revision, severity="warning", category="application", node=tx, tree=tree, index=index, namespace=namespace))

    suspicious = 0
    for node in tree.iter():
        if not isinstance(node.tag, str) or len(node) or node.text is None:
            continue
        value = node.text
        if "\u00a0" in value or "\t" in value or "\n" in value or value != value.strip():
            suspicious += 1
            issues.append(_issue("TEXT_SUSPICIOUS_WHITESPACE", "Pole zawiera NBSP, tabulator, nową linię albo skrajne spacje. Wartość nie została automatycznie zmieniona.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    past_dates = 0
    for group in groups:
        raw_date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        if not raw_date:
            continue
        try:
            requested = date.fromisoformat(raw_date[:10])
        except ValueError:
            continue
        if requested < date.today():
            past_dates += 1
            issues.append(_issue("DATE_IN_PAST", f"Żądana data realizacji {raw_date} jest wcześniejsza niż data analizy {date.today().isoformat()}.", revision, severity="warning", category="application", node=group, tree=tree, index=index, namespace=namespace))

    code_sets, code_metadata = external_code_sets()
    external_checked = 0
    for node in tree.iter():
        if not isinstance(node.tag, str) or node.text is None:
            continue
        type_name = model.type_for_node(node)
        allowed = code_sets.get(type_name or "")
        if allowed is None:
            continue
        external_checked += 1
        if node.text not in allowed:
            issues.append(_issue("CODE_EXTERNAL", f"Wartość {node.text!r} nie występuje w oficjalnym wydaniu External Code Sets August 2026 v3 dla typu {type_name}.", revision, category="code_set", node=node, tree=tree, index=index, namespace=namespace))

    extension_nodes = []
    for envelope in tree.findall(f".//{adapter.q('SplmtryData')}/{adapter.q('Envlp')}"):
        extension_nodes.extend(child for child in envelope if isinstance(child.tag, str) and etree.QName(child).namespace != namespace)
    for node in extension_nodes:
        issues.append(_issue("SCOPE_EXTENSION_UNVALIDATED", f"Rozszerzenie {etree.QName(node).localname!r} zostało zachowane, ale jego obca schema nie należy do pakietu walidacyjnego.", revision, severity="warning", category="application", node=node, tree=tree, index=index, namespace=namespace))

    signature_nodes = [
        node for node in tree.iter()
        if isinstance(node.tag, str)
        and etree.QName(node).namespace == XMLDSIG_NAMESPACE
        and etree.QName(node).localname == "Signature"
    ]
    for node in signature_nodes:
        issues.append(_issue(
            "SIGNATURE_PRESENT_UNSUPPORTED",
            "Dokument zawiera podpis XML Signature. Edycja unieważniłaby podpis, dlatego eksport z edytora jest zablokowany.",
            revision,
            category="security",
            node=node,
            tree=tree,
            index=index,
            namespace=namespace,
        ))

    business_errors = any(issue["severity"] == "error" for issue in issues[business_before:])
    layers.append({"id": "L4", "name": "Kontrole podstawowe i MDR", "status": "fail" if business_errors else "pass", "checked": 4 + len(ibans) + len(transactions) + external_checked + country_checked, "reason": f"MDR pain.001 oraz External Code Sets: {code_metadata['snapshot_id']} ({code_metadata['status']})."})
    profile_scope: dict[str, object] | None = None
    if profile_id == "iso-base":
        profile_status = "not_configured"
        profile_reason = "Nie wybrano profilu schematu płatniczego; eksport obejmuje ISO, MDR i kontrole podstawowe."
    elif profile_id == EPC_PROFILE_ID:
        profile_start = len(issues)
        findings, profile_scope = validate_epc(tree, adapter, groups, transactions, expected_inter_psp_settlement_date)
        for finding in findings:
            issues.append(_issue(finding.rule_id, finding.message, revision, severity=finding.severity, category=finding.category, node=finding.node, tree=tree, index=index, namespace=namespace, raw_message=finding.raw_message))
        profile_issues = issues[profile_start:]
        if any(issue["severity"] == "error" for issue in profile_issues):
            profile_status = "fail"
        elif any(issue["severity"] == "warning" for issue in profile_issues):
            profile_status = "partial"
        elif profile_scope["assessed"] == 0:
            profile_status = "not_applicable"
        else:
            profile_status = "pass"
        profile_reason = f"Sprawdzono {profile_scope['assessed']} z {profile_scope['total']} płatności oznaczonych SEPA; pozostałe: poza zakresem."
    elif profile_id in bank_profile_ids():
        profile_start = len(issues)
        findings, profile_scope = validate_bank_profile(tree, adapter, groups, transactions, profile_id)
        for finding in findings:
            issues.append(_issue(finding.rule_id, finding.message, revision, severity=finding.severity, category=finding.category, node=finding.node, tree=tree, index=index, namespace=namespace, raw_message=finding.raw_message))
        profile_issues = issues[profile_start:]
        if any(issue["severity"] == "error" for issue in profile_issues):
            profile_status = "fail"
        elif any(issue["severity"] == "warning" for issue in profile_issues):
            profile_status = "partial"
        elif profile_scope["assessed"] == 0:
            profile_status = "not_applicable"
        else:
            profile_status = "pass"
        profile_reason = (
            f"Sprawdzono {profile_scope['assessed']} z {profile_scope['total']} płatności w zakresie statycznej "
            "walidacji pliku. Kontrole zależne od umowy, historii i systemu banku nie zostały wykonane."
        )
    else:
        profile_status = "not_configured"
        profile_reason = "Reguły tego kanału bankowego są niezweryfikowane i należą do P1."
    layers.append({"id": "L5", "name": "Profil schematu/banku", "status": profile_status, "checked": 0 if profile_scope is None else profile_scope["assessed"], "reason": profile_reason})
    quality_warnings = len(duplicate_signatures) + suspicious + past_dates + len(extension_nodes)
    layers.append({"id": "L6", "name": "Jakość danych", "status": "partial" if quality_warnings else "pass", "checked": len(identifiers) + len(signatures) + sum(1 for node in tree.iter() if isinstance(node.tag, str) and not len(node))})
    requested_dates = sorted({raw for group in groups for raw in [next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)] if raw})
    return _report(issues, layers, revision, payload, validated_view, entry.sha256, profile_id, document_id, code_metadata, reference_versions, profile_scope, expected_inter_psp_settlement_date, requested_dates)


def _compare_aggregates(parent: etree._Element | None, totals: object, suffix: str, issues: list[dict[str, object]], tree: etree._ElementTree, index: NodeIndex, namespace: str, revision: int, adapter: Adapter) -> None:
    if parent is None:
        return
    declared_count = adapter.child(parent, "NbOfTxs")
    if declared_count is not None and declared_count.text != str(totals.count):
        issues.append(_issue(f"TOTAL_COUNT_{suffix}", f"NbOfTxs ma wartość {declared_count.text!r}, a dokument zawiera {totals.count} płatności w tym zakresie.", revision, node=declared_count, tree=tree, index=index, namespace=namespace))
    declared_sum = adapter.child(parent, "CtrlSum")
    if declared_sum is not None and totals.control_sum is not None:
        try:
            matches = Decimal(declared_sum.text or "") == totals.control_sum
        except InvalidOperation:
            matches = False
        if not matches:
            issues.append(_issue(f"TOTAL_SUM_{suffix}", f"CtrlSum ma wartość {declared_sum.text!r}, a wyliczona suma wynosi {format(totals.control_sum, 'f')}.", revision, node=declared_sum, tree=tree, index=index, namespace=namespace))


def _report(issues: list[dict[str, object]], layers: list[dict[str, object]], revision: int, payload: bytes, validated_view: str, schema_sha256: str | None, profile_id: str, document_id: str | None, code_metadata: dict[str, str] | None, reference_versions: list[dict[str, str]], profile_scope: dict[str, object] | None, expected_inter_psp_settlement_date: date | None, requested_dates: list[str] | None = None) -> dict[str, object]:
    errors = sum(issue["severity"] == "error" for issue in issues)
    warnings = sum(issue["severity"] == "warning" for issue in issues)
    return {
        "report_id": str(uuid4()),
        "document_id": document_id,
        "revision": revision,
        "validated_view": validated_view,
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "created_at": datetime.now(UTC).isoformat(),
        "schema_sha256": schema_sha256,
        "engine_versions": {"lxml": ".".join(map(str, etree.LXML_VERSION)), "libxml2": ".".join(map(str, etree.LIBXML_VERSION))},
        "code_set_versions": ([] if code_metadata is None else [code_metadata]) + reference_versions,
        "validation_context": {"analysis_date": date.today().isoformat(), "requested_execution_date": (requested_dates or [None])[0] if len(requested_dates or []) <= 1 else None, "requested_execution_dates": requested_dates or [], "expected_inter_psp_settlement_date": expected_inter_psp_settlement_date.isoformat() if expected_inter_psp_settlement_date else None},
        "rule_bundle_id": "iso-pain001-mdr-2026.09",
        "profiles": [
            {"profile_id": "iso-base", "status": "implemented"},
            *([] if profile_id == "iso-base" else [{"profile_id": profile_id, "status": "implemented" if profile_id == EPC_PROFILE_ID or profile_id in bank_profile_ids() else "unverified_p1"}]),
        ],
        "profile_scope": profile_scope,
        "layers": layers,
        "issues": issues,
        "error_count": errors,
        "warning_count": warnings,
        "incomplete": False,
        "can_export_in_scope": errors == 0,
        "blocking_reasons": sorted({issue["rule_id"] for issue in issues if issue["severity"] == "error"}),
        "coverage": {
            "implemented": ["XML_SYNTAX", "XML_UNSAFE", "XSD_*", "MDR_*", "TOTAL_*", "ACCOUNT_IBAN_*", "REFERENCE_RF_CHECKSUM", "CURRENCY_CODE", "COUNTRY_CODE", "AMOUNT_MINOR_UNIT", "AMOUNT_NONPOSITIVE", "CODE_EXTERNAL", "IDENTIFIER_DUPLICATE", "PAYMENT_POSSIBLE_DUPLICATE", "DATE_IN_PAST", "TEXT_SUSPICIOUS_WHITESPACE", "SCOPE_EXTENSION_UNVALIDATED", "SIGNATURE_PRESENT_UNSUPPORTED", "EPC_TVS_*", "EPC_ADDRESS_*", "PROFILE_BANK_STATIC_*"],
            "not_configured": [] if profile_id in bank_profile_ids() else ["PROFILE_BANK"],
            "partial": ["iban_registry_release"],
        },
    }
