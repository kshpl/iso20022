"""Source-bound text rules on exact, namespace-qualified XML paths.

Selectors intentionally exclude technical payment codes, dates, BICs, email and
arbitrary extensions. A shared group/header is assessed for each consuming
product, but a transaction is never assessed using a sibling's product.
"""
from string import ascii_letters, digits
import unicodedata

from lxml import etree

from iso_20022_manager.core.adapters import text_at
from iso_20022_manager.core.totals import read_amount

from .bank_context import is_mail, rule_source, seb_country, seb_domestic
from .findings import Finding


ASCII = set(ascii_letters + digits)
LATIN = ASCII | set("/-?:().,'+ ")
NORDIC = set("åäæöøÅÄÆÖØ")
PL = set("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ")
ADDRESS = ("Dept", "SubDept", "StrtNm", "BldgNb", "BldgNm", "Flr", "Room", "PstBx", "PstCd", "TwnNm", "TwnLctnNm", "DstrctNm", "CtrySubDvsn", "AdrLine")


def _party_paths(party):
    return {f"{party}/Nm", *(f"{party}/PstlAdr/{tag}" for tag in ADDRESS),
            *(f"{party}/Id/{kind}/Othr/Id" for kind in ("OrgId", "PrvtId"))}


HEADER_PATHS = {"MsgId"} | _party_paths("InitgPty")
GROUP_PATHS = {"PmtInfId", "DbtrAcct/Nm"} | _party_paths("Dbtr") | _party_paths("UltmtDbtr")
TX_PATHS = {"PmtId/InstrId", "PmtId/EndToEndId", "CdtrAcct/Nm", "RmtInf/Ustrd", "InstrForDbtrAgt", "InstrForCdtrAgt/InstrInf",
            "RmtInf/Strd/AddtlRmtInf", "RmtInf/Strd/CdtrRefInf/Ref", "RmtInf/Strd/RfrdDocInf/Nb"}
for _party in ("Cdtr", "UltmtCdtr", "UltmtDbtr"):
    TX_PATHS |= _party_paths(_party)
for _agent in ("CdtrAgt", "IntrmyAgt1", "IntrmyAgt2", "IntrmyAgt3"):
    TX_PATHS |= {f"{_agent}/FinInstnId/Nm", *(f"{_agent}/FinInstnId/PstlAdr/{tag}" for tag in ADDRESS)}
for _tax in ("Tax", "RmtInf/Strd/TaxRmt"):
    TX_PATHS |= {f"{_tax}/RefNb", f"{_tax}/AdmstnZn", f"{_tax}/Rcrd/AddtlInf", f"{_tax}/Rcrd/FrmsCd",
                 *(f"{_tax}/{party}/{tag}" for party in ("Dbtr", "Cdtr") for tag in ("TaxId", "RegnId"))}


def _text_nodes(parent, adapter, paths):
    if parent is None:
        return
    for path in sorted(paths):
        for node in parent.findall("/".join(adapter.q(tag) for tag in path.split("/"))):
            if not len(node) and node.text:
                yield path, node


def _diacritic(char):
    return (ord(char) > 127 and "LATIN" in unicodedata.name(char, "")) or unicodedata.category(char).startswith("M")


def validate_bank_charsets(tree, adapter, groups, profile_id):
    from .bank_profiles import _citi_variant, _is_sepa, _node

    findings, seen = [], set()
    header = _node(tree.getroot(), adapter, "CstmrCdtTrfInitn/GrpHdr")
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            sepa = _is_sepa(group, tx, adapter, ing_pl=profile_id == "ing-business-pl-2026")
            currency = read_amount(tx, adapter).currency
            iban = text_at(tx, adapter, "CdtrAcct/Id/IBAN") or ""
            foreign = sepa or currency not in {None, "PLN"} or (iban and not iban.startswith("PL"))
            product = "sepa" if sepa else "foreign" if foreign else "domestic"
            allowed, forbidden, predicate = None, set(), None
            severity, kind, ref = "error", "bank_requirement", ""
            if profile_id == "mbank-companynet-2026":
                mail = is_mail(tx, adapter)
                product = "MAIL" if mail else product
                forbidden = set(";") if mail else set(":*;‘“!+?|#")
                allowed = ASCII | set("/-()., ") if foreign and not mail else None
                rule, ref = "MBANK_COMPANYNET_FORBIDDEN_CHAR", "PDF s. 3–4 §8.1–8.4; MAIL s. 31–32"
            elif profile_id == "mbank-swiftnet-2026":
                allowed = LATIN | set("{}")
                rule, ref = "MBANK_SWIFTNET_CHARSET", "PDF s. 3 pkt 9, s. 4 §4"
                kind = "application_data_loss_policy"
            elif profile_id == "ing-business-pl-2026":
                forbidden = set('|”') if not foreign else set('*;“!|#')
                def predicate(char):
                    return char in LATIN or (not sepa and char.isalpha())
                rule, ref = "ING_PL_CHARSET", "PDF s. 20 IV.A"
            elif profile_id == "santander-ibiznes24-2026":
                def predicate(char):
                    return char in LATIN or (not sepa and char.isalpha())
                rule, ref = "SANTANDER_IBIZNES24_CHARSET", "PDF s. 106; tabele .09 s. 128–197"
            elif profile_id == "bnp-goonline-business-2026":
                if not foreign:
                    continue
                def predicate(char):
                    return not _diacritic(char)
                rule = "BNP_GOONLINE_SEPA_CHARSET" if sepa else "BNP_GOONLINE_FOREIGN_CHARSET"
                ref = "PDF s. 58 §8 XML V2" if sepa else "PDF s. 46 §7 XML V2 (&amp; po parsowaniu = &)"
            elif profile_id == "pko-ipko-business-pl-2026":
                allowed = ASCII | PL | set("/ -().,")
                rule, ref = "PKO_IPKO_PL_CHARSET", "PDF s. 6; tabele s. 9–29"
            elif profile_id.startswith("ing-insidebusiness-"):
                allowed = LATIN
                rule, ref = f"ING_INSIDE_{profile_id.split('-')[-2].upper()}_CHARSET", "OneXML 5.0 s. 3; Credit Transfers s. 4–17"
            elif profile_id.startswith("seb-"):
                country = seb_country(profile_id)
                domestic = seb_domestic(group, tx, adapter, country)
                product = "domestic" if domestic else "cross_border_or_unclassified"
                allowed = LATIN | NORDIC if domestic else LATIN
                severity = "error" if domestic else "warning"
                kind = "bank_requirement" if domestic else "bank_recommendation"
                rule, ref = f"SEB_{country}_CHARSET", "MIG 26.4 PDF s. 8 §1.3 (should not dla międzynarodowych)"
            elif profile_id == "citidirect-pl-2026":
                product = _citi_variant(group, tx, adapter)
                if product in {"795_PL_SEPA", "938_PL_SEPA"}:
                    # GOLD does not link a CharSet for these sheets. Do not invent
                    # a CBFT restriction (AdrLine explicitly permits special chars).
                    findings.append(Finding("CITI_PL_SEPA_CHARSET_UNVERIFIED", "GOLD nie wskazuje tabeli CharSet dla tego PIUID SEPA; nie potwierdzono bankowego alfabetu pól. Pozostałe kontrole ISO/profilu nadal działają.", tx, severity="warning", category="profile", source=rule_source(profile_id, f"GOLD {product}, brak odnośnika CharSet; AdrLine N125/N656 dopuszcza special characters", product=product, kind="unverified_source")))
                    continue
                cbft = product == "574_PL_WIRE"
                allowed = ASCII | set(" /-?().+‘,") | (set() if cbft else PL)
                if product == "984_PL_VAT":
                    allowed |= {"_"}
                rule = "CITI_PL_CHARSET"
                table = "CBFT_CE" if cbft else "CE"
                suffix = "_v1" if product == "984_PL_VAT" else ""
                ref = f"GOLD {product}!N107/N325; {table}-SupPay-CharSet-Poland{suffix}.xlsx!B4:L16 (J11=U+2018)"
            else:
                continue

            source = rule_source(profile_id, ref, product=product, kind=kind, current_seb=profile_id.startswith("seb-"))
            for parent, paths in ((header, HEADER_PATHS), (group, GROUP_PATHS), (tx, TX_PATHS)):
                for path, node in _text_nodes(parent, adapter, paths):
                    field_allowed = allowed
                    field_rule = rule
                    if profile_id == "mbank-companynet-2026" and is_mail(tx, adapter) and path == "InstrForDbtrAgt":
                        # Six documented postal subfields are separated by |.
                        invalid = set(node.text) & {";"}
                    else:
                        if profile_id == "citidirect-pl-2026" and path == "PmtId/EndToEndId":
                            field_allowed = allowed - {"_"}
                            if product == "574_PL_WIRE":
                                field_allowed = field_allowed - set(ascii_letters[:26])
                                field_rule = "CITI_PL_WIRE_REFERENCE_CHARSET"
                            elif "_" in node.text:
                                field_rule = "CITI_PL_REFERENCE_UNDERSCORE"
                        invalid = set(node.text) & forbidden
                        if field_allowed is not None:
                            invalid |= set(node.text) - field_allowed
                        if predicate:
                            invalid |= {char for char in node.text if not predicate(char)}
                    identity = (node, field_rule, severity)
                    if invalid and identity not in seen:
                        seen.add(identity)
                        shown = " ".join(repr(char) for char in sorted(invalid)[:8])
                        policy = "Ochrona aplikacji przed zastąpieniem znaków spacjami przez bank" if kind == "application_data_loss_policy" else "Zalecenie banku" if severity == "warning" else "Zestaw znaków banku"
                        findings.append(Finding(field_rule, f"{policy} ({product}): niedozwolone/niezalecane znaki {shown}. Źródło: {ref}.", node, severity=severity, category="profile", source={**source, "message_identifier": adapter.message_identifier, "xml_path": f"{etree.QName(parent).localname}/{path}"}))
    return findings
