"""Validation engine and basic rules."""
