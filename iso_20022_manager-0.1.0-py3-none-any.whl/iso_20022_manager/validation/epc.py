from __future__ import annotations

import hashlib
import json
import threading
from copy import deepcopy
from datetime import date
from functools import lru_cache
from importlib.resources import files

from lxml import etree

from iso_20022_manager.core.adapters import Adapter, text_at
from iso_20022_manager.core.xml_nodes import ancestor_named

from .findings import Finding

PROFILE_ID = "epc-sct-2025"
SUPPORTED_MESSAGE = "pain.001.001.09"
_lock = threading.RLock()


@lru_cache(maxsize=1)
def profile_manifest() -> dict[str, object]:
    root = files("iso_20022_manager").joinpath("resources", "profiles", PROFILE_ID)
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    payload = root.joinpath(str(manifest["xsd_local_path"])).read_bytes()
    if hashlib.sha256(payload).hexdigest() != manifest["xsd_sha256"]:
        raise RuntimeError("Niezgodny hash schemy profilu EPC SCT.")
    return manifest


@lru_cache(maxsize=1)
def compiled_schema() -> etree.XMLSchema:
    root = files("iso_20022_manager").joinpath("resources", "profiles", PROFILE_ID)
    manifest = profile_manifest()
    parser = etree.XMLParser(resolve_entities=False, load_dtd=False, no_network=True)
    schema_root = etree.fromstring(root.joinpath(str(manifest["xsd_local_path"])).read_bytes(), parser)
    return etree.XMLSchema(etree.ElementTree(schema_root))


def _single_transaction_tree(
    tree: etree._ElementTree,
    adapter: Adapter,
    group_position: int,
    transaction_position: int,
) -> etree._ElementTree:
    root = deepcopy(tree.getroot())
    init = root.find(adapter.q("CstmrCdtTrfInitn"))
    assert init is not None
    groups = init.findall(adapter.q("PmtInf"))
    selected_group = groups[group_position]
    for group in groups:
        if group is not selected_group:
            init.remove(group)
    transactions = selected_group.findall(adapter.q("CdtTrfTxInf"))
    selected_tx = transactions[transaction_position]
    for tx in transactions:
        if tx is not selected_tx:
            selected_group.remove(tx)
    return etree.ElementTree(root)


def _uses_unstructured_address(party: etree._Element | None, adapter: Adapter) -> etree._Element | None:
    if party is None:
        return None
    address = party.find(adapter.q("PstlAdr"))
    if address is not None and address.find(adapter.q("AdrLine")) is not None:
        return address
    return None


def validate_epc(
    tree: etree._ElementTree,
    adapter: Adapter,
    groups: list[etree._Element],
    transactions: list[etree._Element],
    expected_inter_psp_settlement_date: date | None,
) -> tuple[list[Finding], dict[str, object]]:
    manifest = profile_manifest()
    if adapter.message_identifier != SUPPORTED_MESSAGE:
        return [Finding("EPC_VERSION_UNSUPPORTED", "Profil EPC SCT 2025 obsługuje wyłącznie pain.001.001.09.", tree.getroot(), category="profile")], {
            "profile_id": PROFILE_ID, "assessed": 0, "not_applicable": len(transactions), "total": len(transactions),
        }

    selected: list[tuple[int, int, etree._Element]] = []
    for group_position, group in enumerate(groups):
        group_service = text_at(group, adapter, "PmtTpInf/SvcLvl/Cd")
        for transaction_position, tx in enumerate(group.findall(adapter.q("CdtTrfTxInf"))):
            tx_service = text_at(tx, adapter, "PmtTpInf/SvcLvl/Cd")
            if group_service == "SEPA" or tx_service == "SEPA":
                selected.append((group_position, transaction_position, tx))

    findings: list[Finding] = []
    schema = compiled_schema()
    seen: set[tuple[int, str, str]] = set()
    for group_position, transaction_position, tx in selected:
        candidate = _single_transaction_tree(tree, adapter, group_position, transaction_position)
        with _lock:
            schema.validate(candidate)
            errors = list(schema.error_log)
        for error in errors:
            key = (id(tx), error.type_name or "VALIDATION", error.message)
            if key in seen:
                continue
            seen.add(key)
            findings.append(Finding(
                f"EPC_TVS_{error.type_name or 'VALIDATION'}",
                "Naruszenie profilu EPC SCT: " + error.message,
                tx,
                category="profile",
                raw_message=error.message,
            ))

        deadline = date.fromisoformat(str(manifest["address_deadline"]))
        parties = [
            ancestor_named(tx, adapter.namespace, "PmtInf").find(adapter.q("Dbtr")),
            tx.find(adapter.q("Cdtr")),
            tx.find(adapter.q("UltmtCdtr")),
        ]
        for party in parties:
            address = _uses_unstructured_address(party, adapter)
            if address is None:
                continue
            if expected_inter_psp_settlement_date is None:
                findings.append(Finding(
                    "EPC_ADDRESS_DATE_UNVERIFIABLE",
                    "Adres nieustrukturyzowany wymaga oceny względem daty rozrachunku między PSP; tej daty nie podano.",
                    address,
                    severity="warning",
                    category="profile",
                ))
            elif expected_inter_psp_settlement_date >= deadline:
                findings.append(Finding(
                    "EPC_ADDRESS_UNSTRUCTURED_AFTER_DEADLINE",
                    f"Adres nieustrukturyzowany nie jest dozwolony dla rozrachunku od {deadline.isoformat()}.",
                    address,
                    category="profile",
                ))

    return findings, {
        "profile_id": PROFILE_ID,
        "assessed": len(selected),
        "not_applicable": len(transactions) - len(selected),
        "total": len(transactions),
        "xsd_sha256": manifest["xsd_sha256"],
        "rulebook_version": manifest["rulebook_version"],
        "implementation_guideline_version": manifest["implementation_guideline_version"],
    }
