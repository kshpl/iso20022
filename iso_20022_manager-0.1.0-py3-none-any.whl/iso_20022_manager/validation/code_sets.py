from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from importlib.resources import files


@lru_cache(maxsize=1)
def external_code_sets() -> tuple[dict[str, set[str]], dict[str, str]]:
    root = files("iso_20022_manager").joinpath("resources", "code_sets")
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    entry = manifest["snapshots"][0]
    payload = root.joinpath(entry["local_path"]).read_bytes()
    if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
        raise RuntimeError("Niezgodny hash snapshotu zewnętrznych list kodów.")
    raw = json.loads(payload)
    sets = {
        name: set(definition.get("enum", []))
        for name, definition in raw.get("definitions", {}).items()
        if name.startswith("External") and definition.get("enum")
    }
    metadata = {
        "snapshot_id": entry["id"],
        "status": entry["verification_status"],
        "sha256": entry["sha256"],
    }
    return sets, metadata
