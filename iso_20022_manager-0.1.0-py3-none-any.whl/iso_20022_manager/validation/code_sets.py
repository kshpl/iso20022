from __future__ import annotations

import hashlib
import json
import re
from functools import lru_cache
from importlib.resources import files


@lru_cache(maxsize=1)
def external_code_sets() -> tuple[dict[str, set[str]], dict[str, str]]:
    root = files("iso_20022_manager").joinpath("resources", "code_sets")
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    entry = manifest["snapshots"][0]
    payload = root.joinpath(entry["local_path"]).read_bytes()
    if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
        raise RuntimeError("Niezgodny hash snapshotu zewnętrznych list kodów.")
    raw = json.loads(payload)
    sets = {
        name: set(definition.get("enum", []))
        for name, definition in raw.get("definitions", {}).items()
        if name.startswith("External") and definition.get("enum")
    }
    metadata = {
        "snapshot_id": entry["id"],
        "status": entry["verification_status"],
        "sha256": entry["sha256"],
    }
    return sets, metadata


@lru_cache(maxsize=1)
def external_code_catalog() -> tuple[dict[str, list[dict[str, str]]], dict[str, str]]:
    root = files("iso_20022_manager").joinpath("resources", "code_sets")
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    entry = manifest["snapshots"][0]
    payload = root.joinpath(entry["local_path"]).read_bytes()
    if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
        raise RuntimeError("Niezgodny hash snapshotu zewnętrznych list kodów.")
    raw = json.loads(payload)
    catalog: dict[str, list[dict[str, str]]] = {}
    for name, definition in raw.get("definitions", {}).items():
        values = definition.get("enum", [])
        if not name.startswith("External") or not values:
            continue
        descriptions: dict[str, str] = {}
        for line in str(definition.get("description", "")).splitlines():
            match = re.match(r"\s*\*`?([A-Z0-9]{1,8})`?\s*[-–]\s*(.+?)\s*$", line)
            if match:
                descriptions[match.group(1)] = match.group(2)
        catalog[name] = [{"code": code, "description": descriptions.get(code, "")} for code in values]
    metadata = {"snapshot_id": entry["id"], "status": entry["verification_status"], "sha256": entry["sha256"]}
    return catalog, metadata


@lru_cache(maxsize=1)
def reference_data() -> tuple[dict[str, dict[str, object]], dict[str, dict[str, object]], set[str], list[dict[str, str]]]:
    root = files("iso_20022_manager").joinpath("resources", "reference_data")
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    loaded: dict[str, dict[str, object]] = {}
    versions: list[dict[str, str]] = []
    for entry in manifest["snapshots"]:
        payload = root.joinpath(entry["local_path"]).read_bytes()
        if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
            raise RuntimeError(f"Niezgodny hash danych referencyjnych {entry['id']}.")
        loaded[entry["kind"]] = json.loads(payload)
        versions.append({
            "snapshot_id": entry["id"],
            "status": entry["verification_status"],
            "sha256": entry["sha256"],
        })
    currencies = loaded["currency_codes_and_minor_units"]
    countries = loaded["country_alpha2_codes"]
    return (
        currencies["active"],
        currencies["historic"],
        set(str(countries["active_alpha2"]).split()),
        versions,
    )
