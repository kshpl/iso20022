"""Checks possible on imported SEB XML, without guessing receiver agreements."""
import re

from iso_20022_manager.core.adapters import text_at
from iso_20022_manager.core.reference_checks import mod10_ok, mod11_ok

from .bank_context import rule_source, seb_country, seb_domestic
from .findings import Finding


def validate_seb_references(adapter, groups, profile_id):
    from .bank_profiles import _local_instrument, _node

    country = seb_country(profile_id)
    findings = []
    for group in groups:
        for tx in group.findall(adapter.q("CdtTrfTxInf")):
            for reference in tx.findall("/".join(adapter.q(tag) for tag in ("RmtInf", "Strd", "CdtrRefInf"))):
                if text_at(reference, adapter, "Tp/CdOrPrtry/Cd") != "SCOR" or text_at(reference, adapter, "Tp/Issr") == "ISO":
                    continue
                ref = _node(reference, adapter, "Ref")
                if not seb_domestic(group, tx, adapter, country):
                    findings.append(Finding(f"SEB_{country}_REFERENCE_PRODUCT_UNCLASSIFIED", "Referencja SCOR bez Issr=ISO: kontekst nie potwierdza krajowego OCR/KID/formularza DK. Nie przypisano algorytmu ani krajowego limitu.", ref if ref is not None else reference, severity="warning", category="profile", source=rule_source(profile_id, "PDF s. 58 Nordic Usage", product="unclassified_SCOR", kind="unverified_product", current_seb=True)))
                    continue
                value = ref.text or "" if ref is not None else ""
                instrument = _local_instrument(group, tx, adapter)
                product = "OCR" if country == "SE" else "KID" if country == "NO" else instrument
                if country == "DK" and instrument not in {"IBK04", "IBK15", "IBK71", "IBK75"}:
                    continue
                source = rule_source(profile_id, "PDF s. 58 Nordic Usage; DK s. 86 §7.2; XLSX AK540/BC551/AE551", product=product, current_seb=True)
                prefix = f"SEB_{country}_{product}"
                node = ref if ref is not None else reference
                if not re.fullmatch(r"[0-9]+", value):
                    findings.append(Finding(f"{prefix}_DIGITS", f"{product}: referencja musi zawierać wyłącznie cyfry ASCII 0–9.", node, category="profile", source=source))
                    continue
                if country == "SE" and 2 <= len(value) <= 25 and not mod10_ok(value):
                    findings.append(Finding(f"{prefix}_CHECKSUM", "OCR: niepoprawna cyfra kontrolna MOD-10.", node, category="profile", source=source))
                if country == "NO" and 2 <= len(value) <= 25 and not (mod10_ok(value) or mod11_ok(value)):
                    findings.append(Finding(f"{prefix}_CHECKSUM", "KID nie przechodzi ani MOD-10, ani MOD-11. Algorytm umowy nie jest znany — nie wybieramy go automatycznie.", node, category="profile", source=source))
                if country in {"NO", "SE"}:
                    notice = "Sprawdzono cyfry, zakres 2–25 i MOD-10. Nie sprawdzono umownego trybu długości OCR (none/fixed/variable), którego XML nie określa." if country == "SE" else "Sprawdzono cyfry, zakres 2–25 i możliwość MOD-10/MOD-11. XML nie określa algorytmu umowy ani konfiguracji odbiorcy; zgodności umownej nie potwierdzono."
                    findings.append(Finding(f"{prefix}_AGREEMENT_UNVERIFIED", notice, node, severity="warning", category="profile", source={**source, "kind": "unverified_agreement"}))
    return findings
