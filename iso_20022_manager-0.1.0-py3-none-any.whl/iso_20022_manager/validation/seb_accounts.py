"""SEB MIG 26.4.0.1, Annex 5: Swedish national account numbers."""
import re

from iso_20022_manager.core.adapters import text_at

from .bank_context import rule_source, seb_domestic
from .findings import Finding


def swedish_bban_issue(value: str, clearing: str | None = None) -> tuple[str, str, str] | None:
    if not re.fullmatch(r"[0-9]+", value):
        return "FORMAT", "Szwedzki BBAN wymaga samych cyfr bez spacji i myślników.", "error"

    # A 9- or 10-digit account can omit clearing altogether. Its first
    # digits cannot identify the bank. Longer forms include clearing.
    prefix = clearing or (value[:4] if len(value) >= 11 else "")
    leading = prefix[:4]
    if prefix.startswith("8"):
        valid = len(value) == 15 and value.startswith(prefix) and bool(re.fullmatch(r"8[0-9]{3,4}", prefix))
        expected = "15 cyfr, w tym pełny pięciocyfrowy clearing Swedbank 8xxxx"
    elif "6000" <= leading <= "6999" and len(leading) == 4:
        valid = len(value) == 9 or (len(value) == 13 and value.startswith(leading))
        expected = "9 cyfr bez clearingu Handelsbanken lub 13 cyfr z clearingiem"
    elif leading in {"3300", "3782"}:
        valid = len(value) == 10 or (len(value) == 14 and value.startswith(leading))
        expected = "10 cyfr Nordea Personkonto lub 14 cyfr z clearingiem"
    elif "9180" <= leading <= "9189":
        valid = len(value) == 10
        expected = "10 cyfr bez clearingu Danske Bank 9180–9189"
    elif "9570" <= leading <= "9579":
        valid = len(value) == 14 and value.startswith(leading)
        expected = "14 cyfr z clearingiem Sparbanken Syd 9570–9579"
    elif leading == "9960":
        valid = value.startswith(leading) and len(value) > 4
        expected = "clearing 9960 i numer powiązanego rachunku, zgodnie z załącznikiem 5 SEB"
    elif not prefix and len(value) in {9, 10}:
        return "CLEARING_UNVERIFIED", "Krótki szwedzki BBAN może pomijać clearing. Potwierdź bank i format numeru rachunku.", "warning"
    else:
        valid = len(value) == 11 and (not clearing or value.startswith(clearing))
        expected = "11 cyfr, w tym czterocyfrowy clearing"
    return None if valid else ("FORMAT", f"Szwedzki BBAN wymaga formatu: {expected}.", "error")


def validate_swedish_bban(group, tx, adapter):
    """Apply Annex 5 only to known Swedish accounts, excluding giro aliases."""
    debtor = tx is None
    role = "Dbtr" if debtor else "Cdtr"
    owner = group if debtor else tx
    account = adapter.child(owner, f"{role}Acct")
    if account is None or text_at(account, adapter, "Id/Othr/SchmeNm/Cd") != "BBAN":
        return None
    prefix = f"{role}Agt/FinInstnId"
    member = text_at(owner, adapter, f"{prefix}/ClrSysMmbId/MmbId")
    clearing = member if re.fullmatch(r"(?:[0-9]{4}|8[0-9]{4})", member or "") else None
    if text_at(account, adapter, "Prxy/Tp/Prtry") in {"BGNR", "PGNR"} or clearing in {"9900", "9960"}:
        # The legacy giro representation with a clearing member carries
        # the giro number itself, whereas Annex 5 describes the linked BBAN.
        return None
    bic = text_at(owner, adapter, f"{prefix}/{adapter.bic_tag}")
    if bic and bic[4:6] != "SE":
        return None
    swedish_clearing = clearing is not None and text_at(owner, adapter, f"{prefix}/ClrSysMmbId/ClrSysId/Cd") == "SESBA"
    if not debtor and not swedish_clearing and not seb_domestic(group, tx, adapter, "SE"):
        return None
    node = account.find("/".join(adapter.q(tag) for tag in ("Id", "Othr", "Id")))
    if node is None:
        return None
    issue = swedish_bban_issue(node.text or "", clearing)
    if issue is None:
        return None
    code, message, severity = issue
    return Finding(
        f"SEB_SE_BBAN_{code}", message, node, severity=severity, category="profile",
        source=rule_source("seb-sweden-2026", "MIG PDF s. 100, załącznik 5", product="swedish_bban", current_seb=True),
    )
