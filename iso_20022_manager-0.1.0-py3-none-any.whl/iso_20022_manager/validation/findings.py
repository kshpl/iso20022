from __future__ import annotations

from dataclasses import dataclass

from lxml import etree


@dataclass(frozen=True)
class Finding:
    rule_id: str
    message: str
    node: etree._Element | None
    severity: str = "error"
    category: str = "business"
    raw_message: str | None = None
