from __future__ import annotations

from collections import defaultdict
from lxml import etree

from .adapters import Adapter, text_at
from .totals import calculate, decimal_text, read_amount
from .xml_nodes import NodeIndex, node_tree
from iso_20022_manager.schemas.metadata import schema_model


def _account(parent: etree._Element | None, adapter: Adapter) -> dict[str, str | None] | None:
    if parent is None:
        return None
    ident = adapter.child(parent, "Id")
    if ident is None:
        return None
    iban = adapter.child(ident, "IBAN")
    other = adapter.child(ident, "Othr")
    if iban is not None and other is None:
        return {"kind": "iban", "value": iban.text, "scheme_code": None}
    if other is not None and iban is None:
        scheme = text_at(other, adapter, "SchmeNm/Cd") or text_at(other, adapter, "SchmeNm/Prtry")
        return {"kind": "other", "value": text_at(other, adapter, "Id"), "scheme_code": scheme}
    return {"kind": "invalid", "value": None, "scheme_code": None}


def document_nodes(tree: etree._ElementTree, adapter: Adapter) -> tuple[etree._Element | None, list[etree._Element], list[etree._Element]]:
    init = adapter.child(tree.getroot(), "CstmrCdtTrfInitn")
    if init is None:
        return None, [], []
    groups = adapter.children(init, "PmtInf")
    return init, groups, [tx for group in groups for tx in adapter.children(group, "CdtTrfTxInf")]


def summary(tree: etree._ElementTree, adapter: Adapter, index: NodeIndex, issue_counts: dict[str, tuple[int, int]] | None = None) -> dict[str, object]:
    issue_counts = issue_counts or {}
    init, groups, transactions = document_nodes(tree, adapter)
    header = adapter.child(init, "GrpHdr") if init is not None else None
    totals = calculate(transactions, adapter)
    group_views = []
    order = 0
    payment_views = []
    for group in groups:
        txs = adapter.children(group, "CdtTrfTxInf")
        gtotals = calculate(txs, adapter)
        gid = index.id_for(group)
        date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        group_views.append({
            "group_id": gid,
            "node_id": gid,
            "payment_info_id": text_at(group, adapter, "PmtInfId"),
            "debtor_name": text_at(group, adapter, "Dbtr/Nm"),
            "account": _account(adapter.child(group, "DbtrAcct"), adapter),
            "execution_date": date,
            "payment_method": text_at(group, adapter, "PmtMtd"),
            "transaction_count": len(txs),
            "totals": totals_json(gtotals),
        })
        for tx in txs:
            order += 1
            tid = index.id_for(tx)
            amount = read_amount(tx, adapter)
            ustrd = [n.text or "" for n in tx.findall("/".join(adapter.q(p) for p in ("RmtInf", "Ustrd")))]
            structured = tx.find("/".join(adapter.q(p) for p in ("RmtInf", "Strd"))) is not None
            errors, warnings = issue_counts.get(tid or "", (0, 0))
            payment_views.append({
                "transaction_id": tid,
                "group_id": gid,
                "node_id": tid,
                "original_order": order,
                "creditor_name": text_at(tx, adapter, "Cdtr/Nm"),
                "account": _account(adapter.child(tx, "CdtrAcct"), adapter),
                "amount": {"kind": amount.kind, "raw_value": amount.raw, "value": decimal_text(amount.value) if amount.value is not None else None, "currency": amount.currency},
                "end_to_end_id": text_at(tx, adapter, "PmtId/EndToEndId"),
                "remittance_summary": " | ".join(ustrd) or ("Dane strukturalne" if structured else ""),
                "is_draft": amount.value is None or not text_at(tx, adapter, "PmtId/EndToEndId"),
                "error_count": errors,
                "warning_count": warnings,
                "execution_date": date,
                "payment_info_id": text_at(group, adapter, "PmtInfId"),
            })
    return {
        "header": {
            "message_reference": text_at(header, adapter, "MsgId"),
            "creation_datetime": text_at(header, adapter, "CreDtTm"),
            "initiating_party": text_at(header, adapter, "InitgPty/Nm"),
            "declared_count": text_at(header, adapter, "NbOfTxs"),
            "declared_control_sum": text_at(header, adapter, "CtrlSum"),
        },
        "groups": group_views,
        "payments": payment_views,
        "totals": totals_json(totals),
    }


def totals_json(totals: object) -> dict[str, object]:
    assert hasattr(totals, "by_currency")
    return {
        "count": totals.count,
        "control_sum": decimal_text(totals.control_sum) if totals.control_sum is not None else None,
        "by_currency": {key: decimal_text(value) for key, value in sorted(totals.by_currency.items())},
        "complete": totals.complete,
        "excluded": totals.excluded,
    }


def payment_detail(tree: etree._ElementTree, adapter: Adapter, index: NodeIndex, transaction_id: str) -> dict[str, object]:
    tx = index.node_for(transaction_id)
    if tx.tag != adapter.q("CdtTrfTxInf"):
        raise KeyError("Węzeł nie jest płatnością.")
    group = tx.getparent()
    model = schema_model(adapter.namespace)
    return {
        "transaction_id": transaction_id,
        "group_id": index.id_for(group),
        "tree": node_tree(tx, index, tree, model),
        "group_tree": node_tree(group, index, tree, model, {"CdtTrfTxInf"}) if group is not None else None,
        "xml": etree.tostring(tx, encoding="unicode", pretty_print=True),
    }


def issue_counts(issues: list[dict[str, object]]) -> dict[str, tuple[int, int]]:
    counts: dict[str, list[int]] = defaultdict(lambda: [0, 0])
    for issue in issues:
        tid = issue.get("transaction_id")
        if not tid:
            continue
        counts[str(tid)][0 if issue.get("severity") == "error" else 1] += 1
    return {key: (value[0], value[1]) for key, value in counts.items()}
