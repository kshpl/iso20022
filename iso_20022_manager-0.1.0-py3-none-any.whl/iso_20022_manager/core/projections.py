from __future__ import annotations

from collections import defaultdict
from lxml import etree

from .adapters import Adapter, read_only_lookups, text_at
from .totals import calculate, decimal_text, read_amount
from .xml_nodes import NodeIndex, node_tree, referenced_code_sets
from iso_20022_manager.schemas.metadata import schema_model


def _account(parent: etree._Element | None, adapter: Adapter) -> dict[str, str | None] | None:
    if parent is None:
        return None
    ident = adapter.child(parent, "Id")
    if ident is None:
        return None
    iban = adapter.child(ident, "IBAN")
    other = adapter.child(ident, "Othr")
    if iban is not None and other is None:
        return {"kind": "iban", "value": iban.text, "scheme_code": None}
    if other is not None and iban is None:
        scheme = text_at(other, adapter, "SchmeNm/Cd") or text_at(other, adapter, "SchmeNm/Prtry")
        return {"kind": "other", "value": text_at(other, adapter, "Id"), "scheme_code": scheme}
    return {"kind": "invalid", "value": None, "scheme_code": None}


def document_nodes(tree: etree._ElementTree, adapter: Adapter) -> tuple[etree._Element | None, list[etree._Element], list[etree._Element]]:
    init = adapter.child(tree.getroot(), "CstmrCdtTrfInitn")
    if init is None:
        return None, [], []
    groups = adapter.children(init, "PmtInf")
    return init, groups, [tx for group in groups for tx in adapter.children(group, "CdtTrfTxInf")]


def _structured_remittance(tx: etree._Element, adapter: Adapter) -> list[str]:
    remittance = adapter.child(tx, "RmtInf")
    if remittance is None:
        return []
    preferred = {"Nb", "Ref", "AddtlRmtInf"}
    values = [
        (node.text or "").strip()
        for structured in adapter.children(remittance, "Strd")
        for node in structured.iter()
        if isinstance(node.tag, str) and etree.QName(node).localname in preferred and (node.text or "").strip()
    ]
    if values:
        return values
    return [
        (node.text or "").strip()
        for structured in adapter.children(remittance, "Strd")
        for node in structured.iter()
        if len(node) == 0 and (node.text or "").strip()
    ][:3]


@read_only_lookups
def summary(tree: etree._ElementTree, adapter: Adapter, index: NodeIndex, issue_counts: dict[str, tuple[int, int]] | None = None) -> dict[str, object]:
    issue_counts = issue_counts or {}
    init, groups, transactions = document_nodes(tree, adapter)
    header = adapter.child(init, "GrpHdr") if init is not None else None
    totals = calculate(transactions, adapter)
    group_views = []
    order = 0
    payment_views = []
    for group in groups:
        txs = adapter.children(group, "CdtTrfTxInf")
        gtotals = calculate(txs, adapter)
        gid = index.id_for(group)
        payment_info_id = text_at(group, adapter, "PmtInfId")
        date = next((text_at(group, adapter, path) for path in adapter.execution_date_paths if text_at(group, adapter, path)), None)
        group_views.append({
            "group_id": gid,
            "node_id": gid,
            "payment_info_id": payment_info_id,
            "debtor_name": text_at(group, adapter, "Dbtr/Nm"),
            "account": _account(adapter.child(group, "DbtrAcct"), adapter),
            "execution_date": date,
            "payment_method": text_at(group, adapter, "PmtMtd"),
            "transaction_count": len(txs),
            "totals": totals_json(gtotals),
        })
        for tx in txs:
            order += 1
            tid = index.id_for(tx)
            amount = read_amount(tx, adapter)
            ustrd = [n.text or "" for n in tx.findall("/".join(adapter.q(p) for p in ("RmtInf", "Ustrd")))]
            structured = _structured_remittance(tx, adapter)
            errors, warnings = issue_counts.get(tid or "", (0, 0))
            payment_views.append({
                "transaction_id": tid,
                "group_id": gid,
                "node_id": tid,
                "original_order": order,
                "creditor_name": text_at(tx, adapter, "Cdtr/Nm"),
                "account": _account(adapter.child(tx, "CdtrAcct"), adapter),
                "amount": {"kind": amount.kind, "raw_value": amount.raw, "value": decimal_text(amount.value) if amount.value is not None else None, "currency": amount.currency},
                "end_to_end_id": text_at(tx, adapter, "PmtId/EndToEndId"),
                "remittance_summary": " | ".join(ustrd or structured),
                "is_draft": amount.value is None or not text_at(tx, adapter, "PmtId/EndToEndId"),
                "error_count": errors,
                "warning_count": warnings,
                "execution_date": date,
                "payment_info_id": payment_info_id,
            })
    return {
        "header": {
            "message_reference": text_at(header, adapter, "MsgId"),
            "creation_datetime": text_at(header, adapter, "CreDtTm"),
            "initiating_party": text_at(header, adapter, "InitgPty/Nm"),
            "declared_count": text_at(header, adapter, "NbOfTxs"),
            "declared_control_sum": text_at(header, adapter, "CtrlSum"),
        },
        "groups": group_views,
        "payments": payment_views,
        "totals": totals_json(totals),
    }


def totals_json(totals: object) -> dict[str, object]:
    assert hasattr(totals, "by_currency")
    return {
        "count": totals.count,
        "control_sum": decimal_text(totals.control_sum) if totals.control_sum is not None else None,
        "by_currency": {key: decimal_text(value) for key, value in sorted(totals.by_currency.items())},
        "complete": totals.complete,
        "excluded": totals.excluded,
    }


@read_only_lookups
def payment_detail(tree: etree._ElementTree, adapter: Adapter, index: NodeIndex, transaction_id: str, profile_id: str = "iso-base", bank_constraints: dict | None = None) -> dict[str, object]:
    from iso_20022_manager.validation.bank_lengths import bank_length_constraints

    lengths = bank_constraints if bank_constraints is not None else bank_length_constraints(tree, adapter, profile_id)
    tx = index.node_for(transaction_id)
    if tx.tag != adapter.q("CdtTrfTxInf"):
        raise KeyError("Węzeł nie jest płatnością.")
    group = tx.getparent()
    model = schema_model(adapter.namespace)
    amount = read_amount(tx, adapter)
    tx_tree = node_tree(tx, index, tree, model, profile_id=profile_id, bank_constraints=lengths)
    group_tree = node_tree(group, index, tree, model, {"CdtTrfTxInf"}, profile_id, lengths) if group is not None else None
    return {
        "transaction_id": transaction_id,
        "group_id": index.id_for(group),
        "payment": {
            "transaction_id": transaction_id,
            "payment_info_id": text_at(group, adapter, "PmtInfId") if group is not None else None,
            "creditor_name": text_at(tx, adapter, "Cdtr/Nm"),
            "end_to_end_id": text_at(tx, adapter, "PmtId/EndToEndId"),
            "amount": {
                "kind": amount.kind,
                "raw_value": amount.raw,
                "value": decimal_text(amount.value) if amount.value is not None else None,
                "currency": amount.currency,
            },
        },
        "tree": tx_tree,
        "group_tree": group_tree,
        "code_sets": referenced_code_sets(tx_tree, group_tree),
        "xml": etree.tostring(tx, encoding="unicode", pretty_print=True),
    }


def issue_counts(issues: list[dict[str, object]]) -> dict[str, tuple[int, int]]:
    counts: dict[str, list[int]] = defaultdict(lambda: [0, 0])
    for issue in issues:
        tid = issue.get("transaction_id")
        if not tid:
            continue
        counts[str(tid)][0 if issue.get("severity") == "error" else 1] += 1
    return {key: (value[0], value[1]) for key, value in counts.items()}
