"""Domain services. Full lxml trees are the source of truth."""
