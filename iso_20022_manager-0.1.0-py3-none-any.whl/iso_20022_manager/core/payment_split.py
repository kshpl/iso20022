from decimal import Decimal, localcontext
import re

from lxml import etree

from iso_20022_manager.validation.bank_profiles import _is_split
from iso_20022_manager.validation.code_sets import reference_data

from .adapters import Adapter, find_every, text_at
from .totals import Amount, decimal_text, read_amount


def plan_payment_split(tx: etree._Element, adapter: Adapter, profile_id: str) -> tuple[Amount, str, str]:
    group = tx.getparent()
    if tx.tag != adapter.q("CdtTrfTxInf") or group is None or group.tag != adapter.q("PmtInf"):
        raise ValueError("Wskazany węzeł nie jest płatnością.")

    amount = read_amount(tx, adapter)
    if amount.kind == "equivalent":
        raise ValueError("Kwota równoważna (EqvtAmt) wymaga ręcznego podziału.")
    if amount.value is None or amount.value <= 0 or amount.value.adjusted() >= 18:
        raise ValueError("Do podziału potrzebna jest poprawna, dodatnia kwota przelewu.")
    currencies, _, _, _ = reference_data()
    minor_unit = currencies.get(amount.currency, {}).get("minor_unit")
    if minor_unit is None:
        raise ValueError("Brak jednostki rozliczeniowej waluty potrzebnej do podziału.")

    # Check all remittance repetitions, including fields hidden in the main form.
    def nodes(path: str) -> list[etree._Element]:
        return find_every(tx, "/".join(adapter.q(tag) for tag in path.split("/")))

    remittance_texts = nodes("RmtInf/Ustrd") + nodes("RmtInf/Strd/AddtlRmtInf")
    coded_vat = any(
        re.search(r"/VAT/|\bsplit[ -]+payment\b|\bpłatność podzielona\b|\bVAT\s+[0-9]+[.,][0-9]{2}\b", node.text or "", re.IGNORECASE)
        for node in remittance_texts
    )
    owners = (tx, group)
    tax_payment = any(text_at(owner, adapter, f"PmtTpInf/CtgyPurp/{tag}") == "TAXS" for owner in owners for tag in ("Cd", "Prtry"))
    pko_tax_or_vat = profile_id == "pko-ipko-business-pl-2026" and any(
        text_at(owner, adapter, "PmtTpInf/SvcLvl/Prtry") in {"3", "4", "5", "6"} for owner in owners
    )
    citi_tax_or_vat = profile_id == "citidirect-pl-2026" and any(
        text_at(owner, adapter, "PmtTpInf/LclInstrm/Prtry") in {"CITI592", "CITI984"} for owner in owners
    )
    if coded_vat or tax_payment or pko_tax_or_vat or citi_tax_or_vat or _is_split(group, tx, adapter):
        raise ValueError("Przelew VAT lub podatkowy wymaga ręcznego podziału.")
    if any(nodes(path) for path in ("Tax", "RmtInf/Strd/TaxRmt", "RmtInf/Strd/RfrdDocAmt", "RmtInf/Strd/GrnshmtRmt", "RgltryRptg/Dtls/Amt")):
        raise ValueError("Dodatkowe kwoty faktury, podatku lub potrącenia wymagają ręcznego podziału.")

    with localcontext() as ctx:
        ctx.prec = 32
        places = int(minor_unit)
        unit = Decimal(1).scaleb(-places)
        if amount.value.quantize(unit) != amount.value:
            raise ValueError(f"Kwota {amount.currency} ma więcej niż {places} miejsc dziesiętnych.")
        units = int(amount.value.scaleb(places))
        if units < 2:
            raise ValueError("Kwota jest za mała na dwa dodatnie przelewy w tej walucie.")
        half, remainder = divmod(units, 2)
        first = decimal_text(Decimal(half + remainder).scaleb(-places))
        second = decimal_text(Decimal(half).scaleb(-places))
    return amount, first, second
