from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal, DecimalException, Inexact, InvalidOperation, Rounded, localcontext
import re

from lxml import etree

from .adapters import Adapter


@dataclass(frozen=True)
class Amount:
    raw: str | None
    value: Decimal | None
    currency: str | None
    kind: str
    node: etree._Element | None


@dataclass(frozen=True)
class Totals:
    count: int
    control_sum: Decimal | None
    by_currency: dict[str, Decimal]
    complete: bool
    excluded: int


def read_amount(tx: etree._Element, adapter: Adapter) -> Amount:
    amt = adapter.child(tx, "Amt")
    if amt is None:
        return Amount(None, None, None, "invalid", None)
    instructed = adapter.child(amt, "InstdAmt")
    equivalent = adapter.child(amt, "EqvtAmt")
    if (instructed is None) == (equivalent is None):
        return Amount(None, None, None, "invalid", amt)
    if instructed is not None:
        node = instructed
        currency = node.get("Ccy")
        kind = "instructed"
    else:
        assert equivalent is not None
        node = adapter.child(equivalent, "Amt")
        currency = node.get("Ccy") if node is not None else None
        kind = "equivalent"
    raw = node.text if node is not None else None
    try:
        lexical = raw.strip() if raw is not None else None
        if lexical is None or not re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)", lexical):
            value = None
        else:
            value = Decimal(lexical)
        if value is not None and not value.is_finite():
            value = None
    except InvalidOperation:
        value = None
    return Amount(raw, value, currency, kind, node)


def calculate(transactions: list[etree._Element], adapter: Adapter) -> Totals:
    by_currency: dict[str, Decimal] = defaultdict(Decimal)
    control_sum = Decimal(0)
    excluded = 0
    with localcontext() as ctx:
        ctx.prec = 50
        ctx.traps[Inexact] = True
        ctx.traps[Rounded] = True
        for tx in transactions:
            amount = read_amount(tx, adapter)
            if amount.value is None or not amount.currency:
                excluded += 1
                continue
            try:
                currency_sum = by_currency[amount.currency] + amount.value
                next_control_sum = control_sum + amount.value
            except DecimalException:
                excluded += 1
                continue
            by_currency[amount.currency] = currency_sum
            control_sum = next_control_sum
    return Totals(len(transactions), control_sum if not excluded else None, dict(by_currency), excluded == 0, excluded)


def decimal_text(value: Decimal) -> str:
    return format(value, "f")


def update_aggregates(tree: etree._ElementTree, adapter: Adapter, *, preserve_presence: bool = True) -> list[dict[str, str | None]]:
    root = tree.getroot()
    initiation = adapter.child(root, "CstmrCdtTrfInitn")
    if initiation is None:
        return []
    groups = adapter.children(initiation, "PmtInf")
    all_tx: list[etree._Element] = []
    changes: list[dict[str, str | None]] = []

    def set_text(parent: etree._Element, name: str, value: str, after: tuple[str, ...], *, required: bool = False) -> None:
        node = adapter.child(parent, name)
        if node is None:
            if preserve_presence and not required:
                return
            node = etree.Element(adapter.q(name))
            insert_at = 0
            for i, child in enumerate(parent):
                if isinstance(child.tag, str) and etree.QName(child).localname in after:
                    insert_at = i + 1
            parent.insert(insert_at, node)
        old = node.text
        if old != value:
            node.text = value
            changes.append({"field": name, "before": old, "after": value})

    for group in groups:
        txs = adapter.children(group, "CdtTrfTxInf")
        all_tx.extend(txs)
        totals = calculate(txs, adapter)
        set_text(group, "NbOfTxs", str(totals.count), ("PmtMtd", "BtchBookg"))
        if totals.control_sum is not None:
            set_text(group, "CtrlSum", decimal_text(totals.control_sum), ("NbOfTxs",))
    totals = calculate(all_tx, adapter)
    header = adapter.child(initiation, "GrpHdr")
    if header is not None:
        set_text(header, "NbOfTxs", str(totals.count), ("MsgId", "CreDtTm"), required=True)
        if totals.control_sum is not None:
            set_text(header, "CtrlSum", decimal_text(totals.control_sum), ("NbOfTxs",))
    return changes
