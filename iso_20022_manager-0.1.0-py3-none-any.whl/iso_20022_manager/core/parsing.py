from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
import multiprocessing
import queue

from lxml import etree

MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_DEPTH = 64
MAX_NODES = 1_000_000
MAX_TEXT_BYTES = 1024 * 1024
MAX_PAYMENTS = 50_000


class UnsafeXml(ValueError):
    pass


class ResourceLimit(ValueError):
    pass


class ParseTimeout(TimeoutError):
    pass


class PreflightSyntax(ValueError):
    def __init__(self, message: str, line: int | None, column: int | None):
        super().__init__(message)
        self.line = line
        self.column = column


@dataclass(frozen=True)
class ParsedXml:
    tree: etree._ElementTree
    namespace: str | None
    message_identifier: str | None
    encoding: str | None


def _doctype_declared(payload: bytes) -> bool:
    # A small expat pass recognizes declarations in UTF-8/16 without resolving them.
    import xml.parsers.expat

    parser = xml.parsers.expat.ParserCreate()
    class DeclarationSeen(Exception):
        pass

    def mark(*_: object) -> None:
        raise DeclarationSeen

    parser.StartDoctypeDeclHandler = mark
    parser.EntityDeclHandler = mark
    try:
        parser.Parse(payload, True)
    except DeclarationSeen:
        return True
    except xml.parsers.expat.ExpatError:
        # lxml returns the useful syntax location. A declaration seen before the
        # syntax error is still enough to reject the input at L0.
        pass
    return False


def parse_xml(payload: bytes) -> ParsedXml:
    if not payload:
        raise ValueError("Plik XML jest pusty.")
    if len(payload) > MAX_UPLOAD_BYTES:
        raise ResourceLimit(f"Plik przekracza limit {MAX_UPLOAD_BYTES} bajtów.")
    if _doctype_declared(payload):
        raise UnsafeXml("Deklaracje DTD i encji są niedozwolone.")
    parser = etree.XMLParser(
        resolve_entities=False,
        load_dtd=False,
        no_network=True,
        recover=False,
        huge_tree=False,
        remove_blank_text=False,
        remove_comments=False,
        remove_pis=False,
        collect_ids=False,
    )
    tree = etree.parse(BytesIO(payload), parser)
    root = tree.getroot()
    qname = etree.QName(root)
    namespace = qname.namespace
    message_identifier = namespace.rsplit(":", 1)[-1] if namespace and ":pain." in namespace else None

    nodes = 0
    max_depth = 0
    payments = 0
    stack: list[tuple[etree._Element, int]] = [(root, 1)]
    while stack:
        node, depth = stack.pop()
        nodes += 1
        max_depth = max(max_depth, depth)
        if isinstance(node.tag, str):
            tag = etree.QName(node)
            if tag.namespace == namespace and tag.localname == "CdtTrfTxInf":
                payments += 1
            if node.text and len(node.text.encode("utf-8")) > MAX_TEXT_BYTES:
                raise ResourceLimit("Pojedynczy węzeł tekstowy przekracza limit 1 MiB.")
        if nodes > MAX_NODES or max_depth > MAX_DEPTH:
            raise ResourceLimit("Dokument przekracza limit liczby węzłów lub głębokości.")
        stack.extend((child, depth + 1) for child in node)
    if payments > MAX_PAYMENTS:
        raise ResourceLimit(f"Dokument przekracza limit {MAX_PAYMENTS} płatności.")
    return ParsedXml(tree, namespace, message_identifier, tree.docinfo.encoding)


def serialize_xml(tree: etree._ElementTree | etree._Element) -> bytes:
    return etree.tostring(tree, encoding="UTF-8", xml_declaration=True, pretty_print=False)


def _preflight_worker(payload: bytes, output: multiprocessing.Queue) -> None:
    try:
        parsed = parse_xml(payload)
        output.put({"status": "ok", "namespace": parsed.namespace, "message_identifier": parsed.message_identifier})
    except UnsafeXml as exc:
        output.put({"status": "unsafe", "message": str(exc)})
    except ResourceLimit as exc:
        output.put({"status": "limit", "message": str(exc)})
    except etree.XMLSyntaxError as exc:
        output.put({"status": "syntax", "message": exc.msg, "raw": str(exc), "line": exc.position[0], "column": exc.position[1]})
    except ValueError as exc:
        output.put({"status": "value", "message": str(exc)})


def preflight_xml(payload: bytes, timeout_seconds: float = 30) -> dict[str, object]:
    """Parse untrusted bytes in a killable worker before in-process parsing."""
    context = multiprocessing.get_context("spawn")
    output = context.Queue(maxsize=1)
    process = context.Process(target=_preflight_worker, args=(payload, output), daemon=True)
    process.start()
    process.join(timeout_seconds)
    if process.is_alive():
        process.terminate()
        process.join(2)
        raise ParseTimeout("Przekroczono limit czasu analizy XML.")
    try:
        result = output.get(timeout=1)
    except queue.Empty as exc:
        raise RuntimeError(f"Proces analizy XML zakończył się bez wyniku (kod {process.exitcode}).") from exc
    finally:
        output.close()
    status = result["status"]
    if status == "unsafe":
        raise UnsafeXml(result["message"])
    if status == "limit":
        raise ResourceLimit(result["message"])
    if status == "syntax":
        raise PreflightSyntax(result["message"], result.get("line"), result.get("column"))
    if status == "value":
        raise ValueError(result["message"])
    return result
