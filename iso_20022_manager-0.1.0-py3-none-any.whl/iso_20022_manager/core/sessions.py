from __future__ import annotations

import copy
import hashlib
import json
import threading
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import PurePath
from uuid import uuid4

from lxml import etree

from iso_20022_manager.validation.engine import validate_tree
from iso_20022_manager.validation.bank_profiles import profile_ids as bank_profile_ids

from .adapters import Adapter, adapter_for, text_at
from .parsing import ParsedXml, decode_xml_source, encode_xml_source, parse_xml, preflight_validation, serialize_xml
from .projections import issue_counts, summary
from .totals import update_aggregates
from .xml_nodes import NodeIndex, local_name

SESSION_TTL = timedelta(hours=2)
ARTIFACT_TTL = timedelta(minutes=15)
MAX_HISTORY_COMMANDS = 100
MAX_HISTORY_BYTES = 64 * 1024 * 1024
MAX_COMMAND_RESULTS = 100
XMLDSIG_SIGNATURE = "{http://www.w3.org/2000/09/xmldsig#}Signature"


@dataclass
class Snapshot:
    payload: bytes
    node_paths: dict[str, str]
    profile_id: str

    @property
    def size(self) -> int:
        return len(self.payload) + sum(len(key) + len(value) for key, value in self.node_paths.items())


@dataclass
class HistoryEntry:
    label: str
    changes: list["HistoryChange"] = field(default_factory=list)
    details: list[dict[str, object]] = field(default_factory=list)
    before: Snapshot | None = None
    after: Snapshot | None = None

    @property
    def size(self) -> int:
        snapshots = (self.before.size if self.before else 0) + (self.after.size if self.after else 0)
        return snapshots + sum(change.size for change in self.changes) + len(self.label.encode())


@dataclass
class HistoryChange:
    kind: str
    node_id: str | None = None
    parent_id: str | None = None
    attribute: str | None = None
    before: str | None = None
    after: str | None = None
    element: etree._Element | None = None
    identities: dict[etree._Element, str] = field(default_factory=dict)
    position: int = 0
    present_before: bool = False
    present_after: bool = False

    @property
    def size(self) -> int:
        scalar = sum(len((value or "").encode()) for value in (self.node_id, self.parent_id, self.attribute, self.before, self.after))
        subtree = len(etree.tostring(self.element)) if self.element is not None else 0
        return scalar + subtree + len(self.identities) * 72


@dataclass
class ExportArtifact:
    artifact_id: str
    source_revision: int
    payload: bytes
    sha256: str
    filename: str
    report: dict[str, object]
    automatic_changes: list[dict[str, str | None]]
    created_at: datetime
    acknowledged: bool = False


@dataclass
class DocumentSession:
    owner_id: str
    original_name: str
    original_bytes: bytes
    parsed: ParsedXml | None
    syntax_issue: dict[str, object] | None = None
    initial_report: dict[str, object] | None = None
    document_id: str = field(default_factory=lambda: str(uuid4()))
    revision: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    last_activity_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    profile_id: str = "iso-base"
    lock: threading.RLock = field(default_factory=threading.RLock)
    undo_stack: list[HistoryEntry] = field(default_factory=list)
    redo_stack: list[HistoryEntry] = field(default_factory=list)
    command_results: dict[str, tuple[str, dict[str, object]]] = field(default_factory=dict)
    export_commands: dict[str, tuple[str, str]] = field(default_factory=dict)
    artifacts: dict[str, ExportArtifact] = field(default_factory=dict)
    current_report: dict[str, object] | None = None
    original_report: dict[str, object] | None = None
    history_discarded_commands: int = 0

    def __post_init__(self) -> None:
        self.tree = self.parsed.tree if self.parsed else None
        self.namespace = self.parsed.namespace if self.parsed else None
        self.message_identifier = self.parsed.message_identifier if self.parsed else None
        self.adapter: Adapter | None = adapter_for(self.namespace)
        self.index = NodeIndex(self.tree) if self.tree is not None else None
        if self.tree is not None and self.index is not None:
            self.original_report = self._adopt_report(self.initial_report, self.tree, self.index, 0, "original") if self.initial_report else self._validate(self.original_bytes, "original")
            self.current_report = self.original_report
        else:
            self.original_report = self.current_report = self._syntax_report()

    @property
    def original_sha256(self) -> str:
        return hashlib.sha256(self.original_bytes).hexdigest()

    @property
    def dirty(self) -> bool:
        return self.revision > 0

    def _syntax_report(self) -> dict[str, object]:
        issue = self.syntax_issue or {"message_pl": "Nie można sparsować dokumentu XML.", "line": None, "column": None}
        return {
            "report_id": str(uuid4()), "document_id": self.document_id, "revision": self.revision, "validated_view": "original",
            "payload_sha256": self.original_sha256, "created_at": datetime.now(UTC).isoformat(),
            "schema_sha256": None, "rule_bundle_id": "iso-base-2026.09", "engine_versions": {"lxml": ".".join(map(str, etree.LXML_VERSION)), "libxml2": ".".join(map(str, etree.LIBXML_VERSION))},
            "code_set_versions": [], "profiles": [{"profile_id": self.profile_id, "status": "not_run"}],
            "validation_context": {"analysis_date": datetime.now(UTC).date().isoformat(), "requested_execution_date": None, "expected_inter_psp_settlement_date": None},
            "layers": [
                {"id": "L0", "name": "Bezpieczeństwo wejścia", "status": "pass", "checked": 1},
                {"id": "L1", "name": "Składnia XML", "status": "fail", "checked": 1},
                {"id": "L2", "name": "Identyfikacja", "status": "not_run", "checked": 0},
            ],
            "issues": [{
                "issue_id": str(uuid4()), "rule_id": "XML_SYNTAX", "severity": "error", "category": "xml",
                "document_revision": self.revision, "transaction_id": None, "group_id": None, "node_id": None, "field_id": None,
                "xpath": None, "location": {"view": "original", "line": issue.get("line"), "column": issue.get("column")},
                "message_pl": issue["message_pl"], "raw_message": issue.get("raw_message"), "source": {"kind": "parser"},
                "expected": None, "actual_summary": None, "suggestion": None, "auto_fixable": False,
            }],
            "error_count": 1, "warning_count": 0, "incomplete": True, "can_export_in_scope": False,
            "blocking_reasons": ["XML_SYNTAX"], "coverage": {"not_run": ["XSD", "business", "profile"]},
        }

    def _validate(self, payload: bytes | None = None, view: str = "working", tree: etree._ElementTree | None = None, index: NodeIndex | None = None) -> dict[str, object]:
        active_tree = tree or self.tree
        active_index = index or self.index
        assert active_tree is not None and active_index is not None
        return validate_tree(active_tree, self.namespace, self.adapter, active_index, self.revision, payload or serialize_xml(active_tree), validated_view=view, profile_id=self.profile_id, document_id=self.document_id)

    def _adopt_report(
        self,
        report: dict[str, object],
        tree: etree._ElementTree,
        index: NodeIndex,
        revision: int,
        view: str,
    ) -> dict[str, object]:
        report["document_id"] = self.document_id
        report["revision"] = revision
        report["validated_view"] = view
        nodes = [node for node in tree.getroot().iter() if isinstance(node.tag, str)]
        for issue in report.get("issues", []):
            issue["document_revision"] = revision
            location = issue.get("location")
            if isinstance(location, dict):
                location["view"] = view
            for key in ("node_id", "transaction_id", "group_id"):
                ordinal = issue.pop(f"_{key}_ordinal", None)
                node = nodes[ordinal] if isinstance(ordinal, int) and 0 <= ordinal < len(nodes) else None
                issue[key] = index.id_for(node)
        return report

    def view(self, include_payments: bool = True) -> dict[str, object]:
        with self.lock:
            return self._view_unlocked(include_payments)

    def _view_unlocked(self, include_payments: bool = True) -> dict[str, object]:
        self.last_activity_at = datetime.now(UTC)
        signed = self._contains_signature()
        base: dict[str, object] = {
            "document_id": self.document_id,
            "original_name": self.original_name,
            "original_sha256": self.original_sha256,
            "namespace": self.namespace,
            "message_identifier": self.message_identifier,
            "revision": self.revision,
            "mode": "signed_read_only" if signed else ("editable" if self.adapter and self.tree is not None else ("syntax_error" if self.tree is None else "unsupported")),
            "dirty": self.dirty,
            "profile_id": self.profile_id,
            "can_undo": bool(self.undo_stack),
            "can_redo": bool(self.redo_stack),
            "history": [{"label": item.label, "details": item.details} for item in reversed(self.undo_stack)],
            "history_limited": self.history_discarded_commands > 0,
            "history_discarded_commands": self.history_discarded_commands,
            "history_bytes": sum(item.size for item in self.undo_stack),
            "expires_at": (self.last_activity_at + SESSION_TTL).isoformat(),
            "report": self.current_report,
            "original_report": self.original_report,
        }
        if self.tree is not None and self.adapter is not None and self.index is not None:
            counts = issue_counts((self.current_report or {}).get("issues", []))
            projected = summary(self.tree, self.adapter, self.index, counts)
            if not include_payments:
                projected.pop("payments", None)
            base.update(projected)
        else:
            base.update({"header": {}, "groups": [], "payments": [], "totals": {"count": 0, "control_sum": None, "by_currency": {}, "complete": False}})
        return base

    def source(self, original: bool = False) -> str:
        with self.lock:
            payload = self.original_bytes if original or self.tree is None else serialize_xml(self.tree)
            encoding = self.parsed.encoding if original and self.parsed is not None else None
            return decode_xml_source(payload, encoding)

    def validate(self) -> dict[str, object]:
        with self.lock:
            if self.tree is None:
                self.current_report = self._syntax_report()
                return self.current_report
            assert self.index is not None
            revision = self.revision
            profile_id = self.profile_id
            payload = serialize_xml(self.tree)
            parsed = parse_xml(payload)
            snapshot_index = NodeIndex.mirror(self.tree, parsed.tree, self.index)
        preflight = preflight_validation(payload, profile_id)
        report = self._adopt_report(preflight["report"], parsed.tree, snapshot_index, revision, "working")
        with self.lock:
            if self.revision == revision and self.profile_id == profile_id:
                self.current_report = report
            assert self.current_report is not None
            return self.current_report

    def _snapshot(self) -> Snapshot:
        assert self.tree is not None and self.index is not None
        return Snapshot(serialize_xml(self.tree), self.index.snapshot_paths(self.tree), self.profile_id)

    def _restore(self, snapshot: Snapshot) -> None:
        parsed = parse_xml(snapshot.payload)
        restored_index = NodeIndex.restore(parsed.tree, snapshot.node_paths)
        self.tree = parsed.tree
        self.namespace = parsed.namespace
        self.message_identifier = parsed.message_identifier
        self.adapter = adapter_for(self.namespace)
        self.index = restored_index
        self.profile_id = snapshot.profile_id

    def _contains_signature(self) -> bool:
        return self.tree is not None and any(
            node.tag == XMLDSIG_SIGNATURE for node in self.tree.iter() if isinstance(node.tag, str)
        )

    def _push_history(self, entry: HistoryEntry) -> None:
        self.undo_stack.append(entry)
        while len(self.undo_stack) > MAX_HISTORY_COMMANDS or sum(item.size for item in self.undo_stack) > MAX_HISTORY_BYTES:
            self.undo_stack.pop(0)
            self.history_discarded_commands += 1
        self.redo_stack.clear()

    def _apply_change(self, change: HistoryChange, *, forward: bool) -> None:
        assert self.index is not None
        if change.kind == "text":
            self.index.node_for(str(change.node_id)).text = change.after if forward else change.before
            return
        if change.kind == "attribute":
            node = self.index.node_for(str(change.node_id))
            value = change.after if forward else change.before
            if value is None:
                node.attrib.pop(str(change.attribute), None)
            else:
                node.set(str(change.attribute), value)
            return
        if change.kind == "profile":
            self.profile_id = str(change.after if forward else change.before)
            return
        if change.kind != "structure" or change.element is None:
            raise RuntimeError("Nieznany wpis historii.")
        should_exist = change.present_after if forward else change.present_before
        existing = self.index.by_id.get(str(change.node_id))
        if should_exist and existing is None:
            parent = self.index.node_for(str(change.parent_id))
            parent.insert(max(0, min(change.position, len(parent))), change.element)
            self.index.restore_subtree_ids(change.element, change.identities)
        elif not should_exist and existing is not None:
            parent = existing.getparent()
            if parent is None:
                raise RuntimeError("Nie można odłączyć korzenia podczas odtwarzania historii.")
            self.index.forget_subtree(existing)
            parent.remove(existing)
            change.element = existing

    def _rollback(self, changes: list[HistoryChange]) -> None:
        for change in reversed(changes):
            self._apply_change(change, forward=False)

    def _aggregate_state(self) -> dict[tuple[str, str], tuple[str, str | None, etree._Element, int]]:
        assert self.tree is not None and self.adapter is not None and self.index is not None
        initiation = self.adapter.child(self.tree.getroot(), "CstmrCdtTrfInitn")
        if initiation is None:
            return {}
        parents = self.adapter.children(initiation, "PmtInf")
        header = self.adapter.child(initiation, "GrpHdr")
        if header is not None:
            parents.append(header)
        state: dict[tuple[str, str], tuple[str, str | None, etree._Element, int]] = {}
        for parent in parents:
            parent_id = self.index.id_for(parent)
            if parent_id is None:
                continue
            for name in ("NbOfTxs", "CtrlSum"):
                node = self.adapter.child(parent, name)
                node_id = self.index.id_for(node)
                if node is not None and node_id is not None:
                    state[(parent_id, name)] = (node_id, node.text, node, parent.index(node))
        return state

    def _record_aggregate_changes(
        self,
        before: dict[tuple[str, str], tuple[str, str | None, etree._Element, int]],
        changes: list[HistoryChange],
        details: list[dict[str, object]],
    ) -> None:
        assert self.index is not None
        after = self._aggregate_state()
        for key, (node_id, value, node, position) in after.items():
            previous = before.get(key)
            if previous is None:
                identities = self.index.subtree_ids(node)
                changes.append(HistoryChange("structure", node_id=node_id, parent_id=key[0], element=node, identities=identities, position=position, present_after=True))
                details.append({"kind": "automatic", "field": key[1], "before": None, "after": value, "node_id": node_id})
            elif previous[1] != value:
                changes.append(HistoryChange("text", node_id=node_id, before=previous[1], after=value))
                details.append({"kind": "automatic", "field": key[1], "before": previous[1], "after": value, "node_id": node_id})

    def command(self, command: dict[str, object], include_payments: bool = True) -> dict[str, object]:
        with self.lock:
            command_id = str(command["command_id"])
            digest = hashlib.sha256(json.dumps(command, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if command_id in self.command_results:
                previous_hash, receipt = self.command_results[command_id]
                if previous_hash != digest:
                    raise CommandConflict("command_id został wcześniej użyty z inną treścią.")
                return {**receipt, "idempotent_replay": True, "current_revision": self.revision, "document": self._view_unlocked(include_payments)}
            if int(command["expected_revision"]) != self.revision:
                raise RevisionConflict(self.revision)
            if self.tree is None or self.adapter is None or self.index is None:
                raise ValueError("Dokument nie jest dostępny w trybie edycji.")
            if self._contains_signature():
                raise ValueError("Dokument zawiera podpis XML Signature i jest dostępny tylko do diagnostyki.")
            kind = str(command["type"])
            if kind == "undo":
                result = self._undo(include_payments)
            elif kind == "redo":
                result = self._redo(include_payments)
            else:
                previous_report = self.current_report
                changes: list[HistoryChange] = []
                details: list[dict[str, object]] = []
                aggregate_before = self._aggregate_state()
                try:
                    label = self._apply(kind, dict(command.get("payload") or {}), changes, details)
                    self.index.assign_subtree(self.tree.getroot())
                    aggregate_changes = update_aggregates(self.tree, self.adapter)
                    self.index.assign_subtree(self.tree.getroot())
                    self._record_aggregate_changes(aggregate_before, changes, details)
                    if aggregate_changes:
                        label += f"; automatycznie zmieniono agregaty: {len(aggregate_changes)}"
                    payload = serialize_xml(self.tree)
                    parse_xml(payload)
                    preflight = preflight_validation(payload, self.profile_id)
                    self.revision += 1
                    self.current_report = self._adopt_report(preflight["report"], self.tree, self.index, self.revision, "working")
                except Exception:
                    self._rollback(changes)
                    self.current_report = previous_report
                    raise
                self._push_history(HistoryEntry(label, changes, details))
                self.artifacts.clear()
                result = {"applied_revision": self.revision, "current_revision": self.revision, "label": label, "document": self._view_unlocked(include_payments)}
            receipt = {key: value for key, value in result.items() if key != "document"}
            self.command_results[command_id] = (digest, receipt)
            while len(self.command_results) > MAX_COMMAND_RESULTS:
                self.command_results.pop(next(iter(self.command_results)))
            return result

    def _undo(self, include_payments: bool = True) -> dict[str, object]:
        if not self.undo_stack:
            raise ValueError("Brak operacji do cofnięcia.")
        entry = self.undo_stack[-1]
        try:
            if entry.before is not None:
                current = self._snapshot()
                self._restore(entry.before)
            else:
                self._rollback(entry.changes)
                current = None
            payload = serialize_xml(self.tree)
            preflight = preflight_validation(payload, self.profile_id)
        except Exception:
            if entry.after is not None and current is not None:
                self._restore(current)
            elif entry.before is None:
                for change in entry.changes:
                    self._apply_change(change, forward=True)
            raise
        self.undo_stack.pop()
        self.redo_stack.append(entry)
        self.revision += 1
        self.artifacts.clear()
        self.current_report = self._adopt_report(preflight["report"], self.tree, self.index, self.revision, "working")
        return {"applied_revision": self.revision, "current_revision": self.revision, "label": f"Cofnięto: {entry.label}", "document": self._view_unlocked(include_payments)}

    def _redo(self, include_payments: bool = True) -> dict[str, object]:
        if not self.redo_stack:
            raise ValueError("Brak operacji do ponowienia.")
        entry = self.redo_stack[-1]
        try:
            if entry.after is not None:
                current = self._snapshot()
                self._restore(entry.after)
            else:
                for change in entry.changes:
                    self._apply_change(change, forward=True)
                current = None
            payload = serialize_xml(self.tree)
            preflight = preflight_validation(payload, self.profile_id)
        except Exception:
            if entry.before is not None and current is not None:
                self._restore(current)
            elif entry.after is None:
                self._rollback(entry.changes)
            raise
        self.redo_stack.pop()
        self.undo_stack.append(entry)
        self.revision += 1
        self.artifacts.clear()
        self.current_report = self._adopt_report(preflight["report"], self.tree, self.index, self.revision, "working")
        return {"applied_revision": self.revision, "current_revision": self.revision, "label": f"Ponowiono: {entry.label}", "document": self._view_unlocked(include_payments)}

    def _apply(
        self,
        kind: str,
        payload: dict[str, object],
        changes: list[HistoryChange],
        details: list[dict[str, object]],
    ) -> str:
        assert self.tree is not None and self.index is not None and self.adapter is not None
        if kind in {"set_field", "set_fields"}:
            fields = [payload] if kind == "set_field" else list(payload.get("fields", []))
            if not fields or len(fields) > 500:
                raise ValueError("Polecenie musi zawierać od 1 do 500 zmian pól.")
            labels: list[str] = []
            for raw_field in fields:
                if not isinstance(raw_field, dict):
                    raise ValueError("Niepoprawny opis zmiany pola.")
                labels.append(self._set_field(raw_field, changes, details))
            return labels[0] if len(labels) == 1 else f"Zapisano zmiany w {len(labels)} polach"
        if kind == "remove_attribute":
            node = self.index.node_for(str(payload["node_id"]))
            attribute = str(payload["attribute"])
            if not re_safe_tag(attribute) or attribute not in node.attrib:
                raise ValueError("Atrybut nie istnieje lub ma niepoprawną nazwę.")
            before = node.attrib.pop(attribute)
            changes.append(HistoryChange("attribute", node_id=self.index.id_for(node), attribute=attribute, before=before, after=None))
            details.append({"kind": "remove", "field": f"{local_name(node)}/@{attribute}", "before": before, "after": None, "node_id": self.index.id_for(node)})
            return f"Usunięto {local_name(node)}/@{attribute}: {short_value(before)}"
        if kind == "insert_element":
            parent = self.index.node_for(str(payload["parent_node_id"]))
            local = str(payload["tag"])
            if not re_safe_tag(local):
                raise ValueError("Niepoprawna nazwa elementu.")
            child = etree.Element(self.adapter.q(local))
            child.text = str(payload.get("value", ""))
            position = int(payload.get("position", len(parent)))
            parent.insert(max(0, min(position, len(parent))), child)
            self.index.assign_subtree(child)
            child_id = self.index.id_for(child)
            changes.append(HistoryChange("structure", node_id=child_id, parent_id=self.index.id_for(parent), element=child, identities=self.index.subtree_ids(child), position=parent.index(child), present_after=True))
            details.append({"kind": "add", "field": local, "before": None, "after": child.text, "node_id": child_id})
            return f"Dodano pole {local} w {local_name(parent)}"
        if kind == "remove_element":
            node = self.index.node_for(str(payload["node_id"]))
            parent = node.getparent()
            if parent is None:
                raise ValueError("Nie można usunąć korzenia dokumentu.")
            node_id = self.index.id_for(node)
            identities = self.index.subtree_ids(node)
            position = parent.index(node)
            self.index.forget_subtree(node)
            parent.remove(node)
            changes.append(HistoryChange("structure", node_id=node_id, parent_id=self.index.id_for(parent), element=node, identities=identities, position=position, present_before=True))
            details.append({"kind": "remove", "field": local_name(node), "before": etree.tostring(node, encoding="unicode"), "after": None, "node_id": node_id})
            return f"Usunięto pole {local_name(node)}"
        if kind == "select_choice":
            parent = self.index.node_for(str(payload["parent_node_id"]))
            remove_nodes = [self.index.node_for(str(node_id)) for node_id in payload.get("remove_node_ids", [])]
            if any(node.getparent() is not parent for node in remove_nodes):
                raise ValueError("Gałąź choice nie należy do wskazanego rodzica.")
            position = int(payload.get("position", len(parent)))
            position -= sum(parent.index(node) < position for node in remove_nodes)
            for node in remove_nodes:
                node_id = self.index.id_for(node)
                identities = self.index.subtree_ids(node)
                node_position = parent.index(node)
                self.index.forget_subtree(node)
                parent.remove(node)
                changes.append(HistoryChange("structure", node_id=node_id, parent_id=self.index.id_for(parent), element=node, identities=identities, position=node_position, present_before=True))
                details.append({"kind": "remove", "field": local_name(node), "before": etree.tostring(node, encoding="unicode"), "after": None, "node_id": node_id})
            local = str(payload["tag"])
            if not re_safe_tag(local):
                raise ValueError("Niepoprawna nazwa elementu.")
            child = etree.Element(self.adapter.q(local))
            child.text = str(payload.get("value", ""))
            position = max(0, min(position, len(parent)))
            parent.insert(position, child)
            self.index.assign_subtree(child)
            child_id = self.index.id_for(child)
            changes.append(HistoryChange("structure", node_id=child_id, parent_id=self.index.id_for(parent), element=child, identities=self.index.subtree_ids(child), position=position, present_after=True))
            details.append({"kind": "add", "field": local, "before": None, "after": child.text, "node_id": child_id})
            return f"Wybrano gałąź {local}"
        if kind == "duplicate_payment":
            tx = self.index.node_for(str(payload["transaction_id"]))
            if tx.tag != self.adapter.q("CdtTrfTxInf"):
                raise ValueError("Wskazany węzeł nie jest płatnością.")
            duplicate = copy.deepcopy(tx)
            parent = tx.getparent()
            assert parent is not None
            parent.insert(parent.index(tx) + 1, duplicate)
            self.index.assign_subtree(duplicate)
            reference = text_at(tx, self.adapter, "PmtId/EndToEndId")
            duplicate_id = self.index.id_for(duplicate)
            changes.append(HistoryChange("structure", node_id=duplicate_id, parent_id=self.index.id_for(parent), element=duplicate, identities=self.index.subtree_ids(duplicate), position=parent.index(duplicate), present_after=True))
            details.append({"kind": "duplicate", "field": "CdtTrfTxInf", "reference": reference, "node_id": duplicate_id})
            return f"Zduplikowano płatność {short_value(reference)} (referencje XML zachowane)"
        if kind == "delete_payments":
            ids = [str(item) for item in payload.get("transaction_ids", [])]
            if not ids:
                raise ValueError("Nie wskazano płatności do usunięcia.")
            if len(ids) != len(set(ids)):
                raise ValueError("Lista płatności do usunięcia zawiera powtórzone identyfikatory.")
            nodes = [self.index.node_for(item) for item in ids]
            if any(node.tag != self.adapter.q("CdtTrfTxInf") for node in nodes):
                raise ValueError("Lista zawiera węzeł, który nie jest płatnością.")
            references = [text_at(node, self.adapter, "PmtId/EndToEndId") for node in nodes]
            for node, reference in zip(nodes, references, strict=True):
                parent = node.getparent()
                assert parent is not None
                node_id = self.index.id_for(node)
                identities = self.index.subtree_ids(node)
                position = parent.index(node)
                self.index.forget_subtree(node)
                parent.remove(node)
                changes.append(HistoryChange("structure", node_id=node_id, parent_id=self.index.id_for(parent), element=node, identities=identities, position=position, present_before=True))
                details.append({"kind": "remove_payment", "field": "CdtTrfTxInf", "reference": reference, "node_id": node_id})
            shown = ", ".join(short_value(item) for item in references[:5])
            suffix = ", …" if len(references) > 5 else ""
            return f"Usunięto płatności: {len(nodes)} ({shown}{suffix})"
        if kind == "delete_empty_group":
            group = self.index.node_for(str(payload["group_id"]))
            if group.tag != self.adapter.q("PmtInf"):
                raise ValueError("Wskazany węzeł nie jest grupą płatności.")
            if self.adapter.children(group, "CdtTrfTxInf"):
                raise ValueError("Można usunąć tylko pustą grupę.")
            parent = group.getparent()
            assert parent is not None
            group_id = self.index.id_for(group)
            identities = self.index.subtree_ids(group)
            position = parent.index(group)
            self.index.forget_subtree(group)
            parent.remove(group)
            changes.append(HistoryChange("structure", node_id=group_id, parent_id=self.index.id_for(parent), element=group, identities=identities, position=position, present_before=True))
            details.append({"kind": "remove_group", "field": "PmtInf", "node_id": group_id})
            return "Usunięto pustą grupę"
        if kind == "add_payment":
            group = self.index.node_for(str(payload["group_id"]))
            if group.tag != self.adapter.q("PmtInf"):
                raise ValueError("Wskazany węzeł nie jest grupą płatności.")
            tx = etree.Element(self.adapter.q("CdtTrfTxInf"))
            pmt_id = etree.SubElement(tx, self.adapter.q("PmtId"))
            etree.SubElement(pmt_id, self.adapter.q("EndToEndId"))
            amt = etree.SubElement(tx, self.adapter.q("Amt"))
            instructed = etree.SubElement(amt, self.adapter.q("InstdAmt"))
            instructed.set("Ccy", str(payload.get("currency", "")))
            group.append(tx)
            self.index.assign_subtree(tx)
            tx_id = self.index.id_for(tx)
            changes.append(HistoryChange("structure", node_id=tx_id, parent_id=self.index.id_for(group), element=tx, identities=self.index.subtree_ids(tx), position=group.index(tx), present_after=True))
            details.append({"kind": "add_payment", "field": "CdtTrfTxInf", "node_id": tx_id})
            return f"Dodano pustą płatność do grupy {short_value(text_at(group, self.adapter, 'PmtInfId'))}"
        if kind == "recalculate_totals":
            update_aggregates(self.tree, self.adapter)
            return "Przeliczono agregaty"
        if kind == "set_profile":
            profile_id = str(payload.get("profile_id", "iso-base"))
            allowed = {"iso-base", "epc-sct-2025"} | bank_profile_ids()
            if profile_id not in allowed:
                raise ValueError("Nieznany profil.")
            previous = self.profile_id
            self.profile_id = profile_id
            changes.append(HistoryChange("profile", before=previous, after=profile_id))
            details.append({"kind": "profile", "field": "profile_id", "before": previous, "after": profile_id})
            return "Zmieniono zakres walidacji"
        raise ValueError(f"Nieobsługiwany typ polecenia: {kind}")

    def _set_field(
        self,
        payload: dict[str, object],
        changes: list[HistoryChange],
        details: list[dict[str, object]],
    ) -> str:
        assert self.index is not None
        node = self.index.node_for(str(payload["node_id"]))
        attribute = payload.get("attribute")
        value = str(payload.get("value", ""))
        if local_name(node) in {"NbOfTxs", "CtrlSum"} and not attribute:
            raise ValueError("To pole jest wyliczane automatycznie i nie może być edytowane ręcznie.")
        if attribute:
            if not re_safe_tag(str(attribute)):
                raise ValueError("Niepoprawna nazwa atrybutu.")
            before = node.get(str(attribute))
            node.set(str(attribute), value)
            field_name = f"{local_name(node)}/@{attribute}"
            changes.append(HistoryChange("attribute", node_id=self.index.id_for(node), attribute=str(attribute), before=before, after=value))
        else:
            before = node.text
            node.text = value
            field_name = local_name(node)
            changes.append(HistoryChange("text", node_id=self.index.id_for(node), before=before, after=value))
        details.append({"kind": "change", "field": field_name, "before": before, "after": value, "node_id": self.index.id_for(node)})
        return f"Zmieniono {field_name}: {short_value(before)} → {short_value(value)}"

    def replace_source(self, source: str, expected_revision: int, include_payments: bool = True) -> dict[str, object]:
        with self.lock:
            if expected_revision != self.revision:
                raise RevisionConflict(self.revision)
            before = self._snapshot() if self.tree is not None and self.index is not None else None
            payload = encode_xml_source(source)
            preflight = preflight_validation(payload, self.profile_id)
            parsed = parse_xml(payload)
            self.parsed = parsed
            self.tree = parsed.tree
            self.namespace = parsed.namespace
            self.message_identifier = parsed.message_identifier
            self.adapter = adapter_for(self.namespace)
            self.index = NodeIndex(self.tree)
            self.command_results.clear()
            self.artifacts.clear()
            self.revision += 1
            self.current_report = self._adopt_report(preflight["report"], self.tree, self.index, self.revision, "working")
            if before is None:
                self.undo_stack.clear()
                self.redo_stack.clear()
            else:
                after = self._snapshot()
                self._push_history(HistoryEntry(
                    "Zastąpiono całe źródło XML",
                    details=[{"kind": "source", "field": "Document", "before": "poprzednia rewizja", "after": "nowe źródło"}],
                    before=before,
                    after=after,
                ))
            return self._view_unlocked(include_payments)

    def prepare_export(self, expected_revision: int, command_id: str) -> ExportArtifact:
        with self.lock:
            digest = hashlib.sha256(f"{expected_revision}:{self.profile_id}".encode()).hexdigest()
            if command_id in self.export_commands:
                previous_hash, artifact_id = self.export_commands[command_id]
                if previous_hash != digest:
                    raise CommandConflict("command_id eksportu został wcześniej użyty z innymi opcjami.")
                return self.artifact(artifact_id)
            if expected_revision != self.revision:
                raise RevisionConflict(self.revision)
            if self.tree is None or self.adapter is None:
                raise ValueError("Ta wiadomość nie może zostać wyeksportowana.")
            candidate_tree = copy.deepcopy(self.tree)
            assert self.index is not None
            candidate_index = NodeIndex.mirror(self.tree, candidate_tree, self.index)
            automatic_changes = update_aggregates(candidate_tree, self.adapter)
            candidate_index.assign_subtree(candidate_tree.getroot())
            payload = serialize_xml(candidate_tree)
            preflight = preflight_validation(payload, self.profile_id)
            reparsed = parse_xml(payload)
            reparsed_index = NodeIndex.mirror(candidate_tree, reparsed.tree, candidate_index)
            report = self._adopt_report(preflight["report"], reparsed.tree, reparsed_index, self.revision, "export_candidate")
            artifact_id = str(uuid4())
            safe_stem = PurePath(self.original_name).name.rsplit(".", 1)[0][:120] or "payment"
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            artifact = ExportArtifact(artifact_id, self.revision, payload, hashlib.sha256(payload).hexdigest(), f"{safe_stem}_edited_{timestamp}.xml", report, automatic_changes, datetime.now(UTC), report["warning_count"] == 0)
            self.artifacts[artifact_id] = artifact
            self.export_commands[command_id] = (digest, artifact_id)
            for old in sorted(self.artifacts.values(), key=lambda item: item.created_at)[:-2]:
                self.artifacts.pop(old.artifact_id, None)
            return artifact

    def artifact(self, artifact_id: str) -> ExportArtifact:
        artifact = self.artifacts.get(artifact_id)
        if artifact is None or datetime.now(UTC) - artifact.created_at > ARTIFACT_TTL:
            raise KeyError("Artefakt eksportu wygasł lub nie istnieje.")
        if artifact.source_revision != self.revision:
            raise RevisionConflict(self.revision)
        return artifact


class RevisionConflict(RuntimeError):
    def __init__(self, current_revision: int):
        super().__init__("Dokument zmienił się od czasu otwarcia formularza.")
        self.current_revision = current_revision


class CommandConflict(RuntimeError):
    pass


class SessionStore:
    def __init__(self) -> None:
        self.sessions: dict[str, DocumentSession] = {}
        self.lock = threading.RLock()

    def create(self, owner_id: str, name: str, payload: bytes, parsed: ParsedXml | None, syntax_issue: dict[str, object] | None = None, initial_report: dict[str, object] | None = None) -> DocumentSession:
        with self.lock:
            self._sweep_expired()
            active = [item for item in self.sessions.values() if item.owner_id == owner_id]
            if len(active) >= 3:
                raise ValueError("Limit trzech otwartych dokumentów został osiągnięty.")
            session = DocumentSession(owner_id, name[:255], payload, parsed, syntax_issue, initial_report)
            self.sessions[session.document_id] = session
            return session

    def get(self, document_id: str, owner_id: str) -> DocumentSession:
        with self.lock:
            expired_requested = document_id in self.sessions and datetime.now(UTC) - self.sessions[document_id].last_activity_at > SESSION_TTL
            self._sweep_expired()
            session = self.sessions.get(document_id)
            if session is None or session.owner_id != owner_id:
                raise KeyError("Sesja dokumentu wygasła." if expired_requested else "Dokument nie istnieje w tej sesji przeglądarki.")
            session.last_activity_at = datetime.now(UTC)
            return session

    def delete(self, document_id: str, owner_id: str) -> None:
        self.get(document_id, owner_id)
        self.sessions.pop(document_id, None)

    def delete_owner(self, owner_id: str) -> None:
        with self.lock:
            for document_id, session in list(self.sessions.items()):
                if session.owner_id == owner_id:
                    self.sessions.pop(document_id, None)

    def _sweep_expired(self) -> None:
        now = datetime.now(UTC)
        for document_id, session in list(self.sessions.items()):
            if now - session.last_activity_at > SESSION_TTL:
                self.sessions.pop(document_id, None)


def re_safe_tag(value: str) -> bool:
    import re
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", value))


def short_value(value: object, limit: int = 48) -> str:
    text = "∅" if value is None else repr(str(value))
    return text if len(text) <= limit else text[: limit - 1] + "…"
