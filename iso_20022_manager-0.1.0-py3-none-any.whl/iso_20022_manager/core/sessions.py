from __future__ import annotations

import copy
import hashlib
import json
import threading
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import PurePath
from uuid import uuid4

from lxml import etree

from iso_20022_manager.validation.engine import validate_tree

from .adapters import Adapter, adapter_for, text_at
from .parsing import ParsedXml, parse_xml, serialize_xml
from .projections import issue_counts, summary
from .totals import update_aggregates
from .xml_nodes import NodeIndex, local_name

SESSION_TTL = timedelta(hours=2)
ARTIFACT_TTL = timedelta(minutes=15)
MAX_HISTORY_COMMANDS = 100
MAX_HISTORY_BYTES = 64 * 1024 * 1024


@dataclass
class Snapshot:
    payload: bytes
    node_paths: dict[str, str]
    profile_id: str

    @property
    def size(self) -> int:
        return len(self.payload) + sum(len(key) + len(value) for key, value in self.node_paths.items())


@dataclass
class HistoryEntry:
    label: str
    before: Snapshot
    after: Snapshot

    @property
    def size(self) -> int:
        return self.before.size + self.after.size


@dataclass
class ExportArtifact:
    artifact_id: str
    source_revision: int
    payload: bytes
    sha256: str
    filename: str
    report: dict[str, object]
    created_at: datetime
    acknowledged: bool = False


@dataclass
class DocumentSession:
    owner_id: str
    original_name: str
    original_bytes: bytes
    parsed: ParsedXml | None
    syntax_issue: dict[str, object] | None = None
    document_id: str = field(default_factory=lambda: str(uuid4()))
    revision: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    last_activity_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    profile_id: str = "iso-base"
    lock: threading.RLock = field(default_factory=threading.RLock)
    undo_stack: list[HistoryEntry] = field(default_factory=list)
    redo_stack: list[HistoryEntry] = field(default_factory=list)
    command_results: dict[str, tuple[str, dict[str, object]]] = field(default_factory=dict)
    export_commands: dict[str, tuple[str, str]] = field(default_factory=dict)
    artifacts: dict[str, ExportArtifact] = field(default_factory=dict)
    current_report: dict[str, object] | None = None
    original_report: dict[str, object] | None = None

    def __post_init__(self) -> None:
        self.tree = self.parsed.tree if self.parsed else None
        self.namespace = self.parsed.namespace if self.parsed else None
        self.message_identifier = self.parsed.message_identifier if self.parsed else None
        self.adapter: Adapter | None = adapter_for(self.namespace)
        self.index = NodeIndex(self.tree) if self.tree is not None else None
        if self.tree is not None and self.index is not None:
            self.original_report = self._validate(self.original_bytes, "original")
            self.current_report = self.original_report
        else:
            self.original_report = self.current_report = self._syntax_report()

    @property
    def original_sha256(self) -> str:
        return hashlib.sha256(self.original_bytes).hexdigest()

    @property
    def dirty(self) -> bool:
        return self.revision > 0

    def _syntax_report(self) -> dict[str, object]:
        issue = self.syntax_issue or {"message_pl": "Nie można sparsować dokumentu XML.", "line": None, "column": None}
        return {
            "report_id": str(uuid4()), "document_id": self.document_id, "revision": self.revision, "validated_view": "original",
            "payload_sha256": self.original_sha256, "created_at": datetime.now(UTC).isoformat(),
            "schema_sha256": None, "rule_bundle_id": "iso-base-2026.09", "engine_versions": {"lxml": ".".join(map(str, etree.LXML_VERSION)), "libxml2": ".".join(map(str, etree.LIBXML_VERSION))},
            "code_set_versions": [], "profiles": [{"profile_id": self.profile_id, "status": "not_run"}],
            "validation_context": {"analysis_date": datetime.now(UTC).date().isoformat(), "requested_execution_date": None, "expected_inter_psp_settlement_date": None},
            "layers": [
                {"id": "L0", "name": "Bezpieczeństwo wejścia", "status": "pass", "checked": 1},
                {"id": "L1", "name": "Składnia XML", "status": "fail", "checked": 1},
                {"id": "L2", "name": "Identyfikacja", "status": "not_run", "checked": 0},
            ],
            "issues": [{
                "issue_id": str(uuid4()), "rule_id": "XML_SYNTAX", "severity": "error", "category": "xml",
                "document_revision": self.revision, "transaction_id": None, "group_id": None, "node_id": None, "field_id": None,
                "xpath": None, "location": {"view": "original", "line": issue.get("line"), "column": issue.get("column")},
                "message_pl": issue["message_pl"], "raw_message": issue.get("raw_message"), "source": {"kind": "parser"},
                "expected": None, "actual_summary": None, "suggestion": None, "auto_fixable": False,
            }],
            "error_count": 1, "warning_count": 0, "incomplete": True, "can_export_in_scope": False,
            "blocking_reasons": ["XML_SYNTAX"], "coverage": {"not_run": ["XSD", "business", "profile"]},
        }

    def _validate(self, payload: bytes | None = None, view: str = "working", tree: etree._ElementTree | None = None, index: NodeIndex | None = None) -> dict[str, object]:
        active_tree = tree or self.tree
        active_index = index or self.index
        assert active_tree is not None and active_index is not None
        return validate_tree(active_tree, self.namespace, self.adapter, active_index, self.revision, payload or serialize_xml(active_tree), validated_view=view, profile_id=self.profile_id, document_id=self.document_id)

    def view(self, include_payments: bool = True) -> dict[str, object]:
        self.last_activity_at = datetime.now(UTC)
        base: dict[str, object] = {
            "document_id": self.document_id,
            "original_name": self.original_name,
            "original_sha256": self.original_sha256,
            "namespace": self.namespace,
            "message_identifier": self.message_identifier,
            "revision": self.revision,
            "mode": "editable" if self.adapter and self.tree is not None else ("syntax_error" if self.tree is None else "unsupported"),
            "dirty": self.dirty,
            "profile_id": self.profile_id,
            "can_undo": bool(self.undo_stack),
            "can_redo": bool(self.redo_stack),
            "history": [{"label": item.label} for item in reversed(self.undo_stack[-20:])],
            "report": self.current_report,
            "original_report": self.original_report,
        }
        if self.tree is not None and self.adapter is not None and self.index is not None:
            counts = issue_counts((self.current_report or {}).get("issues", []))
            projected = summary(self.tree, self.adapter, self.index, counts)
            if not include_payments:
                projected.pop("payments", None)
            base.update(projected)
        else:
            base.update({"header": {}, "groups": [], "payments": [], "totals": {"count": 0, "control_sum": None, "by_currency": {}, "complete": False}})
        return base

    def source(self, original: bool = False) -> str:
        payload = self.original_bytes if original or self.tree is None else serialize_xml(self.tree)
        return payload.decode("utf-8", errors="replace")

    def validate(self) -> dict[str, object]:
        if self.tree is None:
            self.current_report = self._syntax_report()
        else:
            self.current_report = self._validate()
        return self.current_report

    def _snapshot(self) -> Snapshot:
        assert self.tree is not None and self.index is not None
        return Snapshot(serialize_xml(self.tree), self.index.snapshot_paths(self.tree), self.profile_id)

    def _restore(self, snapshot: Snapshot) -> None:
        parsed = parse_xml(snapshot.payload)
        self.tree = parsed.tree
        self.namespace = parsed.namespace
        self.message_identifier = parsed.message_identifier
        self.adapter = adapter_for(self.namespace)
        self.index = NodeIndex.restore(self.tree, snapshot.node_paths)
        self.profile_id = snapshot.profile_id

    def _push_history(self, entry: HistoryEntry) -> None:
        self.undo_stack.append(entry)
        while len(self.undo_stack) > MAX_HISTORY_COMMANDS or sum(item.size for item in self.undo_stack) > MAX_HISTORY_BYTES:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def command(self, command: dict[str, object]) -> dict[str, object]:
        with self.lock:
            command_id = str(command["command_id"])
            digest = hashlib.sha256(json.dumps(command, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if command_id in self.command_results:
                previous_hash, response = self.command_results[command_id]
                if previous_hash != digest:
                    raise CommandConflict("command_id został wcześniej użyty z inną treścią.")
                return {**response, "idempotent_replay": True, "current_revision": self.revision, "document": self.view()}
            if int(command["expected_revision"]) != self.revision:
                raise RevisionConflict(self.revision)
            if self.tree is None or self.adapter is None or self.index is None:
                raise ValueError("Dokument nie jest dostępny w trybie edycji.")
            kind = str(command["type"])
            if kind == "undo":
                result = self._undo()
            elif kind == "redo":
                result = self._redo()
            else:
                before = self._snapshot()
                label = self._apply(kind, dict(command.get("payload") or {}))
                aggregate_changes = update_aggregates(self.tree, self.adapter)
                if aggregate_changes:
                    label += f"; automatycznie zmieniono agregaty: {len(aggregate_changes)}"
                self.index.assign_subtree(self.tree.getroot())
                after = self._snapshot()
                self._push_history(HistoryEntry(label, before, after))
                self.revision += 1
                self.artifacts.clear()
                self.current_report = self._validate()
                result = {"applied_revision": self.revision, "current_revision": self.revision, "label": label, "document": self.view()}
            self.command_results[command_id] = (digest, result)
            return result

    def _undo(self) -> dict[str, object]:
        if not self.undo_stack:
            raise ValueError("Brak operacji do cofnięcia.")
        entry = self.undo_stack.pop()
        self._restore(entry.before)
        self.redo_stack.append(entry)
        self.revision += 1
        self.artifacts.clear()
        self.current_report = self._validate()
        return {"applied_revision": self.revision, "current_revision": self.revision, "label": f"Cofnięto: {entry.label}", "document": self.view()}

    def _redo(self) -> dict[str, object]:
        if not self.redo_stack:
            raise ValueError("Brak operacji do ponowienia.")
        entry = self.redo_stack.pop()
        self._restore(entry.after)
        self.undo_stack.append(entry)
        self.revision += 1
        self.artifacts.clear()
        self.current_report = self._validate()
        return {"applied_revision": self.revision, "current_revision": self.revision, "label": f"Ponowiono: {entry.label}", "document": self.view()}

    def _apply(self, kind: str, payload: dict[str, object]) -> str:
        assert self.tree is not None and self.index is not None and self.adapter is not None
        if kind == "set_field":
            node = self.index.node_for(str(payload["node_id"]))
            attribute = payload.get("attribute")
            value = str(payload.get("value", ""))
            if attribute:
                before = node.get(str(attribute))
                node.set(str(attribute), value)
                field = f"{local_name(node)}/@{attribute}"
            else:
                before = node.text
                node.text = value
                field = local_name(node)
            return f"Zmieniono {field}: {short_value(before)} → {short_value(value)}"
        if kind == "insert_element":
            parent = self.index.node_for(str(payload["parent_node_id"]))
            local = str(payload["tag"])
            if not re_safe_tag(local):
                raise ValueError("Niepoprawna nazwa elementu.")
            child = etree.Element(self.adapter.q(local))
            child.text = str(payload.get("value", ""))
            position = int(payload.get("position", len(parent)))
            parent.insert(max(0, min(position, len(parent))), child)
            self.index.assign_subtree(child)
            return f"Dodano pole {local} w {local_name(parent)}"
        if kind == "remove_element":
            node = self.index.node_for(str(payload["node_id"]))
            parent = node.getparent()
            if parent is None:
                raise ValueError("Nie można usunąć korzenia dokumentu.")
            self.index.forget_subtree(node)
            parent.remove(node)
            return f"Usunięto pole {local_name(node)}"
        if kind == "select_choice":
            parent = self.index.node_for(str(payload["parent_node_id"]))
            for node_id in payload.get("remove_node_ids", []):
                node = self.index.node_for(str(node_id))
                if node.getparent() is not parent:
                    raise ValueError("Gałąź choice nie należy do wskazanego rodzica.")
                self.index.forget_subtree(node)
                parent.remove(node)
            local = str(payload["tag"])
            if not re_safe_tag(local):
                raise ValueError("Niepoprawna nazwa elementu.")
            child = etree.Element(self.adapter.q(local))
            child.text = str(payload.get("value", ""))
            position = max(0, min(int(payload.get("position", len(parent))), len(parent)))
            parent.insert(position, child)
            self.index.assign_subtree(child)
            return f"Wybrano gałąź {local}"
        if kind == "duplicate_payment":
            tx = self.index.node_for(str(payload["transaction_id"]))
            if tx.tag != self.adapter.q("CdtTrfTxInf"):
                raise ValueError("Wskazany węzeł nie jest płatnością.")
            duplicate = copy.deepcopy(tx)
            parent = tx.getparent()
            assert parent is not None
            parent.insert(parent.index(tx) + 1, duplicate)
            self.index.assign_subtree(duplicate)
            reference = text_at(tx, self.adapter, "PmtId/EndToEndId")
            return f"Zduplikowano płatność {short_value(reference)} (referencje XML zachowane)"
        if kind == "delete_payments":
            ids = [str(item) for item in payload.get("transaction_ids", [])]
            if not ids:
                raise ValueError("Nie wskazano płatności do usunięcia.")
            nodes = [self.index.node_for(item) for item in ids]
            if any(node.tag != self.adapter.q("CdtTrfTxInf") for node in nodes):
                raise ValueError("Lista zawiera węzeł, który nie jest płatnością.")
            references = [text_at(node, self.adapter, "PmtId/EndToEndId") for node in nodes]
            for node in nodes:
                parent = node.getparent()
                assert parent is not None
                self.index.forget_subtree(node)
                parent.remove(node)
            shown = ", ".join(short_value(item) for item in references[:5])
            suffix = ", …" if len(references) > 5 else ""
            return f"Usunięto płatności: {len(nodes)} ({shown}{suffix})"
        if kind == "delete_empty_group":
            group = self.index.node_for(str(payload["group_id"]))
            if group.tag != self.adapter.q("PmtInf"):
                raise ValueError("Wskazany węzeł nie jest grupą płatności.")
            if self.adapter.children(group, "CdtTrfTxInf"):
                raise ValueError("Można usunąć tylko pustą grupę.")
            parent = group.getparent()
            assert parent is not None
            self.index.forget_subtree(group)
            parent.remove(group)
            return "Usunięto pustą grupę"
        if kind == "add_payment":
            group = self.index.node_for(str(payload["group_id"]))
            if group.tag != self.adapter.q("PmtInf"):
                raise ValueError("Wskazany węzeł nie jest grupą płatności.")
            tx = etree.Element(self.adapter.q("CdtTrfTxInf"))
            pmt_id = etree.SubElement(tx, self.adapter.q("PmtId"))
            etree.SubElement(pmt_id, self.adapter.q("EndToEndId"))
            amt = etree.SubElement(tx, self.adapter.q("Amt"))
            instructed = etree.SubElement(amt, self.adapter.q("InstdAmt"))
            instructed.set("Ccy", str(payload.get("currency", "")))
            group.append(tx)
            self.index.assign_subtree(tx)
            return f"Dodano pustą płatność do grupy {short_value(text_at(group, self.adapter, 'PmtInfId'))}"
        if kind == "recalculate_totals":
            update_aggregates(self.tree, self.adapter)
            return "Przeliczono agregaty"
        if kind == "set_profile":
            profile_id = str(payload.get("profile_id", "iso-base"))
            allowed = {"iso-base", "epc-sct-2025-partial", "mbank-companynet-unverified", "mbank-swiftnet-unverified", "ing-pl-unverified", "ing-insidebusiness-unverified", "citidirect-unverified"}
            if profile_id not in allowed:
                raise ValueError("Nieznany profil.")
            self.profile_id = profile_id
            return "Zmieniono zakres walidacji"
        raise ValueError(f"Nieobsługiwany typ polecenia: {kind}")

    def replace_source(self, source: str, expected_revision: int) -> dict[str, object]:
        with self.lock:
            if expected_revision != self.revision:
                raise RevisionConflict(self.revision)
            payload = source.encode("utf-8")
            parsed = parse_xml(payload)
            self.parsed = parsed
            self.tree = parsed.tree
            self.namespace = parsed.namespace
            self.message_identifier = parsed.message_identifier
            self.adapter = adapter_for(self.namespace)
            self.index = NodeIndex(self.tree)
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.command_results.clear()
            self.artifacts.clear()
            self.revision += 1
            self.current_report = self._validate()
            return self.view()

    def prepare_export(self, expected_revision: int, command_id: str) -> ExportArtifact:
        with self.lock:
            digest = hashlib.sha256(f"{expected_revision}:{self.profile_id}".encode()).hexdigest()
            if command_id in self.export_commands:
                previous_hash, artifact_id = self.export_commands[command_id]
                if previous_hash != digest:
                    raise CommandConflict("command_id eksportu został wcześniej użyty z innymi opcjami.")
                return self.artifact(artifact_id)
            if expected_revision != self.revision:
                raise RevisionConflict(self.revision)
            if self.tree is None or self.adapter is None:
                raise ValueError("Ta wiadomość nie może zostać wyeksportowana.")
            candidate_root = copy.deepcopy(self.tree.getroot())
            candidate_tree = etree.ElementTree(candidate_root)
            update_aggregates(candidate_tree, self.adapter)
            payload = serialize_xml(candidate_tree)
            reparsed = parse_xml(payload)
            candidate_index = NodeIndex(reparsed.tree)
            report = validate_tree(reparsed.tree, reparsed.namespace, adapter_for(reparsed.namespace), candidate_index, self.revision, payload, validated_view="export_candidate", profile_id=self.profile_id, document_id=self.document_id)
            artifact_id = str(uuid4())
            safe_stem = PurePath(self.original_name).name.rsplit(".", 1)[0][:120] or "payment"
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            artifact = ExportArtifact(artifact_id, self.revision, payload, hashlib.sha256(payload).hexdigest(), f"{safe_stem}_edited_{timestamp}.xml", report, datetime.now(UTC), report["warning_count"] == 0)
            self.artifacts[artifact_id] = artifact
            self.export_commands[command_id] = (digest, artifact_id)
            for old in sorted(self.artifacts.values(), key=lambda item: item.created_at)[:-2]:
                self.artifacts.pop(old.artifact_id, None)
            return artifact

    def artifact(self, artifact_id: str) -> ExportArtifact:
        artifact = self.artifacts.get(artifact_id)
        if artifact is None or datetime.now(UTC) - artifact.created_at > ARTIFACT_TTL:
            raise KeyError("Artefakt eksportu wygasł lub nie istnieje.")
        if artifact.source_revision != self.revision:
            raise RevisionConflict(self.revision)
        return artifact


class RevisionConflict(RuntimeError):
    def __init__(self, current_revision: int):
        super().__init__("Dokument zmienił się od czasu otwarcia formularza.")
        self.current_revision = current_revision


class CommandConflict(RuntimeError):
    pass


class SessionStore:
    def __init__(self) -> None:
        self.sessions: dict[str, DocumentSession] = {}
        self.lock = threading.RLock()

    def create(self, owner_id: str, name: str, payload: bytes, parsed: ParsedXml | None, syntax_issue: dict[str, object] | None = None) -> DocumentSession:
        with self.lock:
            active = [item for item in self.sessions.values() if item.owner_id == owner_id and datetime.now(UTC) - item.last_activity_at <= SESSION_TTL]
            if len(active) >= 3:
                raise ValueError("Limit trzech otwartych dokumentów został osiągnięty.")
            session = DocumentSession(owner_id, name[:255], payload, parsed, syntax_issue)
            self.sessions[session.document_id] = session
            return session

    def get(self, document_id: str, owner_id: str) -> DocumentSession:
        session = self.sessions.get(document_id)
        if session is None or session.owner_id != owner_id:
            raise KeyError("Dokument nie istnieje w tej sesji przeglądarki.")
        if datetime.now(UTC) - session.last_activity_at > SESSION_TTL:
            self.sessions.pop(document_id, None)
            raise KeyError("Sesja dokumentu wygasła.")
        session.last_activity_at = datetime.now(UTC)
        return session

    def delete(self, document_id: str, owner_id: str) -> None:
        self.get(document_id, owner_id)
        self.sessions.pop(document_id, None)


def re_safe_tag(value: str) -> bool:
    import re
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", value))


def short_value(value: object, limit: int = 48) -> str:
    text = "∅" if value is None else repr(str(value))
    return text if len(text) <= limit else text[: limit - 1] + "…"
