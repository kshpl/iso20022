from __future__ import annotations

from itertools import zip_longest
from uuid import uuid4

from lxml import etree


class NodeIndex:
    def __init__(self, tree: etree._ElementTree):
        self.by_id: dict[str, etree._Element] = {}
        self.by_node: dict[etree._Element, str] = {}
        self.assign_subtree(tree.getroot())

    def assign_subtree(self, root: etree._Element) -> None:
        for node in root.iter():
            if isinstance(node.tag, str) and node not in self.by_node:
                node_id = str(uuid4())
                self.by_node[node] = node_id
                self.by_id[node_id] = node

    def id_for(self, node: etree._Element | None) -> str | None:
        return self.by_node.get(node) if node is not None else None

    def node_for(self, node_id: str) -> etree._Element:
        try:
            return self.by_id[node_id]
        except KeyError as exc:
            raise KeyError("Nieznany identyfikator węzła w tej rewizji.") from exc

    def forget_subtree(self, root: etree._Element) -> None:
        for node in list(root.iter()):
            node_id = self.by_node.pop(node, None)
            if node_id:
                self.by_id.pop(node_id, None)

    def subtree_ids(self, root: etree._Element) -> dict[etree._Element, str]:
        return {
            node: self.by_node[node]
            for node in root.iter()
            if isinstance(node.tag, str) and node in self.by_node
        }

    def restore_subtree_ids(self, root: etree._Element, identities: dict[etree._Element, str]) -> None:
        for node in root.iter():
            if not isinstance(node.tag, str):
                continue
            node_id = identities.get(node)
            if node_id is None:
                node_id = str(uuid4())
            self.by_node[node] = node_id
            self.by_id[node_id] = node

    def snapshot_paths(self, tree: etree._ElementTree) -> dict[str, str]:
        # ElementTree paths use Clark notation and are independent of whatever
        # namespace prefix the source document happened to declare.
        return {tree.getelementpath(node): node_id for node, node_id in self.by_node.items()}

    @classmethod
    def restore(cls, tree: etree._ElementTree, paths: dict[str, str]) -> "NodeIndex":
        index = cls.__new__(cls)
        index.by_id = {}
        index.by_node = {}
        for node in tree.getroot().iter():
            if not isinstance(node.tag, str):
                continue
            node_id = paths.get(tree.getelementpath(node))
            if node_id is not None:
                index.by_id[node_id] = node
                index.by_node[node] = node_id
        index.assign_subtree(tree.getroot())
        return index

    @classmethod
    def mirror(cls, source_tree: etree._ElementTree, target_tree: etree._ElementTree, source: "NodeIndex") -> "NodeIndex":
        index = cls.__new__(cls)
        index.by_id = {}
        index.by_node = {}
        source_nodes = (node for node in source_tree.getroot().iter() if isinstance(node.tag, str))
        target_nodes = (node for node in target_tree.getroot().iter() if isinstance(node.tag, str))
        sentinel = object()
        for source_node, target_node in zip_longest(source_nodes, target_nodes, fillvalue=sentinel):
            if source_node is sentinel or target_node is sentinel or source_node.tag != target_node.tag:
                raise ValueError("Nie można odtworzyć tożsamości węzłów: struktura dokumentu się różni.")
            node_id = source.id_for(source_node)
            if node_id is not None:
                index.by_id[node_id] = target_node
                index.by_node[target_node] = node_id
        index.assign_subtree(target_tree.getroot())
        return index


def local_name(node: etree._Element) -> str:
    return etree.QName(node).localname if isinstance(node.tag, str) else str(node.tag)


def xpath_for(tree: etree._ElementTree, node: etree._Element) -> str:
    return tree.getpath(node)


def ancestor_named(node: etree._Element | None, namespace: str, name: str) -> etree._Element | None:
    current = node
    qname = f"{{{namespace}}}{name}"
    while current is not None:
        if current.tag == qname:
            return current
        current = current.getparent()
    return None


def node_tree(node: etree._Element, index: NodeIndex, tree: etree._ElementTree, model: object | None = None, exclude_tags: set[str] | None = None, profile_id: str = "iso-base", bank_constraints: dict | None = None) -> dict[str, object]:
    if bank_constraints is None:
        from iso_20022_manager.core.adapters import adapter_for
        from iso_20022_manager.validation.bank_lengths import bank_length_constraints

        adapter = adapter_for(etree.QName(tree.getroot()).namespace)
        bank_constraints = bank_length_constraints(tree, adapter, profile_id) if adapter is not None else {}
    exclude_tags = exclude_tags or set()
    children = [
        node_tree(child, index, tree, model, exclude_tags, profile_id, bank_constraints)
        for child in node
        if isinstance(child.tag, str) and etree.QName(child).localname not in exclude_tags
    ]
    result = {
        "node_id": index.id_for(node),
        "tag": local_name(node),
        "qname": node.tag,
        "path": xpath_for(tree, node),
        "text": node.text,
        "attributes": dict(node.attrib),
        "children": children,
    }
    if model is not None:
        schema, available = model.metadata(node)
        if bank_constraints.get(node):
            schema = dict(schema or {})
            schema["bank_constraints"] = bank_constraints[node]
        type_name = str((schema or {}).get("type") or "")
        if type_name.startswith("External"):
            from iso_20022_manager.validation.code_sets import external_code_catalog

            catalog, metadata = external_code_catalog()
            if type_name in catalog:
                # Only a reference: one dictionary can have hundreds of codes and
                # repeating it on every node made large groups megabytes long.
                # The response carries each set once, see referenced_code_sets().
                schema["external_code_set"] = type_name
                schema["code_set_version"] = metadata["snapshot_id"]
        available = [field for field in available if field["tag"] not in exclude_tags]
        for field in available:
            replace_tags = set(field.pop("replace_tags", []))
            field["replace_node_ids"] = [
                index.id_for(child)
                for child in node
                if isinstance(child.tag, str) and local_name(child) in replace_tags
            ]
        result["schema"] = schema
        result["available_children"] = available
    return result


def referenced_code_sets(*trees: dict[str, object] | None) -> dict[str, list[dict[str, str]]]:
    from iso_20022_manager.validation.code_sets import external_code_catalog

    catalog, _ = external_code_catalog()
    names: set[str] = set()
    stack = [tree for tree in trees if tree]
    while stack:
        node = stack.pop()
        name = (node.get("schema") or {}).get("external_code_set")
        if name:
            names.add(str(name))
        stack.extend(node["children"])
    return {name: catalog[name] for name in sorted(names)}
