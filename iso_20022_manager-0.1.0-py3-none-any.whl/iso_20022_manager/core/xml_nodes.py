from __future__ import annotations

from uuid import uuid4

from lxml import etree


class NodeIndex:
    def __init__(self, tree: etree._ElementTree):
        self.by_id: dict[str, etree._Element] = {}
        self.by_node: dict[etree._Element, str] = {}
        self.assign_subtree(tree.getroot())

    def assign_subtree(self, root: etree._Element) -> None:
        for node in root.iter():
            if isinstance(node.tag, str) and node not in self.by_node:
                node_id = str(uuid4())
                self.by_node[node] = node_id
                self.by_id[node_id] = node

    def id_for(self, node: etree._Element | None) -> str | None:
        return self.by_node.get(node) if node is not None else None

    def node_for(self, node_id: str) -> etree._Element:
        try:
            return self.by_id[node_id]
        except KeyError as exc:
            raise KeyError("Nieznany identyfikator węzła w tej rewizji.") from exc

    def forget_subtree(self, root: etree._Element) -> None:
        for node in list(root.iter()):
            node_id = self.by_node.pop(node, None)
            if node_id:
                self.by_id.pop(node_id, None)

    def snapshot_paths(self, tree: etree._ElementTree) -> dict[str, str]:
        return {tree.getpath(node): node_id for node, node_id in self.by_node.items()}

    @classmethod
    def restore(cls, tree: etree._ElementTree, paths: dict[str, str]) -> "NodeIndex":
        index = cls.__new__(cls)
        index.by_id = {}
        index.by_node = {}
        for path, node_id in paths.items():
            matches = tree.xpath(path)
            if len(matches) == 1 and isinstance(matches[0], etree._Element):
                index.by_id[node_id] = matches[0]
                index.by_node[matches[0]] = node_id
        index.assign_subtree(tree.getroot())
        return index


def local_name(node: etree._Element) -> str:
    return etree.QName(node).localname if isinstance(node.tag, str) else str(node.tag)


def xpath_for(tree: etree._ElementTree, node: etree._Element) -> str:
    return tree.getpath(node)


def ancestor_named(node: etree._Element | None, namespace: str, name: str) -> etree._Element | None:
    current = node
    qname = f"{{{namespace}}}{name}"
    while current is not None:
        if current.tag == qname:
            return current
        current = current.getparent()
    return None


def node_tree(node: etree._Element, index: NodeIndex, tree: etree._ElementTree, model: object | None = None, exclude_tags: set[str] | None = None) -> dict[str, object]:
    exclude_tags = exclude_tags or set()
    children = [
        node_tree(child, index, tree, model, exclude_tags)
        for child in node
        if isinstance(child.tag, str) and etree.QName(child).localname not in exclude_tags
    ]
    result = {
        "node_id": index.id_for(node),
        "tag": local_name(node),
        "qname": node.tag,
        "path": xpath_for(tree, node),
        "text": node.text,
        "attributes": dict(node.attrib),
        "children": children,
    }
    if model is not None:
        schema, available = model.metadata(node)
        result["schema"] = schema
        result["available_children"] = available
    return result
