from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from functools import wraps
from typing import Callable, Iterator, TypeVar

from lxml import etree


@dataclass(frozen=True)
class Adapter:
    message_identifier: str
    namespace: str
    execution_date_paths: tuple[str, ...]
    bic_tag: str

    def q(self, local: str) -> str:
        return f"{{{self.namespace}}}{local}"

    def child(self, parent: etree._Element, local: str) -> etree._Element | None:
        return find_first(parent, self.q(local))

    def children(self, parent: etree._Element, local: str) -> list[etree._Element]:
        return find_every(parent, self.q(local))


ADAPTERS = {
    "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03": Adapter(
        "pain.001.001.03", "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03", ("ReqdExctnDt",), "BIC"
    ),
    "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09": Adapter(
        "pain.001.001.09", "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09", ("ReqdExctnDt/Dt", "ReqdExctnDt/DtTm"), "BICFI"
    ),
}


def adapter_for(namespace: str | None) -> Adapter | None:
    return ADAPTERS.get(namespace or "")


def text_at(parent: etree._Element | None, adapter: Adapter, path: str) -> str | None:
    if parent is None:
        return None
    node = find_first(parent, "/".join(adapter.q(part) for part in path.split("/")))
    return node.text if node is not None else None


# lxml's find(), findall(), iterchildren(tag=...) and len() visit every child of
# the element. A PmtInf holding thousands of CdtTrfTxInf therefore made each
# group lookup O(payments), and the lookups done once per payment O(payments²).
# Inside a read-only lookup scope these wide containers get a per-tag index of
# their children, built once. Nothing may change the tree while a scope is open.
_WIDE_CONTAINERS = ("}PmtInf", "}CstmrCdtTrfInitn")
_scope: ContextVar[dict[str, dict] | None] = ContextVar("iso20022_lookup_scope", default=None)

F = TypeVar("F", bound=Callable)


@contextmanager
def lookup_scope() -> Iterator[None]:
    if _scope.get() is not None:
        yield
        return
    token = _scope.set({"children": {}, "paths": {}, "positions": {}})
    try:
        yield
    finally:
        _scope.reset(token)


def read_only_lookups(function: F) -> F:
    @wraps(function)
    def wrapper(*args, **kwargs):
        with lookup_scope():
            return function(*args, **kwargs)
    return wrapper  # type: ignore[return-value]


def scope_cache(name: str) -> dict | None:
    caches = _scope.get()
    return caches[name] if caches is not None else None


def _indexed_children(parent: etree._Element, tag: str) -> list[etree._Element] | None:
    cache = scope_cache("children")
    parent_tag = parent.tag
    if cache is None or not isinstance(parent_tag, str) or not parent_tag.endswith(_WIDE_CONTAINERS):
        return None
    index = cache.get(parent)
    if index is None:
        index = {}
        for child in parent:
            index.setdefault(child.tag, []).append(child)
        cache[parent] = index
    return index.get(tag, [])


def _simple_path(query: str) -> bool:
    return not query.startswith(".") and "//" not in query and "[" not in query


def find_first(parent: etree._Element, query: str) -> etree._Element | None:
    """parent.find(query) for a child path like "{ns}A/{ns}B"; same first match."""
    if not _simple_path(query):
        return parent.find(query)
    first, _, rest = query.partition("/")
    candidates = _indexed_children(parent, first)
    if candidates is None:
        return parent.find(query)
    for child in candidates:
        found = child.find(rest) if rest else child
        if found is not None:
            return found
    return None


def find_every(parent: etree._Element, query: str) -> list[etree._Element]:
    """parent.findall(query) for a child path; same nodes in document order."""
    if not _simple_path(query):
        return list(parent.findall(query))
    first, _, rest = query.partition("/")
    candidates = _indexed_children(parent, first)
    if candidates is None:
        return list(parent.findall(query))
    if not rest:
        return list(candidates)
    return [found for child in candidates for found in child.findall(rest)]
