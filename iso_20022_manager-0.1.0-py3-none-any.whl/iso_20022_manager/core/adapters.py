from __future__ import annotations

from dataclasses import dataclass

from lxml import etree


@dataclass(frozen=True)
class Adapter:
    message_identifier: str
    namespace: str
    execution_date_paths: tuple[str, ...]
    bic_tag: str

    def q(self, local: str) -> str:
        return f"{{{self.namespace}}}{local}"

    def child(self, parent: etree._Element, local: str) -> etree._Element | None:
        return parent.find(self.q(local))

    def children(self, parent: etree._Element, local: str) -> list[etree._Element]:
        return list(parent.findall(self.q(local)))


ADAPTERS = {
    "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03": Adapter(
        "pain.001.001.03", "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03", ("ReqdExctnDt",), "BIC"
    ),
    "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09": Adapter(
        "pain.001.001.09", "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09", ("ReqdExctnDt/Dt", "ReqdExctnDt/DtTm"), "BICFI"
    ),
}


def adapter_for(namespace: str | None) -> Adapter | None:
    return ADAPTERS.get(namespace or "")


def text_at(parent: etree._Element | None, adapter: Adapter, path: str) -> str | None:
    if parent is None:
        return None
    node = parent.find("/".join(adapter.q(part) for part in path.split("/")))
    return node.text if node is not None else None
