"""Pure Nordic reference checks, shared by importer and Composer."""


def mod10_ok(value: str) -> bool:
    if not value or any(char not in "0123456789" for char in value):
        return False
    total = 0
    for index, char in enumerate(reversed(value)):
        product = int(char) * (1 if index % 2 == 0 else 2)
        total += product // 10 + product % 10
    return total % 10 == 0


def mod11_ok(value: str) -> bool:
    if len(value) < 2 or any(char not in "0123456789" for char in value):
        return False
    body, check = value[:-1], int(value[-1])
    total = sum(int(char) * (2 + index % 6) for index, char in enumerate(reversed(body)))
    remainder = 11 - total % 11
    expected = 0 if remainder == 11 else remainder
    return expected != 10 and check == expected
