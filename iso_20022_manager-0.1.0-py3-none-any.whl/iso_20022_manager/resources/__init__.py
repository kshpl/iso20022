"""Versioned local schemas, profiles, and reference data."""
