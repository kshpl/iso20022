"""Bundled schema registry."""
