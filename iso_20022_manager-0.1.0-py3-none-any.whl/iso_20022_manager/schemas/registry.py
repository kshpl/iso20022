from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files
from pathlib import Path

from lxml import etree

_schema_locks: dict[str, threading.RLock] = {}
_schema_locks_guard = threading.RLock()


@dataclass(frozen=True)
class SchemaEntry:
    message_identifier: str
    namespace: str
    path: Path
    sha256: str
    source_url: str
    verification_status: str
    capabilities: dict[str, bool]


class LocalOnlyResolver(etree.Resolver):
    def resolve(self, url: str, public_id: str | None, context: object) -> object:
        raise OSError(f"Zewnętrzna zależność XSD jest niedozwolona: {url}")


def _resource_root() -> Path:
    return Path(str(files("iso_20022_manager").joinpath("resources", "schemas")))


@lru_cache(maxsize=1)
def entries() -> dict[str, SchemaEntry]:
    root = _resource_root()
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    result: dict[str, SchemaEntry] = {}
    for raw in manifest["schemas"]:
        path = root / raw["local_path"]
        payload = path.read_bytes()
        actual = hashlib.sha256(payload).hexdigest()
        if actual != raw["sha256"]:
            raise RuntimeError(f"Niezgodny hash schemy {raw['message_identifier']}")
        parsed = etree.parse(str(path), etree.XMLParser(resolve_entities=False, load_dtd=False, no_network=True))
        target = parsed.getroot().get("targetNamespace")
        if target != raw["namespace"]:
            raise RuntimeError(f"Niezgodny namespace schemy {raw['message_identifier']}")
        result[raw["namespace"]] = SchemaEntry(
            message_identifier=raw["message_identifier"],
            namespace=raw["namespace"],
            path=path,
            sha256=raw["sha256"],
            source_url=raw["source_url"],
            verification_status=raw["verification_status"],
            capabilities=raw["capabilities"],
        )
    return result


@lru_cache(maxsize=4)
def compiled_schema(namespace: str) -> etree.XMLSchema:
    entry = entries()[namespace]
    parser = etree.XMLParser(resolve_entities=False, load_dtd=False, no_network=True)
    parser.resolvers.add(LocalOnlyResolver())
    root = etree.fromstring(entry.path.read_bytes(), parser)
    return etree.XMLSchema(etree.ElementTree(root))


def validate_document(namespace: str, tree: etree._ElementTree) -> tuple[bool, list[etree._LogEntry]]:
    """Validate and copy the mutable libxml2 error log under a per-schema lock."""
    with _schema_locks_guard:
        lock = _schema_locks.setdefault(namespace, threading.RLock())
    with lock:
        schema = compiled_schema(namespace)
        valid = schema.validate(tree)
        errors = list(schema.error_log)
    return valid, errors


def registry_health() -> list[dict[str, object]]:
    output = []
    for item in entries().values():
        compiled_schema(item.namespace)
        output.append({
            "message_identifier": item.message_identifier,
            "namespace": item.namespace,
            "sha256": item.sha256,
            "verification_status": item.verification_status,
            "capabilities": item.capabilities,
            "status": "ready",
        })
    return output
