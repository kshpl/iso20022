from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from lxml import etree

from .registry import entries

XSD = "{http://www.w3.org/2001/XMLSchema}"


@dataclass(frozen=True)
class Declaration:
    name: str
    type_name: str | None
    min_occurs: int
    max_occurs: int | None
    order: int
    choice: str | None


@dataclass(frozen=True)
class AttributeDeclaration:
    name: str
    type_name: str | None
    required: bool


class SchemaModel:
    def __init__(self, namespace: str):
        entry = entries()[namespace]
        root = etree.parse(str(entry.path)).getroot()
        self.namespace = namespace
        self.types: dict[str, list[Declaration]] = {}
        self.facets: dict[str, dict[str, object]] = {}
        self.attributes: dict[str, list[AttributeDeclaration]] = {}
        self.simple_content_bases: dict[str, str] = {}
        self.root_types = {node.get("name"): node.get("type") for node in root.findall(f"{XSD}element")}
        for simple in root.findall(f"{XSD}simpleType"):
            restriction = simple.find(f"{XSD}restriction")
            if restriction is None or not simple.get("name"):
                continue
            data: dict[str, object] = {"base": restriction.get("base")}
            enums = [item.get("value") for item in restriction.findall(f"{XSD}enumeration")]
            if enums:
                data["enumeration"] = enums
            for facet in ("minLength", "maxLength", "length", "pattern", "minInclusive", "maxInclusive", "totalDigits", "fractionDigits", "whiteSpace"):
                node = restriction.find(f"{XSD}{facet}")
                if node is not None:
                    data[facet] = node.get("value")
            self.facets[simple.get("name")] = data
        for complex_type in root.findall(f"{XSD}complexType"):
            name = complex_type.get("name")
            if not name:
                continue
            declarations: list[Declaration] = []
            self._walk_particles(complex_type, declarations, None)
            self.types[name] = declarations
            extension = complex_type.find(f"{XSD}simpleContent/{XSD}extension")
            attribute_parent = extension if extension is not None else complex_type
            if extension is not None and extension.get("base"):
                self.simple_content_bases[name] = extension.get("base").split(":")[-1]
            self.attributes[name] = [
                AttributeDeclaration(
                    attribute.get("name") or attribute.get("ref", "").split(":")[-1],
                    attribute.get("type"),
                    attribute.get("use") == "required",
                )
                for attribute in attribute_parent.findall(f"{XSD}attribute")
                if attribute.get("name") or attribute.get("ref")
            ]

    def _walk_particles(self, parent: etree._Element, output: list[Declaration], choice: str | None) -> None:
        for child in parent:
            local = etree.QName(child).localname
            if local == "element":
                max_raw = child.get("maxOccurs", "1")
                output.append(Declaration(
                    child.get("name") or child.get("ref", "").split(":")[-1],
                    child.get("type"),
                    int(child.get("minOccurs", "1")),
                    None if max_raw == "unbounded" else int(max_raw),
                    len(output),
                    choice,
                ))
            elif local in {"sequence", "all", "choice"}:
                group = f"choice-{id(child)}" if local == "choice" else choice
                self._walk_particles(child, output, group)

    def type_for_node(self, node: etree._Element) -> str | None:
        chain = list(reversed(list(node.iterancestors()))) + [node]
        if not chain:
            return None
        current = self.root_types.get(etree.QName(chain[0]).localname)
        for item in chain[1:]:
            local = etree.QName(item).localname
            declaration = next((decl for decl in self.types.get(current or "", []) if decl.name == local), None)
            if declaration is None:
                return None
            current = declaration.type_name
        return current

    def facets_for_type(self, type_name: str | None) -> dict[str, object]:
        current = (type_name or "").split(":")[-1]
        seen: set[str] = set()
        merged: dict[str, object] = {}
        if current in self.simple_content_bases:
            current = self.simple_content_bases[current]
        while current and current not in seen:
            seen.add(current)
            data = self.facets.get(current, {})
            merged = {**data, **merged}
            base = str(data.get("base", ""))
            current = base.split(":")[-1] if base and not base.startswith("xs:") else ""
        return merged

    def metadata(self, node: etree._Element) -> tuple[dict[str, object], list[dict[str, object]]]:
        type_name = self.type_for_node(node)
        declarations = self.types.get(type_name or "", [])
        current_children = [
            (position, etree.QName(child).localname)
            for position, child in enumerate(node)
            if isinstance(child.tag, str)
        ]
        current_names = [name for _, name in current_children]
        available = []
        for declaration in declarations:
            count = current_names.count(declaration.name)
            if declaration.max_occurs is not None and count >= declaration.max_occurs:
                continue
            position = len(node)
            for idx, child_name in current_children:
                child_decl = next((decl for decl in declarations if decl.name == child_name), None)
                if child_decl and child_decl.order > declaration.order:
                    position = idx
                    break
            replace_tags = []
            if declaration.choice:
                replace_tags = [
                    child_name for child_name in current_names
                    if (child_decl := next((decl for decl in declarations if decl.name == child_name), None))
                    and child_decl.choice == declaration.choice
                ]
            available.append({
                "tag": declaration.name,
                "type": declaration.type_name,
                "min_occurs": declaration.min_occurs,
                "max_occurs": "unbounded" if declaration.max_occurs is None else declaration.max_occurs,
                "choice": declaration.choice,
                "suggested_position": position,
                "replace_tags": replace_tags,
            })
        attributes = [
            {
                "name": attribute.name,
                "type": attribute.type_name,
                "required": attribute.required,
                "facets": self.facets_for_type(attribute.type_name),
            }
            for attribute in self.attributes.get(type_name or "", [])
        ]
        return {"type": type_name, "facets": self.facets_for_type(type_name), "attributes": attributes}, available


@lru_cache(maxsize=4)
def schema_model(namespace: str) -> SchemaModel:
    return SchemaModel(namespace)
