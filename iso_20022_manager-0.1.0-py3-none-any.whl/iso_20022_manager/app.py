from __future__ import annotations

import asyncio
import secrets
from importlib.resources import files
from pathlib import Path
from urllib.parse import unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from lxml import etree

from . import __version__
from .core.parsing import MAX_UPLOAD_BYTES, ParseTimeout, PreflightSyntax, ResourceLimit, UnsafeXml, parse_xml, preflight_xml
from .core.projections import payment_detail
from .core.sessions import CommandConflict, RevisionConflict, SessionStore
from .schemas.registry import registry_health

store = SessionStore()
browser_tokens: dict[str, str] = {}


def _owner(request: Request) -> str:
    owner = request.cookies.get("iso20022_session")
    if not owner or owner not in browser_tokens:
        raise HTTPException(403, "Brak lokalnej sesji przeglądarki.")
    return owner


def _document(request: Request, document_id: str):
    try:
        return store.get(document_id, _owner(request))
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc


def create_app() -> FastAPI:
    app = FastAPI(title="ISO 20022 Editor", version=__version__, docs_url=None, redoc_url=None)

    @app.middleware("http")
    async def local_security(request: Request, call_next):
        host = request.headers.get("host", "").split(":", 1)[0].lower()
        if host not in {"127.0.0.1", "localhost", "testserver"}:
            return JSONResponse({"detail": "Niedozwolony Host."}, status_code=403)
        origin = request.headers.get("origin")
        if origin and origin not in {f"http://{request.headers.get('host')}", f"https://{request.headers.get('host')}"}:
            return JSONResponse({"detail": "Niedozwolony Origin."}, status_code=403)
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            owner = request.cookies.get("iso20022_session")
            token = request.headers.get("x-iso20022-csrf")
            if not owner or not token or not secrets.compare_digest(browser_tokens.get(owner, ""), token):
                return JSONResponse({"detail": "Brak lub niepoprawny token żądania lokalnego."}, status_code=403)
        response = await call_next(request)
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    @app.get("/api/bootstrap")
    async def bootstrap(request: Request):
        owner = request.cookies.get("iso20022_session")
        if not owner or owner not in browser_tokens:
            owner = secrets.token_urlsafe(24)
            browser_tokens[owner] = secrets.token_urlsafe(32)
        response = JSONResponse({"csrf_token": browser_tokens[owner], "retention": "Sesje są przechowywane wyłącznie w RAM przez 2 godziny bezczynności."})
        response.set_cookie("iso20022_session", owner, httponly=True, samesite="strict", secure=False, max_age=7200)
        return response

    @app.get("/api/health")
    async def health():
        try:
            schemas = registry_health()
            status = "ready"
        except (OSError, RuntimeError, etree.XMLSchemaParseError) as exc:
            schemas = [{"status": "error", "detail": str(exc)}]
            status = "degraded"
        return {"status": status, "version": __version__, "schemas": schemas}

    @app.get("/api/capabilities")
    async def capabilities(request: Request):
        _owner(request)
        return {
            "versions": registry_health(),
            "profiles": [
                {"profile_id": "iso-base", "name": "ISO + kontrole podstawowe", "status": "implemented"},
                {"profile_id": "epc-sct-2025-partial", "name": "EPC SCT 2025", "status": "partial"},
                *[{"profile_id": key, "name": name, "status": "unverified_p1"} for key, name in [
                    ("mbank-companynet-unverified", "mBank CompanyNet"), ("mbank-swiftnet-unverified", "mBank SWIFTNET"),
                    ("ing-pl-unverified", "ING PL"), ("ing-insidebusiness-unverified", "ING InsideBusiness"),
                    ("citidirect-unverified", "CitiDirect"),
                ]],
            ],
            "limits": {"upload_bytes": MAX_UPLOAD_BYTES, "payments": 50_000, "depth": 64, "nodes": 1_000_000},
        }

    @app.post("/api/documents", status_code=201)
    async def create_document(request: Request):
        owner = _owner(request)
        content_type = request.headers.get("content-type", "").split(";", 1)[0]
        if content_type not in {"application/xml", "text/xml", "application/octet-stream"}:
            raise HTTPException(415, "Wymagany jest surowy plik XML.")
        chunks: list[bytes] = []
        size = 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                raise HTTPException(413, "Plik przekracza limit 20 MiB.")
            chunks.append(chunk)
        payload = b"".join(chunks)
        filename = unquote(request.headers.get("x-original-filename", "payment.xml"))
        try:
            await asyncio.to_thread(preflight_xml, payload)
            parsed = parse_xml(payload)
            session = store.create(owner, filename, payload, parsed)
        except UnsafeXml as exc:
            raise HTTPException(400, str(exc)) from exc
        except ResourceLimit as exc:
            raise HTTPException(413, str(exc)) from exc
        except PreflightSyntax as exc:
            issue = {"message_pl": f"Błąd składni XML: {exc}", "raw_message": str(exc), "line": exc.line, "column": exc.column}
            session = store.create(owner, filename, payload, None, issue)
        except ParseTimeout as exc:
            raise HTTPException(408, "Przekroczono 30 sekund analizy XML.") from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        return session.view()

    @app.get("/api/documents/{document_id}")
    async def get_document(document_id: str, request: Request):
        return _document(request, document_id).view()

    @app.post("/api/documents/{document_id}/payments/query")
    async def query_payments(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await request.json()
        payments = list(session.view()["payments"])
        search = str(body.get("search", "")).casefold().strip()
        group_id = body.get("group_id")
        currency = body.get("currency")
        status = body.get("status")
        if search:
            payments = [row for row in payments if search in " ".join(str(row.get(key) or "") for key in ("creditor_name", "account", "end_to_end_id", "remittance_summary")).casefold()]
        if group_id:
            payments = [row for row in payments if row["group_id"] == group_id]
        if currency:
            payments = [row for row in payments if row["amount"]["currency"] == currency]
        if status == "errors":
            payments = [row for row in payments if row["error_count"]]
        if status == "drafts":
            payments = [row for row in payments if row["is_draft"]]
        sort_by = body.get("sort_by", "original_order")
        reverse = body.get("sort_direction") == "desc"
        allowed_sort = {"original_order", "creditor_name", "end_to_end_id", "payment_info_id"}
        if sort_by in allowed_sort:
            payments.sort(key=lambda row: (row.get(sort_by) is None, str(row.get(sort_by) or "")), reverse=reverse)
        page = max(1, int(body.get("page", 1)))
        page_size = min(100, max(1, int(body.get("page_size", 100))))
        start = (page - 1) * page_size
        return {"items": payments[start:start + page_size], "total": len(payments), "page": page, "page_size": page_size}

    @app.get("/api/documents/{document_id}/payments/{transaction_id}")
    async def get_payment(document_id: str, transaction_id: str, request: Request):
        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        try:
            return payment_detail(session.tree, session.adapter, session.index, transaction_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @app.get("/api/documents/{document_id}/groups/{group_id}")
    async def get_group(document_id: str, group_id: str, request: Request):
        from .core.xml_nodes import node_tree
        from .schemas.metadata import schema_model

        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        try:
            group = session.index.node_for(group_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        if group.tag != session.adapter.q("PmtInf"):
            raise HTTPException(404, "Węzeł nie jest grupą płatności.")
        return {"group_id": group_id, "payment_count": len(session.adapter.children(group, "CdtTrfTxInf")), "tree": node_tree(group, session.index, session.tree, schema_model(session.namespace))}

    @app.get("/api/documents/{document_id}/header")
    async def get_header(document_id: str, request: Request):
        from .core.xml_nodes import node_tree
        from .schemas.metadata import schema_model

        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        initiation = session.adapter.child(session.tree.getroot(), "CstmrCdtTrfInitn")
        header = session.adapter.child(initiation, "GrpHdr") if initiation is not None else None
        if header is None:
            raise HTTPException(404, "Dokument nie zawiera nagłówka GrpHdr.")
        return {"node_id": session.index.id_for(header), "tree": node_tree(header, session.index, session.tree, schema_model(session.namespace))}

    @app.get("/api/documents/{document_id}/source")
    async def get_source(document_id: str, request: Request, original: bool = False):
        session = _document(request, document_id)
        return {"revision": session.revision, "view": "original" if original else "working", "source": session.source(original)}

    @app.post("/api/documents/{document_id}/source-draft")
    async def source_draft(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await request.json()
        try:
            source = str(body["source"])
            await asyncio.to_thread(preflight_xml, source.encode("utf-8"))
            return await asyncio.to_thread(session.replace_source, source, int(body["expected_revision"]))
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except PreflightSyntax as exc:
            raise HTTPException(422, {"message": str(exc), "line": exc.line, "column": exc.column}) from exc
        except ParseTimeout as exc:
            raise HTTPException(408, "Przekroczono 30 sekund analizy XML.") from exc
        except (UnsafeXml, ResourceLimit, etree.XMLSyntaxError, ValueError) as exc:
            position = getattr(exc, "position", (None, None))
            raise HTTPException(422, {"message": str(exc), "line": position[0], "column": position[1]}) from exc

    @app.post("/api/documents/{document_id}/commands")
    async def command(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await request.json()
        try:
            return await asyncio.to_thread(session.command, body)
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except CommandConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except (KeyError, ValueError, TypeError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/documents/{document_id}/validations")
    async def validate(document_id: str, request: Request):
        session = _document(request, document_id)
        return await asyncio.to_thread(session.validate)

    @app.get("/api/documents/{document_id}/validations/{report_id}")
    async def get_validation(document_id: str, report_id: str, request: Request):
        session = _document(request, document_id)
        reports = [session.current_report, session.original_report, *[item.report for item in session.artifacts.values()]]
        report = next((item for item in reports if item and item["report_id"] == report_id), None)
        if report is None:
            raise HTTPException(404, "Raport nie istnieje w tej sesji.")
        return report

    @app.post("/api/documents/{document_id}/exports/prepare")
    async def prepare_export(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await request.json()
        try:
            artifact = await asyncio.to_thread(session.prepare_export, int(body["expected_revision"]), str(body["command_id"]))
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        except CommandConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        return {"artifact_id": artifact.artifact_id, "source_revision": artifact.source_revision, "sha256": artifact.sha256, "filename": artifact.filename, "report": artifact.report, "requires_acknowledgement": artifact.report["warning_count"] > 0, "download_ready": artifact.report["can_export_in_scope"] and artifact.acknowledged}

    @app.post("/api/documents/{document_id}/exports/{artifact_id}/acknowledgements")
    async def acknowledge(document_id: str, artifact_id: str, request: Request):
        session = _document(request, document_id)
        try:
            artifact = session.artifact(artifact_id)
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        artifact.acknowledged = True
        return {"artifact_id": artifact_id, "download_ready": artifact.report["can_export_in_scope"]}

    @app.get("/api/documents/{document_id}/exports/{artifact_id}/download")
    async def download(document_id: str, artifact_id: str, request: Request):
        session = _document(request, document_id)
        try:
            artifact = session.artifact(artifact_id)
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        except RevisionConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        if not artifact.report["can_export_in_scope"] or not artifact.acknowledged:
            raise HTTPException(422, "Eksport jest zablokowany przez błędy lub nieprzejrzane ostrzeżenia.")
        return Response(artifact.payload, media_type="application/xml", headers={"Content-Disposition": f'attachment; filename="{artifact.filename}"', "X-Content-SHA256": artifact.sha256})

    @app.delete("/api/documents/{document_id}", status_code=204)
    async def close_document(document_id: str, request: Request):
        try:
            store.delete(document_id, _owner(request))
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        return Response(status_code=204)

    static_dir = Path(str(files("iso_20022_manager").joinpath("resources", "static")))
    if static_dir.exists() and (static_dir / "index.html").exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True), name="ui")

    return app


app = create_app()
