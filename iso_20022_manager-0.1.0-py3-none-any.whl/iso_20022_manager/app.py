from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, DecimalException, Inexact, Rounded, localcontext
import json
import secrets
import threading
import unicodedata
from importlib.resources import files
from pathlib import Path
from urllib.parse import quote, unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from lxml import etree

from . import __version__
from .core.parsing import MAX_UPLOAD_BYTES, ParseTimeout, PreflightSyntax, ResourceLimit, UnsafeXml, parse_xml, preflight_validation
from .core.projections import payment_detail
from .core.sessions import CommandConflict, RevisionConflict, SESSION_TTL, SessionStore
from .schemas.registry import registry_health
from .validation.epc import compiled_schema as compiled_epc_schema
from .validation.epc import profile_manifest as epc_profile_manifest
from .validation.bank_profiles import profile_catalog

store = SessionStore()


@dataclass
class BrowserToken:
    csrf: str
    last_activity_at: datetime


browser_tokens: dict[str, BrowserToken] = {}
browser_tokens_lock = threading.RLock()
BROWSER_SESSION_TTL = timedelta(hours=2)
MAX_BROWSER_SESSIONS = 32
MAX_COMMAND_BODY_BYTES = 1024 * 1024
MAX_SOURCE_BODY_BYTES = MAX_UPLOAD_BYTES * 2 + 64 * 1024


async def _json_body(request: Request, limit: int = MAX_COMMAND_BODY_BYTES) -> dict[str, object]:
    chunks: list[bytes] = []
    size = 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > limit:
            raise HTTPException(413, "Treść żądania przekracza dozwolony limit.")
        chunks.append(chunk)
    try:
        value = json.loads(b"".join(chunks))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HTTPException(400, "Niepoprawna treść JSON.") from exc
    if not isinstance(value, dict):
        raise HTTPException(400, "Treść JSON musi być obiektem.")
    return value


def _content_disposition(filename: str) -> str:
    clean = "".join(char for char in filename if ord(char) >= 32 and char != "\x7f")
    ascii_name = unicodedata.normalize("NFKD", clean).encode("ascii", "ignore").decode("ascii")
    ascii_name = "".join(char if char not in {'"', "\\", ";"} else "_" for char in ascii_name)
    ascii_name = ascii_name or "payment.xml"
    return f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(clean, safe='')}"


def _owner(request: Request) -> str:
    owner = request.cookies.get("iso20022_session")
    with browser_tokens_lock:
        _sweep_browser_tokens()
        token = browser_tokens.get(owner or "")
        if not owner or token is None:
            raise HTTPException(403, "Brak lokalnej sesji przeglądarki.")
        token.last_activity_at = datetime.now(UTC)
        return owner


def _sweep_browser_tokens() -> None:
    now = datetime.now(UTC)
    expired = [owner for owner, token in browser_tokens.items() if now - token.last_activity_at > BROWSER_SESSION_TTL]
    for owner in expired:
        browser_tokens.pop(owner, None)
        store.delete_owner(owner)


def _document(request: Request, document_id: str):
    try:
        return store.get(document_id, _owner(request))
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc


def create_app() -> FastAPI:
    app = FastAPI(title="ISO 20022 Editor", version=__version__, docs_url=None, redoc_url=None)

    @app.middleware("http")
    async def local_security(request: Request, call_next):
        host = request.headers.get("host", "").split(":", 1)[0].lower()
        if host not in {"127.0.0.1", "localhost", "testserver"}:
            return JSONResponse({"detail": "Niedozwolony Host."}, status_code=403)
        origin = request.headers.get("origin")
        if origin and origin not in {f"http://{request.headers.get('host')}", f"https://{request.headers.get('host')}"}:
            return JSONResponse({"detail": "Niedozwolony Origin."}, status_code=403)
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            owner = request.cookies.get("iso20022_session")
            token = request.headers.get("x-iso20022-csrf")
            with browser_tokens_lock:
                _sweep_browser_tokens()
                expected = browser_tokens.get(owner or "")
            if not owner or not token or expected is None or not secrets.compare_digest(expected.csrf, token):
                return JSONResponse({"detail": "Brak lub niepoprawny token żądania lokalnego."}, status_code=403)
        response = await call_next(request)
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    @app.get("/api/bootstrap")
    async def bootstrap(request: Request):
        owner = request.cookies.get("iso20022_session")
        with browser_tokens_lock:
            _sweep_browser_tokens()
            if not owner or owner not in browser_tokens:
                while len(browser_tokens) >= MAX_BROWSER_SESSIONS:
                    oldest = min(browser_tokens, key=lambda key: browser_tokens[key].last_activity_at)
                    browser_tokens.pop(oldest, None)
                    store.delete_owner(oldest)
                owner = secrets.token_urlsafe(24)
                browser_tokens[owner] = BrowserToken(secrets.token_urlsafe(32), datetime.now(UTC))
            else:
                browser_tokens[owner].last_activity_at = datetime.now(UTC)
            csrf_token = browser_tokens[owner].csrf
        response = JSONResponse({"csrf_token": csrf_token, "retention": "Sesje są przechowywane wyłącznie w RAM przez 2 godziny bezczynności."})
        response.set_cookie("iso20022_session", owner, httponly=True, samesite="strict", secure=False, max_age=7200)
        return response

    @app.get("/api/health")
    async def health():
        try:
            schemas = registry_health()
            compiled_epc_schema()
            profile_catalog()
            status = "ready"
        except (OSError, RuntimeError, etree.XMLSchemaParseError) as exc:
            schemas = [{"status": "error", "detail": str(exc)}]
            status = "degraded"
        return {"status": status, "version": __version__, "schemas": schemas}

    @app.get("/api/capabilities")
    async def capabilities(request: Request):
        _owner(request)
        epc = epc_profile_manifest()
        return {
            "versions": registry_health(),
            "profiles": [
                {"profile_id": "iso-base", "name": "ISO + kontrole podstawowe", "status": "implemented"},
                {
                    "profile_id": "epc-sct-2025",
                    "name": "EPC SCT 2025 v1.1",
                    "status": "implemented",
                    "message_identifier": epc["message_identifier"],
                    "implementation_guideline_version": epc["implementation_guideline_version"],
                    "xsd_sha256": epc["xsd_sha256"],
                },
                *[
                    {
                        "profile_id": profile["profile_id"],
                        "name": profile["name"],
                        "status": "implemented",
                        "message_identifiers": profile["message_identifiers"],
                        "document_version": profile["document_version"],
                        "source_sha256": profile["source_sha256"],
                        "coverage": "static_file_validation",
                    }
                    for profile in profile_catalog()
                ],
            ],
            "limits": {"upload_bytes": MAX_UPLOAD_BYTES, "payments": 50_000, "depth": 64, "nodes": 1_000_000},
        }

    @app.post("/api/documents", status_code=201)
    async def create_document(request: Request):
        owner = _owner(request)
        content_type = request.headers.get("content-type", "").split(";", 1)[0]
        if content_type not in {"application/xml", "text/xml", "application/octet-stream"}:
            raise HTTPException(415, "Wymagany jest surowy plik XML.")
        chunks: list[bytes] = []
        size = 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                raise HTTPException(413, "Plik przekracza limit 20 MiB.")
            chunks.append(chunk)
        payload = b"".join(chunks)
        filename = unquote(request.headers.get("x-original-filename", "payment.xml"))
        try:
            preflight = await asyncio.to_thread(preflight_validation, payload)
            parsed = await asyncio.to_thread(parse_xml, payload)
            session = await asyncio.to_thread(store.create, owner, filename, payload, parsed, None, preflight["report"])
        except UnsafeXml as exc:
            raise HTTPException(400, str(exc)) from exc
        except ResourceLimit as exc:
            raise HTTPException(413, str(exc)) from exc
        except PreflightSyntax as exc:
            issue = {"message_pl": f"Błąd składni XML: {exc}", "raw_message": str(exc), "line": exc.line, "column": exc.column}
            session = store.create(owner, filename, payload, None, issue)
        except ParseTimeout as exc:
            raise HTTPException(408, "Przekroczono 30 sekund analizy XML.") from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        return session.view(include_payments=request.query_params.get("compact") != "true")

    @app.get("/api/documents/{document_id}")
    async def get_document(document_id: str, request: Request):
        return _document(request, document_id).view(include_payments=request.query_params.get("compact") != "true")

    @app.post("/api/documents/{document_id}/payments/query")
    async def query_payments(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await _json_body(request)
        all_payments = list(session.view()["payments"])
        payments = all_payments.copy()
        search = str(body.get("search", "")).casefold().strip()
        group_id = body.get("group_id")
        currency = body.get("currency")
        status = body.get("status")
        if search:
            payments = [row for row in payments if search in " ".join(str(row.get(key) or "") for key in ("creditor_name", "account", "end_to_end_id", "remittance_summary")).casefold()]
        if group_id:
            payments = [row for row in payments if row["group_id"] == group_id]
        if currency:
            payments = [row for row in payments if row["amount"]["currency"] == currency]
        if status == "errors":
            payments = [row for row in payments if row["error_count"]]
        if status == "drafts":
            payments = [row for row in payments if row["is_draft"]]
        sort_by = body.get("sort_by", "original_order")
        reverse = body.get("sort_direction") == "desc"
        allowed_sort = {"original_order", "creditor_name", "end_to_end_id", "payment_info_id"}
        if sort_by in allowed_sort:
            if sort_by == "original_order":
                payments.sort(key=lambda row: int(row.get("original_order") or 0), reverse=reverse)
            else:
                payments.sort(key=lambda row: (row.get(sort_by) is None, str(row.get(sort_by) or "").casefold()), reverse=reverse)
        page = max(1, int(body.get("page", 1)))
        page_size = min(100, max(1, int(body.get("page_size", 100))))
        start = (page - 1) * page_size
        result = {
            "items": payments[start:start + page_size],
            "total": len(payments),
            "page": page,
            "page_size": page_size,
            "expires_at": (session.last_activity_at + SESSION_TTL).isoformat(),
        }
        if body.get("include_matching_ids") is True:
            result["matching_ids"] = [row["transaction_id"] for row in payments]
        selected_ids = body.get("selected_ids")
        if isinstance(selected_ids, list):
            if len(selected_ids) > 50_000 or len(selected_ids) != len(set(map(str, selected_ids))):
                raise HTTPException(422, "Niepoprawna lista zaznaczonych płatności.")
            selected = {str(item) for item in selected_ids}
            chosen = [row for row in all_payments if row["transaction_id"] in selected]
            if len(chosen) != len(selected):
                raise HTTPException(422, "Część zaznaczonych płatności nie istnieje w bieżącej rewizji.")
            totals: dict[str, Decimal | None] = {}
            with localcontext() as context:
                context.prec = 50
                context.traps[Inexact] = True
                context.traps[Rounded] = True
                for row in chosen:
                    ccy = str(row["amount"].get("currency") or "bez waluty")
                    raw = row["amount"].get("value") or row["amount"].get("raw_value")
                    try:
                        amount = Decimal(str(raw))
                        previous = totals.get(ccy, Decimal(0))
                        totals[ccy] = amount + previous if previous is not None else None
                    except (DecimalException, ValueError):
                        totals[ccy] = None
            result["selection_summary"] = {
                "groups": sorted({str(row.get("payment_info_id") or "Bez PmtInfId") for row in chosen}),
                "totals": {ccy: format(value, "f") if value is not None else "niepełna" for ccy, value in totals.items()},
            }
        return result

    @app.get("/api/documents/{document_id}/payments/{transaction_id}")
    async def get_payment(document_id: str, transaction_id: str, request: Request):
        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        try:
            return payment_detail(session.tree, session.adapter, session.index, transaction_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc

    @app.get("/api/documents/{document_id}/groups/{group_id}")
    async def get_group(document_id: str, group_id: str, request: Request):
        from .core.xml_nodes import node_tree
        from .schemas.metadata import schema_model

        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        try:
            group = session.index.node_for(group_id)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        if group.tag != session.adapter.q("PmtInf"):
            raise HTTPException(404, "Węzeł nie jest grupą płatności.")
        return {"group_id": group_id, "payment_count": len(session.adapter.children(group, "CdtTrfTxInf")), "tree": node_tree(group, session.index, session.tree, schema_model(session.namespace))}

    @app.get("/api/documents/{document_id}/header")
    async def get_header(document_id: str, request: Request):
        from .core.xml_nodes import node_tree
        from .schemas.metadata import schema_model

        session = _document(request, document_id)
        if session.tree is None or session.adapter is None or session.index is None:
            raise HTTPException(409, "Dokument nie jest edytowalny.")
        initiation = session.adapter.child(session.tree.getroot(), "CstmrCdtTrfInitn")
        header = session.adapter.child(initiation, "GrpHdr") if initiation is not None else None
        if header is None:
            raise HTTPException(404, "Dokument nie zawiera nagłówka GrpHdr.")
        return {"node_id": session.index.id_for(header), "tree": node_tree(header, session.index, session.tree, schema_model(session.namespace))}

    @app.get("/api/documents/{document_id}/source")
    async def get_source(document_id: str, request: Request, original: bool = False):
        session = _document(request, document_id)
        return {"revision": session.revision, "view": "original" if original else "working", "source": session.source(original)}

    @app.post("/api/documents/{document_id}/source-draft")
    async def source_draft(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await _json_body(request, MAX_SOURCE_BODY_BYTES)
        try:
            source = str(body["source"])
            return await asyncio.to_thread(
                session.replace_source,
                source,
                int(body["expected_revision"]),
                request.query_params.get("compact") != "true",
            )
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except PreflightSyntax as exc:
            raise HTTPException(422, {"message": str(exc), "line": exc.line, "column": exc.column}) from exc
        except ParseTimeout as exc:
            raise HTTPException(408, "Przekroczono 30 sekund analizy XML.") from exc
        except (UnsafeXml, ResourceLimit, etree.XMLSyntaxError, ValueError) as exc:
            position = getattr(exc, "position", (None, None))
            raise HTTPException(422, {"message": str(exc), "line": position[0], "column": position[1]}) from exc

    @app.post("/api/documents/{document_id}/commands")
    async def command(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await _json_body(request)
        try:
            return await asyncio.to_thread(session.command, body, request.query_params.get("compact") != "true")
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except CommandConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except ParseTimeout as exc:
            raise HTTPException(408, str(exc)) from exc
        except (KeyError, ValueError, TypeError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/api/documents/{document_id}/validations")
    async def validate(document_id: str, request: Request):
        session = _document(request, document_id)
        try:
            return await asyncio.to_thread(session.validate)
        except ParseTimeout as exc:
            raise HTTPException(408, str(exc)) from exc

    @app.get("/api/documents/{document_id}/validations/{report_id}")
    async def get_validation(document_id: str, report_id: str, request: Request):
        session = _document(request, document_id)
        reports = [session.current_report, session.original_report, *[item.report for item in session.artifacts.values()]]
        report = next((item for item in reports if item and item["report_id"] == report_id), None)
        if report is None:
            raise HTTPException(404, "Raport nie istnieje w tej sesji.")
        return report

    @app.post("/api/documents/{document_id}/exports/prepare")
    async def prepare_export(document_id: str, request: Request):
        session = _document(request, document_id)
        body = await _json_body(request)
        try:
            artifact = await asyncio.to_thread(session.prepare_export, int(body["expected_revision"]), str(body["command_id"]))
        except RevisionConflict as exc:
            raise HTTPException(409, {"message": str(exc), "current_revision": exc.current_revision}) from exc
        except ParseTimeout as exc:
            raise HTTPException(408, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        except CommandConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        return {"artifact_id": artifact.artifact_id, "source_revision": artifact.source_revision, "sha256": artifact.sha256, "filename": artifact.filename, "report": artifact.report, "automatic_changes": artifact.automatic_changes, "requires_acknowledgement": artifact.report["warning_count"] > 0, "download_ready": artifact.report["can_export_in_scope"] and artifact.acknowledged}

    @app.post("/api/documents/{document_id}/exports/{artifact_id}/acknowledgements")
    async def acknowledge(document_id: str, artifact_id: str, request: Request):
        session = _document(request, document_id)
        try:
            artifact = session.artifact(artifact_id)
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        artifact.acknowledged = True
        return {"artifact_id": artifact_id, "download_ready": artifact.report["can_export_in_scope"]}

    @app.get("/api/documents/{document_id}/exports/{artifact_id}/download")
    async def download(document_id: str, artifact_id: str, request: Request):
        session = _document(request, document_id)
        try:
            artifact = session.artifact(artifact_id)
        except KeyError as exc:
            raise HTTPException(410, str(exc)) from exc
        except RevisionConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        if not artifact.report["can_export_in_scope"] or not artifact.acknowledged:
            raise HTTPException(422, "Eksport jest zablokowany przez błędy lub nieprzejrzane ostrzeżenia.")
        return Response(artifact.payload, media_type="application/xml", headers={"Content-Disposition": _content_disposition(artifact.filename), "X-Content-SHA256": artifact.sha256})

    @app.delete("/api/documents/{document_id}", status_code=204)
    async def close_document(document_id: str, request: Request):
        try:
            store.delete(document_id, _owner(request))
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        return Response(status_code=204)

    static_dir = Path(str(files("iso_20022_manager").joinpath("resources", "static")))
    if static_dir.exists() and (static_dir / "index.html").exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True), name="ui")

    return app


app = create_app()
