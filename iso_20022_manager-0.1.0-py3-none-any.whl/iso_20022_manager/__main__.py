from __future__ import annotations

import argparse
import socket
import webbrowser

import uvicorn


def _free_port(preferred: int) -> int:
    for port in range(preferred, preferred + 20):
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise RuntimeError("Nie znaleziono wolnego portu lokalnego.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Lokalny walidator i edytor ISO 20022 pain.001")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    port = _free_port(args.port)
    url = f"http://127.0.0.1:{port}"
    print(f"ISO 20022 Editor: {url}")
    print("Dane pozostają w pamięci tego procesu. Ctrl+C kończy aplikację i usuwa sesje.")
    if not args.no_browser:
        webbrowser.open(url)
    uvicorn.run("iso_20022_manager.app:app", host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    main()
