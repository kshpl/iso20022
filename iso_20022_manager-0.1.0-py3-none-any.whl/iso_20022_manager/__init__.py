"""Local ISO 20022 payment-file manager."""

__all__ = ["__version__"]

__version__ = "0.1.0"
