from __future__ import annotations

from collections import Counter

from .compare import NEW, OLD, Group, Result, account_text, delta_map, money, money_map, plural
from .model import Document, Payment, Severity

MAX_VALUE = 220


def _short(value: str, limit: int = MAX_VALUE) -> str:
    value = " ".join(value.split())
    return value if len(value) <= limit else value[: limit - 1] + "…"


def _document_line(side: str, document: Document) -> str:
    return f"  {side:<6}{document.name}  |  {document.version}  |  przelewy: {len(document.payments)}  |  sha256 {document.sha256[:12]}"


def pair_summary(result: Result) -> list[str]:
    stats = result.pair_stats()
    rows = [
        ("identyczne merytorycznie pary 1:1", str(stats.pairs[Severity.OK])),
        ("pary 1:1 z różnicami kosmetycznymi", str(stats.pairs[Severity.KOSMETYCZNA])),
        ("pary 1:1 z różnicami istotnymi", str(stats.pairs[Severity.ISTOTNA])),
        ("pary 1:1 z różnicami krytycznymi", str(stats.pairs[Severity.KRYTYCZNA])),
        ("inne grupowanie faktur", f"{stats.regrouped} ({OLD}: {plural(stats.regrouped_old)} → {NEW}: {plural(stats.regrouped_new)})"),
        (f"tylko w pliku {OLD}", str(stats.only_old)),
        (f"tylko w pliku {NEW}", str(stats.only_new)),
    ]
    lines = [f"Przelewy ({OLD}: {len(result.old.payments)}, {NEW}: {len(result.new.payments)})"]
    lines += [f"  {label + ':':<40}{value}" for label, value in rows]
    return lines


def group_header(group: Group) -> list[str]:
    accounts = ", ".join(account_text(value) for value in group.values(lambda p: p.creditor_account))
    dates = ", ".join(group.values(lambda p: p.execution_date))
    currencies = ", ".join(group.values(lambda p: p.currency))
    old_total, new_total = group.total(OLD), group.total(NEW)
    delta = delta_map(old_total, new_total)
    delta_text = ("  |  Δ " + ", ".join(money(value, currency) for currency, value in delta.items())) if delta else ""
    return [
        f"[{group.severity.tag}] #{group.id} {group.creditor_name}  |  {accounts}  |  {currencies}  |  {dates}",
        f"       {OLD} {len(group.old)} przel. {money_map(old_total)}  |  {NEW} {len(group.new)} przel. {money_map(new_total)}{delta_text}  |  para: {group.pairing}",
    ]


def render_console(result: Result, show_all: bool = False, limit: int = 50, report_dir: str | None = None) -> str:
    lines = ["Porównanie merytoryczne plików pain.001", _document_line(OLD, result.old), _document_line(NEW, result.new), ""]

    lines.append("Sumy wg walut")
    lines.append(f"  {'waluta':<7}{OLD + ' szt.':>11}{OLD + ' suma':>20}{NEW + ' szt.':>11}{NEW + ' suma':>20}{'Δ':>18}")
    for row in result.totals:
        delta = row.new_sum - row.old_sum
        lines.append(f"  {row.currency or '?':<7}{row.old_count:>11}{money(row.old_sum):>20}{row.new_count:>11}{money(row.new_sum):>20}{(money(delta) if delta else '0'):>18}")
    lines.append("")

    if result.file_findings:
        lines.append("Plik")
        for finding in result.file_findings:
            lines.append(f"  [{finding.severity.tag}] {finding.message}")
        lines.append("")

    lines.extend(pair_summary(result))
    lines.append("")

    counts = Counter(group.severity for group in result.groups)
    lines.append(
        f"Grupy (rachunek obciążany + rachunek beneficjenta + waluta + data): {len(result.groups)} — "
        + ", ".join(f"{level.plural} {counts[level]}" for level in sorted(Severity, reverse=True))
    )
    lines.append("")

    threshold = Severity.OK if show_all else Severity.ISTOTNA
    shown = [group for group in sorted(result.groups, key=lambda g: (-g.severity, g.id)) if group.severity >= threshold]
    for group in shown[:limit]:
        lines.extend(group_header(group))
        for finding in sorted(group.findings, key=lambda f: -f.severity):
            if finding.severity < threshold and not show_all:
                continue
            lines.append(f"       - [{finding.severity.tag}] {_short(finding.message, 400)}" + (f"  [{_short(finding.where, 160)}]" if finding.where else ""))
            if finding.old or finding.new:
                lines.append(f"           {OLD}: {_short(finding.old)}")
                lines.append(f"           {NEW}:  {_short(finding.new)}")
        lines.append("")
    if len(shown) > limit:
        lines.append(f"... oraz {len(shown) - limit} kolejnych grup — pełna lista w raporcie HTML/CSV.")
        lines.append("")
    if not show_all and counts[Severity.KOSMETYCZNA]:
        lines.append(f"Pominięte grupy z różnicami tylko kosmetycznymi: {counts[Severity.KOSMETYCZNA]} (pokaż: --all).")

    severity = result.severity
    verdict = {
        Severity.OK: "brak różnic merytorycznych",
        Severity.KOSMETYCZNA: "tylko różnice kosmetyczne",
        Severity.ISTOTNA: "są różnice istotne",
        Severity.KRYTYCZNA: "są różnice krytyczne (przelewy, kwoty, rachunki, faktury lub grupowanie)",
    }[severity]
    lines.append(f"WYNIK: {verdict}.")
    if report_dir:
        lines.append(f"Raport: {report_dir}")
    return "\n".join(lines)


def render_inspect(document: Document, payments: list[Payment]) -> str:
    lines = [_document_line("PLIK", document), ""]
    header = f"{'nr':>5}  {'data':<10}  {'beneficjent':<28}  {'rachunek':<28}  {'kwota':>14} {'wal':<3}  faktury / numery  ‖  pozostałe słowa"
    lines.append(header)
    lines.append("-" * len(header))
    for payment in payments:
        refs = ", ".join(f"{ref.display}" for ref in payment.refs) or "(brak numerów)"
        extra = []
        if len(payment.text_variants) > 1:
            extra.append(f"niejednoznaczny podział Ustrd: {len(payment.text_variants)} odczyty")
        if payment.mpp:
            extra.append(f"MPP VAT {payment.mpp.vat_raw} NIP {payment.mpp.nip}")
        if payment.ustrd_length >= 130:
            extra.append(f"opis {payment.ustrd_length} znaków")
        lines.append(
            f"{payment.seq:>5}  {payment.execution_date:<10}  {_short(payment.creditor_name, 28):<28}  {payment.creditor_account:<28}  "
            f"{money(payment.amount):>14} {payment.currency:<3}  {refs}  ‖  {' '.join(payment.words)}"
            + (f"  [{'; '.join(extra)}]" if extra else "")
        )
    without = sum(1 for payment in payments if not payment.refs)
    sources = Counter(ref.source for payment in payments for ref in payment.refs)
    words = Counter(word.casefold() for payment in payments for word in payment.words)
    lines += [
        "",
        f"Przelewów: {len(payments)}, bez rozpoznanych numerów: {without}, MPP: {sum(1 for p in payments if p.mpp)}, "
        f"niejednoznaczny podział Ustrd: {sum(1 for p in payments if len(p.text_variants) > 1)}",
        "Źródła numerów: " + (", ".join(f"{source} × {count}" for source, count in sources.most_common()) or "—"),
        "Najczęstsze słowa (nie są traktowane jako numery): " + (", ".join(f"{word} × {count}" for word, count in words.most_common(15)) or "—"),
    ]
    return "\n".join(lines)
