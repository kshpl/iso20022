"""Temporary business-level comparison of two pain.001 files (old ERP vs new generator)."""
