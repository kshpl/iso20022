"""Extraction of invoice numbers from remittance text.

Default rule: description is split on whitespace, ';' and ',' (a comma between two
digits, e.g. "100,00", is kept). Every resulting token that contains a digit is
treated as an invoice/reference number, except amounts like "23.00" or "1.234,56";
tokens without digits are plain words.
A custom regular expression replaces this rule when a file uses another layout.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re

from .model import InvoiceRef, Mpp, TextVariant

SEPARATOR = re.compile(r"\s+|;|(?<!\d),|,(?!\d)")
AMOUNT = re.compile(r"[+-]?\d+(?:[.,]\d{3})*[.,]\d{2}")
EDGE_PUNCTUATION = " .:;,()[]{}\"'"
SEPARATOR_CHARS = set(" \t\r\n,;")
MAX_AMBIGUOUS_BOUNDARIES = 6
MPP = re.compile(r"/VAT/(?P<vat>[^/]*)/IDC/(?P<nip>[^/]*)/INV/(?P<inv>.*?)(?:/TXT/(?P<txt>.*))?", re.DOTALL)


def tokenize(text: str, source: str, invoice_regex: re.Pattern[str] | None = None) -> tuple[list[InvoiceRef], list[str]]:
    if invoice_regex is not None:
        refs = [InvoiceRef(match.group(0).strip(), source) for match in invoice_regex.finditer(text) if match.group(0).strip()]
        rest = invoice_regex.sub(" ", text)
        words = [word for word in (part.strip(EDGE_PUNCTUATION) for part in SEPARATOR.split(rest)) if word]
        return refs, words
    refs: list[InvoiceRef] = []
    words: list[str] = []
    for part in SEPARATOR.split(text):
        token = part.strip(EDGE_PUNCTUATION)
        if not token:
            continue
        if any(char.isdigit() for char in token) and not AMOUNT.fullmatch(token):
            refs.append(InvoiceRef(token, source))
        else:
            words.append(token)
    return refs, words


def _ambiguous(left: str, right: str) -> bool:
    return bool(left) and bool(right) and left[-1] not in SEPARATOR_CHARS and right[0] not in SEPARATOR_CHARS


def ustrd_variants(lines: list[str], invoice_regex: re.Pattern[str] | None = None) -> list[TextVariant]:
    """Tokenize Ustrd lines; where a line boundary may cut a number, keep both readings.

    Variant 0 always joins lines with a space. Other variants glue selected boundaries.
    The comparison later picks the reading that best matches the other file.
    """
    if not lines:
        return []
    boundaries = [i for i in range(len(lines) - 1) if _ambiguous(lines[i], lines[i + 1])][:MAX_AMBIGUOUS_BOUNDARIES]
    variants: list[TextVariant] = []
    for mask in range(1 << len(boundaries)):
        glue = {boundaries[j] for j in range(len(boundaries)) if mask >> j & 1}
        text = lines[0]
        for i in range(len(lines) - 1):
            text += ("" if i in glue else " ") + lines[i + 1]
        refs, words = tokenize(text, "Ustrd", invoice_regex)
        variants.append(TextVariant(len(glue), refs, words, text))
    return variants


def parse_decimal(raw: str) -> Decimal | None:
    value = raw.strip().replace(" ", "").replace(",", ".")
    if not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
        return None
    try:
        return Decimal(value)
    except InvalidOperation:
        return None


def parse_mpp(lines: list[str], invoice_regex: re.Pattern[str] | None = None) -> tuple[Mpp, list[InvoiceRef], list[str]] | None:
    """Polish split payment layout /VAT/../IDC/../INV/..[/TXT/..] written in Ustrd."""
    glued = "".join(lines).strip()
    if not glued.upper().startswith("/VAT/"):
        return None
    match = MPP.fullmatch(glued)
    if match is None:
        return None
    vat_raw = match.group("vat").strip()
    invoice = match.group("inv").strip()
    text = (match.group("txt") or "").strip()
    mpp = Mpp(parse_decimal(vat_raw), vat_raw, match.group("nip").strip(), invoice, text, "Ustrd /VAT/")
    refs, words = tokenize(invoice, "Ustrd /INV/", invoice_regex)
    if not refs and invoice:
        refs = [InvoiceRef(invoice, "Ustrd /INV/")]
        words = []
    text_refs, text_words = tokenize(text, "Ustrd /TXT/", invoice_regex)
    return mpp, refs + text_refs, words + text_words
