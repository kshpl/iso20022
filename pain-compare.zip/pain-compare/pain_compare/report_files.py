from __future__ import annotations

from collections import Counter
import csv
from datetime import datetime
from decimal import Decimal
from html import escape
import io
from pathlib import Path
import zipfile

from .compare import NEW, OLD, Group, Link, Result, account_text, delta_map, money, money_map, plural
from .model import Payment, Severity


def _csv_amount(value: Decimal | None) -> str:
    return "" if value is None else format(value, "f").replace(".", ",")


def _csv_bytes(header: list[str], rows: list[list[object]]) -> bytes:
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, delimiter=";", quoting=csv.QUOTE_MINIMAL)
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8-sig")


def _links_by_payment(result: Result) -> dict[int, tuple[Group, Link]]:
    mapping: dict[int, tuple[Group, Link]] = {}
    for group in result.groups:
        for link in group.links:
            for payment in link.old + link.new:
                mapping[id(payment)] = (group, link)
    return mapping


def _counterpart(payment: Payment, link: Link) -> str:
    other = link.new if payment.side == OLD else link.old
    return ", ".join(item.label for item in other)


def csv_files(result: Result) -> dict[str, bytes]:
    """Report tables as CSV for Excel: ';' separator, decimal comma, UTF-8 with BOM."""
    files: dict[str, bytes] = {}
    findings_rows: list[list[object]] = [["plik", finding.severity.label, finding.category, "", "", "", "", finding.message, "", finding.old, finding.new] for finding in result.file_findings]
    for group in result.groups:
        for finding in sorted(group.findings, key=lambda f: -f.severity):
            findings_rows.append([
                group.id,
                finding.severity.label,
                finding.category,
                group.creditor_name,
                ", ".join(group.values(lambda p: p.creditor_account)),
                ", ".join(group.values(lambda p: p.currency)),
                ", ".join(group.values(lambda p: p.execution_date)),
                finding.message,
                finding.where,
                finding.old,
                finding.new,
            ])
    files["roznice.csv"] = _csv_bytes(["grupa", "waga", "kategoria", "beneficjent", "rachunek beneficjenta", "waluta", "data", "opis różnicy", "przelewy", OLD, NEW], findings_rows)

    invoice_rows = [
        [
            group.id,
            group.severity.label,
            group.creditor_name,
            ", ".join(group.values(lambda p: p.creditor_account)),
            ", ".join(group.values(lambda p: p.execution_date)),
            row.display,
            row.old_count,
            row.new_count,
            ", ".join(payment.label for payment in row.old_payments),
            ", ".join(payment.label for payment in row.new_payments),
            row.status,
            row.note,
        ]
        for group, row in result.all_invoices()
    ]
    files["faktury.csv"] = _csv_bytes(["grupa", "waga grupy", "beneficjent", "rachunek beneficjenta", "data", "faktura / numer", f"w {OLD}", f"w {NEW}", f"przelewy {OLD}", f"przelewy {NEW}", "status", "uwagi"], invoice_rows)

    links = _links_by_payment(result)
    payment_rows = []
    for payment in result.old.payments + result.new.payments:
        group, link = links[id(payment)]
        payment_rows.append([
            payment.side,
            payment.seq,
            group.id,
            group.severity.label,
            f"{link.kind} — {link.severity.label}",
            _counterpart(payment, link),
            payment.execution_date,
            payment.debtor_account,
            payment.creditor_name,
            payment.creditor_account,
            payment.creditor_bic,
            _csv_amount(payment.amount),
            payment.currency,
            ", ".join(ref.display for ref in payment.refs),
            payment.description,
            "/".join(payment.payment_type[name] for name in ("SvcLvl", "LclInstrm", "CtgyPurp")),
            payment.mpp.vat_raw if payment.mpp else "",
            payment.mpp.nip if payment.mpp else "",
            payment.end_to_end_id,
            payment.pmt_inf_id,
        ])
    files["przelewy.csv"] = _csv_bytes(["plik", "nr", "grupa", "waga grupy", "dopasowanie", "odpowiednik", "data", "rachunek obciążany", "beneficjent", "rachunek beneficjenta", "BIC", "kwota", "waluta", "faktury / numery", "opis", "SvcLvl/LclInstrm/CtgyPurp", "MPP VAT", "MPP NIP", "EndToEndId", "PmtInfId"], payment_rows)
    return files


def write_csv_files(result: Result, directory: Path) -> list[Path]:
    paths = []
    for name, content in csv_files(result).items():
        path = directory / name
        path.write_bytes(content)
        paths.append(path)
    return paths


def report_zip(result: Result, options_text: str) -> bytes:
    """HTML report and CSV tables in one archive, ready to send."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("raport.html", render_html(result, options_text).encode("utf-8"))
        for name, content in csv_files(result).items():
            archive.writestr(name, content)
    return buffer.getvalue()


# --- HTML --------------------------------------------------------------------------

CSS = """
:root{--bg:#f6f7f9;--panel:#fff;--text:#1d2330;--muted:#5d6779;--line:#dde1e8;--soft:#eef1f5;
--krit:#b42318;--krit-bg:#fde8e7;--ist:#b54708;--ist-bg:#fef0db;--kosm:#475467;--kosm-bg:#eceff3;--ok:#067647;--ok-bg:#dcf5e8}
@media (prefers-color-scheme:dark){:root{--bg:#12151b;--panel:#1a1f27;--text:#e4e8ef;--muted:#9aa4b5;--line:#2c3440;--soft:#222934;
--krit:#ff8a80;--krit-bg:#3d1c1a;--ist:#ffb867;--ist-bg:#3a2a14;--kosm:#b7c0cf;--kosm-bg:#2a313c;--ok:#6fd8a3;--ok-bg:#16352a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 -apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:1400px;margin:0 auto;padding:24px 16px 64px}h1{font-size:22px;margin:0 0 12px}h2{font-size:17px;margin:32px 0 10px}h4{margin:16px 0 6px;font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:12px;color:var(--muted);font-weight:600}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;white-space:nowrap}
.s3{color:var(--krit);background:var(--krit-bg)}.s2{color:var(--ist);background:var(--ist-bg)}.s1{color:var(--kosm);background:var(--kosm-bg)}.s0{color:var(--ok);background:var(--ok-bg)}
.verdict{font-size:15px;padding:6px 14px;margin-bottom:14px}
.filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 12px}.filters label{cursor:pointer;user-select:none}
.filters input[type=search]{flex:1;min-width:220px;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--panel);color:var(--text)}
details.group{background:var(--panel);border:1px solid var(--line);border-radius:10px;margin-bottom:8px}
details.group>summary{cursor:pointer;padding:10px 14px;display:flex;flex-wrap:wrap;gap:6px 14px;align-items:baseline;list-style:none}
details.group>summary::-webkit-details-marker{display:none}details.group[open]>summary{border-bottom:1px solid var(--line)}
.gid{color:var(--muted)}.name{font-weight:600}.muted{color:var(--muted)}.delta{font-weight:600;color:var(--krit)}
.body{padding:4px 14px 14px;overflow-x:auto}.cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media (max-width:900px){.cols{grid-template-columns:1fr}}
ul.links{margin:0;padding-left:0;list-style:none}ul.links li{margin:4px 0}.ok{color:var(--ok)}.bad{color:var(--krit)}
.scroll{overflow-x:auto}.nowrap{white-space:nowrap}.hidden{display:none!important}footer{margin-top:40px;color:var(--muted);font-size:12px}
"""

JS = """
const groups=[...document.querySelectorAll('details.group')];
const invoices=[...document.querySelectorAll('#invoice-table tbody tr')];
function apply(){
  const on=new Set([...document.querySelectorAll('.sev-filter:checked')].map(x=>x.value));
  const q=document.getElementById('q').value.trim().toLowerCase();
  let shown=0;
  for(const g of groups){const v=on.has(g.dataset.sev)&&(!q||g.dataset.text.includes(q));g.classList.toggle('hidden',!v);if(v)shown++;}
  document.getElementById('shown').textContent=shown;
  const onlyDiff=document.getElementById('inv-diff').checked;
  const iq=document.getElementById('iq').value.trim().toLowerCase();
  for(const r of invoices){r.classList.toggle('hidden',(onlyDiff&&r.dataset.ok==='1')||(iq&&!r.dataset.text.includes(iq)));}
}
document.querySelectorAll('.sev-filter,#inv-diff').forEach(x=>x.addEventListener('change',apply));
document.getElementById('q').addEventListener('input',apply);document.getElementById('iq').addEventListener('input',apply);
document.getElementById('expand').addEventListener('click',()=>groups.forEach(g=>{if(!g.classList.contains('hidden'))g.open=true}));
document.getElementById('collapse').addEventListener('click',()=>groups.forEach(g=>g.open=false));
apply();
"""


def _e(value: object) -> str:
    return escape(str(value), quote=True)


def _badge(severity: Severity) -> str:
    return f'<span class="badge s{severity.value}">{_e(severity.label)}</span>'


def _payment_table(title: str, payments: list[Payment], links: dict[int, tuple[Group, Link]]) -> str:
    if not payments:
        return f"<div><h4>{_e(title)}</h4><p class='muted'>brak przelewów</p></div>"
    rows = []
    for payment in payments:
        link = links[id(payment)][1]
        rows.append(
            "<tr>"
            f"<td class='mono'>#{payment.seq}</td><td class='num'>{_e(money(payment.amount, payment.currency))}</td>"
            f"<td class='nowrap'>{_e(payment.execution_date)}</td><td class='mono'>{_e(', '.join(ref.display for ref in payment.refs) or '—')}</td>"
            f"<td>{_e(payment.description or '—')}</td><td class='mono'>{_e(payment.end_to_end_id)}</td>"
            f"<td>{_badge(link.severity)} {_e(link.kind)}</td>"
            "</tr>"
        )
    return (
        f"<div><h4>{_e(title)}</h4><div class='scroll'><table><thead><tr><th>nr</th><th class='num'>kwota</th><th>data</th><th>numery</th>"
        f"<th>opis</th><th>EndToEndId</th><th>dopasowanie</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></div>"
    )


def _group_html(group: Group, links: dict[int, tuple[Group, Link]]) -> str:
    old_total, new_total = group.total(OLD), group.total(NEW)
    delta = delta_map(old_total, new_total)
    accounts = ", ".join(account_text(value) for value in group.values(lambda p: p.creditor_account))
    dates = ", ".join(group.values(lambda p: p.execution_date))
    currencies = ", ".join(group.values(lambda p: p.currency))
    account_values = group.values(lambda p: p.creditor_account)
    search = " ".join([group.creditor_name, accounts, dates] + account_values + [ref.display for p in group.payments for ref in p.refs]).lower()
    summary = (
        f"{_badge(group.severity)}<span class='gid'>#{group.id}</span><span class='name'>{_e(group.creditor_name)}</span>"
        f"<span class='mono'>{_e(accounts)}</span><span>{_e(currencies)}</span><span>{_e(dates)}</span>"
        f"<span class='muted'>{OLD} {len(group.old)} → {NEW} {len(group.new)} przel.</span>"
        f"<span class='num'>{_e(money_map(old_total))} → {_e(money_map(new_total))}</span>"
        + (f"<span class='delta'>Δ {_e(', '.join(money(v, c) for c, v in delta.items()))}</span>" if delta else "")
    )
    findings = "".join(
        f"<tr><td>{_badge(f.severity)}</td><td>{_e(f.category)}</td><td>{_e(f.message)}</td><td class='mono'>{_e(f.where)}</td><td>{_e(f.old)}</td><td>{_e(f.new)}</td></tr>"
        for f in sorted(group.findings, key=lambda f: -f.severity)
    )
    findings_html = (
        f"<h4>Różnice</h4><div class='scroll'><table><thead><tr><th>waga</th><th>kategoria</th><th>opis</th><th>przelewy</th><th>{OLD}</th><th>{NEW}</th></tr></thead><tbody>{findings}</tbody></table></div>"
        if findings else "<p class='ok'>Brak różnic merytorycznych.</p>"
    )
    link_items = "".join(
        f"<li>{_badge(link.severity)} {_e(', '.join(p.label for p in link.old) or '—')} ↔ {_e(', '.join(p.label for p in link.new) or '—')}"
        f" — {_e(link.kind)}{(' — ' + _e(link.note)) if link.note else ''}</li>"
        for link in group.links
    )
    invoice_rows = "".join(
        f"<tr><td class='mono'>{_e(row.display)}</td><td class='num'>{row.old_count}</td><td class='num'>{row.new_count}</td>"
        f"<td class='{'ok' if row.status == 'zgodna' else 'bad'}'>{_e(row.status)}</td><td>{_e(row.note)}</td></tr>"
        for row in group.invoices
    )
    invoices_html = (
        f"<h4>Faktury / numery</h4><div class='scroll'><table><thead><tr><th>numer</th><th class='num'>{OLD}</th><th class='num'>{NEW}</th><th>status</th><th>uwagi</th></tr></thead><tbody>{invoice_rows}</tbody></table></div>"
        if invoice_rows else "<h4>Faktury / numery</h4><p class='muted'>Nie rozpoznano numerów w opisie.</p>"
    )
    meta = (
        f"<p class='muted'>Para grup: {_e(group.pairing)} · rachunek obciążany: {_e(', '.join(account_text(v) for v in group.values(lambda p: p.debtor_account)))}</p>"
    )
    body = (
        meta + findings_html + f"<h4>Pary przelewów</h4><ul class='links'>{link_items}</ul>" + invoices_html
        + f"<div class='cols'>{_payment_table(OLD, group.old, links)}{_payment_table(NEW, group.new, links)}</div>"
    )
    return f"<details class='group' data-sev='{group.severity.value}' data-text='{_e(search)}'><summary>{summary}</summary><div class='body'>{body}</div></details>"


def write_html(result: Result, path: Path, options_text: str) -> Path:
    path.write_text(render_html(result, options_text), encoding="utf-8")
    return path


def render_html(result: Result, options_text: str) -> str:
    links = _links_by_payment(result)
    severity = result.severity
    verdict = {0: "Brak różnic merytorycznych", 1: "Tylko różnice kosmetyczne", 2: "Są różnice istotne", 3: "Są różnice krytyczne"}[severity.value]
    files = "".join(
        f"<tr><th>{side}</th><td>{_e(doc.name)}</td><td>{_e(doc.version)}</td><td class='num'>{len(doc.payments)}</td>"
        f"<td class='mono'>{_e(doc.msg_id)}</td><td>{_e(doc.created)}</td><td class='mono'>{_e(doc.sha256)}</td></tr>"
        for side, doc in ((OLD, result.old), (NEW, result.new))
    )
    totals = "".join(
        f"<tr><td>{_e(row.currency)}</td><td class='num'>{row.old_count}</td><td class='num'>{_e(money(row.old_sum))}</td>"
        f"<td class='num'>{row.new_count}</td><td class='num'>{_e(money(row.new_sum))}</td>"
        f"<td class='num {'bad' if row.new_sum != row.old_sum else 'ok'}'>{_e(money(row.new_sum - row.old_sum))}</td></tr>"
        for row in result.totals
    )
    stats = result.pair_stats()
    pair_rows = [
        (Severity.OK, "identyczne merytorycznie pary 1:1", stats.pairs[Severity.OK]),
        (Severity.KOSMETYCZNA, "pary 1:1 z różnicami kosmetycznymi", stats.pairs[Severity.KOSMETYCZNA]),
        (Severity.ISTOTNA, "pary 1:1 z różnicami istotnymi", stats.pairs[Severity.ISTOTNA]),
        (Severity.KRYTYCZNA, "pary 1:1 z różnicami krytycznymi", stats.pairs[Severity.KRYTYCZNA]),
        (Severity.KRYTYCZNA, f"inne grupowanie faktur ({OLD}: {plural(stats.regrouped_old)} → {NEW}: {plural(stats.regrouped_new)})", stats.regrouped),
        (Severity.KRYTYCZNA, f"przelewy tylko w pliku {OLD}", stats.only_old),
        (Severity.KRYTYCZNA, f"przelewy tylko w pliku {NEW}", stats.only_new),
    ]
    pairs = "".join(
        f"<tr><td>{_badge(level) if count else ''}</td><td>{_e(label)}</td><td class='num'>{count}</td></tr>"
        for level, label, count in pair_rows
    )
    file_findings = "".join(
        f"<tr><td>{_badge(f.severity)}</td><td>{_e(f.category)}</td><td>{_e(f.message)}</td><td>{_e(f.old)}</td><td>{_e(f.new)}</td></tr>"
        for f in result.file_findings
    )
    counts = Counter(group.severity for group in result.groups)
    chips = "".join(
        f"<label class='badge s{level.value}'><input type='checkbox' class='sev-filter' value='{level.value}'{' checked' if level >= Severity.KOSMETYCZNA else ''}> {_e(level.plural)} ({counts[level]})</label>"
        for level in sorted(Severity, reverse=True)
    )
    ordered = sorted(result.groups, key=lambda g: (-g.severity, g.id))
    invoice_rows = "".join(
        f"<tr data-ok='{1 if row.status == 'zgodna' else 0}' data-text='{_e((row.display + ' ' + group.creditor_name).lower())}'>"
        f"<td class='mono'>{_e(row.display)}</td><td>#{group.id} {_e(group.creditor_name)}</td><td>{_e(', '.join(group.values(lambda p: p.execution_date)))}</td>"
        f"<td class='num'>{row.old_count}</td><td class='num'>{row.new_count}</td>"
        f"<td class='mono'>{_e(', '.join(p.label for p in row.old_payments))}</td><td class='mono'>{_e(', '.join(p.label for p in row.new_payments))}</td>"
        f"<td class='{'ok' if row.status == 'zgodna' else 'bad'}'>{_e(row.status)}</td><td>{_e(row.note)}</td></tr>"
        for group, row in result.all_invoices()
    )
    html = f"""<!doctype html>
<html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Porównanie pain.001</title><style>{CSS}</style></head><body><main>
<h1>Porównanie merytoryczne plików pain.001</h1>
<div class="badge verdict s{severity.value}">{_e(verdict)}</div>
<div class="panel scroll"><table><thead><tr><th></th><th>plik</th><th>wersja</th><th class="num">przelewy</th><th>MsgId</th><th>CreDtTm</th><th>SHA-256</th></tr></thead><tbody>{files}</tbody></table></div>

<h2>Sumy wg walut</h2>
<div class="panel scroll"><table><thead><tr><th>waluta</th><th class="num">{OLD} szt.</th><th class="num">{OLD} suma</th><th class="num">{NEW} szt.</th><th class="num">{NEW} suma</th><th class="num">Δ</th></tr></thead><tbody>{totals}</tbody></table>
</div>

<h2>Przelewy</h2>
<div class="panel scroll"><table><tbody>{pairs}</tbody></table>
<p class="muted">Cel: każdy przelew z pliku {OLD} ma dokładnie jeden identyczny merytorycznie odpowiednik w pliku {NEW}.</p></div>
{f'<h2>Plik</h2><div class="panel scroll"><table><thead><tr><th>waga</th><th>kategoria</th><th>opis</th><th>{OLD}</th><th>{NEW}</th></tr></thead><tbody>{file_findings}</tbody></table></div>' if file_findings else ''}

<h2>Grupy beneficjentów <span class="muted">(rachunek obciążany + rachunek beneficjenta + waluta + data)</span></h2>
<div class="filters">{chips}<input id="q" type="search" placeholder="Szukaj: nazwa, rachunek, numer faktury…">
<span class="muted">widoczne: <b id="shown"></b> / {len(result.groups)}</span>
<button id="expand" type="button">Rozwiń widoczne</button><button id="collapse" type="button">Zwiń</button></div>
{''.join(_group_html(group, links) for group in ordered)}

<h2>Faktury / numery</h2>
<div class="filters"><label><input id="inv-diff" type="checkbox" checked> tylko z różnicą</label><input id="iq" type="search" placeholder="Szukaj numeru lub beneficjenta…"></div>
<div class="panel scroll"><table id="invoice-table"><thead><tr><th>numer</th><th>grupa</th><th>data</th><th class="num">{OLD}</th><th class="num">{NEW}</th><th>przelewy {OLD}</th><th>przelewy {NEW}</th><th>status</th><th>uwagi</th></tr></thead><tbody>{invoice_rows}</tbody></table></div>

<footer>Wygenerowano {_e(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))} · {_e(options_text)} · Pominięte pola techniczne: MsgId, CreDtTm, PmtInfId, InstrId, EndToEndId, NbOfTxs/CtrlSum (sprawdzane tylko pod kątem spójności), kolejność i podział na PmtInf, wersja schematu.</footer>
</main><script>{JS}</script></body></html>"""
    return html
