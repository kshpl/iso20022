from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import IntEnum


class Severity(IntEnum):
    OK = 0
    KOSMETYCZNA = 1
    ISTOTNA = 2
    KRYTYCZNA = 3

    @property
    def label(self) -> str:
        return {0: "zgodne", 1: "kosmetyczna", 2: "istotna", 3: "krytyczna"}[self.value]

    @property
    def plural(self) -> str:
        return {0: "zgodne", 1: "kosmetyczne", 2: "istotne", 3: "krytyczne"}[self.value]

    @property
    def tag(self) -> str:
        return {0: "OK", 1: "KOSM", 2: "ISTOT", 3: "KRYT"}[self.value]


@dataclass(frozen=True)
class InvoiceRef:
    """One invoice-like identifier found in a payment (number, reference, /INV/ ...)."""

    display: str
    source: str
    amount: Decimal | None = None

    @property
    def key(self) -> str:
        return self.display.upper()


@dataclass
class TextVariant:
    """Tokenization of free-text remittance for one way of joining Ustrd lines."""

    glued: int
    refs: list[InvoiceRef]
    words: list[str]
    text: str = ""


@dataclass
class Mpp:
    vat: Decimal | None
    vat_raw: str
    nip: str
    invoice: str
    text: str
    source: str


@dataclass
class Payment:
    seq: int
    side: str
    pmt_inf_id: str
    instr_id: str
    end_to_end_id: str
    execution_date: str
    debtor_name: str
    debtor_account: str
    debtor_account_raw: str
    currency: str
    amount: Decimal | None
    amount_raw: str
    creditor_name: str
    creditor_account: str
    creditor_account_raw: str
    creditor_bic: str
    creditor_country: str
    creditor_address: str
    payment_type: dict[str, str]
    ultimate_debtor: str
    ultimate_creditor: str
    ustrd: list[str]
    strd_summary: str
    tax_info: str
    mpp: Mpp | None
    fixed_refs: list[InvoiceRef]
    fixed_words: list[str]
    text_variants: list[TextVariant]
    chosen_variant: int = 0

    @property
    def refs(self) -> list[InvoiceRef]:
        variant = self.text_variants[self.chosen_variant] if self.text_variants else None
        return self.fixed_refs + (variant.refs if variant else [])

    @property
    def words(self) -> list[str]:
        variant = self.text_variants[self.chosen_variant] if self.text_variants else None
        return self.fixed_words + (variant.words if variant else [])

    @property
    def description(self) -> str:
        parts = [" | ".join(self.ustrd)] if self.ustrd else []
        if self.strd_summary:
            parts.append(self.strd_summary)
        return " || ".join(parts)

    @property
    def remittance_text(self) -> str:
        """Ustrd as one line, read the same way as the invoice numbers were."""
        if self.text_variants:
            return " ".join(self.text_variants[self.chosen_variant].text.split())
        return " ".join("".join(self.ustrd).split())

    @property
    def ustrd_length(self) -> int:
        return sum(len(line) for line in self.ustrd)

    @property
    def label(self) -> str:
        return f"{self.side} #{self.seq}"


@dataclass
class PmtInfCheck:
    pmt_inf_id: str
    declared_count: str
    declared_sum: str
    count: int
    total: Decimal | None


@dataclass
class Document:
    path: str
    name: str
    sha256: str
    size: int
    namespace: str
    version: str
    msg_id: str
    created: str
    declared_count: str
    declared_sum: str
    pmt_infs: list[PmtInfCheck]
    payments: list[Payment] = field(default_factory=list)
