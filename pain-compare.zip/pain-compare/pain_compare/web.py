"""Local browser UI: pick two pain.001 files, read the report, download it.

The server listens on 127.0.0.1 only. Uploaded files and generated reports live in this
process' memory and disappear when it stops. POST requests must carry the session token
embedded in the page, and every request must use the server's own Host, so other
websites open in the same browser cannot drive it (CSRF, DNS rebinding).
"""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import threading
import webbrowser

from .compare import NEW, OLD, compare_documents, money
from .extract import MAX_BYTES, InputError, load_document_bytes
from .model import Severity
from .report_files import render_html, report_zip

INDEX = Path(__file__).with_name("web_index.html")
DEFAULT_PORT = 8875
PORT_ATTEMPTS = 50
MAX_BODY = 2 * (MAX_BYTES * 4 // 3 + 4) + 64 * 1024
MAX_REPORTS = 20
REPORT_PATH = re.compile(r"/report/([A-Za-z0-9_-]{16,64})/(raport\.html|pobierz\.html|pobierz\.zip)")
REPORT_CSP = "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'"
VERDICTS = {
    Severity.OK: "Pliki są zgodne merytorycznie.",
    Severity.KOSMETYCZNA: "Pliki są zgodne merytorycznie, są tylko różnice kosmetyczne.",
    Severity.ISTOTNA: "Są różnice istotne.",
    Severity.KRYTYCZNA: "Są różnice krytyczne.",
}


@dataclass(frozen=True)
class StoredReport:
    id: str
    stem: str
    html: bytes
    archive: bytes


class AppState:
    def __init__(self, port: int):
        self.port = port
        self.token = secrets.token_urlsafe(32)
        self.reports: dict[str, StoredReport] = {}
        self.lock = threading.Lock()

    @property
    def hosts(self) -> set[str]:
        return {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}

    @property
    def origins(self) -> set[str]:
        return {f"http://{host}" for host in self.hosts}

    def add(self, report: StoredReport) -> None:
        with self.lock:
            self.reports[report.id] = report
            while len(self.reports) > MAX_REPORTS:
                self.reports.pop(next(iter(self.reports)))

    def get(self, report_id: str) -> StoredReport | None:
        with self.lock:
            return self.reports.get(report_id)


def _ascii_stem(name: str) -> str:
    stem = Path(name).stem
    return (re.sub(r"[^A-Za-z0-9.-]+", "_", stem).strip("_") or "plik")[:40]


def run_comparison(old_name: str, old_payload: bytes, new_name: str, new_payload: bytes, invoice_regex: str = "") -> tuple[dict, StoredReport]:
    pattern = None
    if invoice_regex.strip():
        try:
            pattern = re.compile(invoice_regex.strip(), re.IGNORECASE)
        except re.error as exc:
            raise InputError(f"Niepoprawny wzorzec numeru faktury: {exc}") from exc
    old = load_document_bytes(old_payload, old_name, OLD, pattern)
    new = load_document_bytes(new_payload, new_name, NEW, pattern)
    result = compare_documents(old, new)
    options = f"wzorzec faktur: {invoice_regex.strip() or 'domyślny (słowa z cyfrą)'}"
    stem = f"porownanie_{_ascii_stem(old_name)}_vs_{_ascii_stem(new_name)}_{datetime.now():%Y-%m-%d_%H%M}"
    report = StoredReport(secrets.token_urlsafe(18), stem, render_html(result, options).encode("utf-8"), report_zip(result, options))
    stats = result.pair_stats()
    summary = {
        "id": report.id,
        "severity": result.severity.value,
        "severity_label": result.severity.label,
        "verdict": VERDICTS[result.severity],
        "files": [
            {"side": side, "name": document.name, "version": document.version, "count": len(document.payments)}
            for side, document in ((OLD, old), (NEW, new))
        ],
        "pairs": {
            "ok": stats.pairs[Severity.OK],
            "cosmetic": stats.pairs[Severity.KOSMETYCZNA],
            "important": stats.pairs[Severity.ISTOTNA],
            "critical": stats.pairs[Severity.KRYTYCZNA],
            "regrouped": stats.regrouped,
            "regrouped_old": stats.regrouped_old,
            "regrouped_new": stats.regrouped_new,
            "only_old": stats.only_old,
            "only_new": stats.only_new,
        },
        "totals": [
            {
                "currency": row.currency,
                "old_count": row.old_count,
                "old_sum": money(row.old_sum),
                "new_count": row.new_count,
                "new_sum": money(row.new_sum),
                "delta": money(row.new_sum - row.old_sum) if row.new_sum != row.old_sum else "",
            }
            for row in result.totals
        ],
        "file_findings": [{"severity": f.severity.value, "label": f.severity.label, "message": f.message} for f in result.file_findings],
        "links": {
            "view": f"/report/{report.id}/raport.html",
            "html": f"/report/{report.id}/pobierz.html",
            "zip": f"/report/{report.id}/pobierz.zip",
        },
        "filename": stem,
    }
    return summary, report


class Handler(BaseHTTPRequestHandler):
    server_version = "pain-compare"
    sys_version = ""
    server: Server

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002 - signature of the base class
        pass

    @property
    def state(self) -> AppState:
        return self.server.state

    def _send(self, status: int, body: bytes, content_type: str, headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        if self.command != "HEAD" and body:
            self.wfile.write(body)

    def _json(self, status: int, data: dict) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _host_allowed(self) -> bool:
        if self.headers.get("Host", "") in self.state.hosts:
            return True
        self._json(403, {"error": "Niedozwolony adres hosta."})
        return False

    def do_GET(self) -> None:  # noqa: N802 - name required by BaseHTTPRequestHandler
        if not self._host_allowed():
            return
        path = self.path.split("?", 1)[0]
        if path == "/":
            nonce = secrets.token_urlsafe(16)
            page = INDEX.read_text(encoding="utf-8").replace("__TOKEN__", self.state.token).replace("__NONCE__", nonce)
            csp = f"default-src 'none'; script-src 'nonce-{nonce}'; style-src 'unsafe-inline'; connect-src 'self'; frame-src 'self'; img-src data:; base-uri 'none'; form-action 'none'"
            self._send(200, page.encode("utf-8"), "text/html; charset=utf-8", {"Content-Security-Policy": csp, "X-Frame-Options": "DENY"})
            return
        match = REPORT_PATH.fullmatch(path)
        if match:
            report = self.state.get(match.group(1))
            if report is None:
                self._json(404, {"error": "Raport nie jest już dostępny — uruchom porównanie ponownie."})
            elif match.group(2) == "raport.html":
                self._send(200, report.html, "text/html; charset=utf-8", {"Content-Security-Policy": REPORT_CSP, "X-Frame-Options": "SAMEORIGIN"})
            elif match.group(2) == "pobierz.html":
                self._send(200, report.html, "text/html; charset=utf-8", {"Content-Security-Policy": REPORT_CSP, "Content-Disposition": f'attachment; filename="{report.stem}.html"'})
            else:
                self._send(200, report.archive, "application/zip", {"Content-Disposition": f'attachment; filename="{report.stem}.zip"'})
            return
        if path == "/favicon.ico":
            self._send(204, b"", "image/x-icon")
            return
        self._json(404, {"error": "Nie znaleziono."})

    def do_POST(self) -> None:  # noqa: N802 - name required by BaseHTTPRequestHandler
        if not self._host_allowed():
            return
        origin = self.headers.get("Origin")
        if (origin and origin not in self.state.origins) or not secrets.compare_digest(self.headers.get("X-Token", ""), self.state.token):
            self._json(403, {"error": "Brak uprawnień — odśwież stronę aplikacji."})
            return
        path = self.path.split("?", 1)[0]
        if path == "/api/compare":
            self._compare()
        elif path == "/api/shutdown":
            self._json(200, {"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        else:
            self._json(404, {"error": "Nie znaleziono."})

    def _compare(self) -> None:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = -1
        if length <= 0 or length > MAX_BODY:
            self._json(413, {"error": f"Pliki są puste albo za duże (limit {MAX_BYTES // (1024 * 1024)} MiB na plik)."})
            return
        try:
            data = json.loads(self.rfile.read(length))
            old_name, old_payload = _uploaded(data, "old")
            new_name, new_payload = _uploaded(data, "new")
            summary, report = run_comparison(old_name, old_payload, new_name, new_payload, str(data.get("invoice_regex") or ""))
        except (InputError, json.JSONDecodeError, AttributeError) as exc:
            self._json(422, {"error": str(exc) if isinstance(exc, InputError) else "Niepoprawne żądanie."})
            return
        except Exception as exc:  # the UI must show something useful instead of a dropped connection
            self._json(500, {"error": f"Błąd wewnętrzny narzędzia ({type(exc).__name__}): {exc}"})
            return
        self.state.add(report)
        self._json(200, summary)


def _uploaded(data: dict, key: str) -> tuple[str, bytes]:
    item = data.get(key) or {}
    name = Path(str(item.get("name") or f"{key}.xml")).name[:200]
    try:
        payload = base64.b64decode(str(item.get("data") or ""), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise InputError(f"Nie udało się odczytać przesłanego pliku {name}.") from exc
    return name, payload


class Server(ThreadingHTTPServer):
    daemon_threads = True
    # On Windows SO_REUSEADDR would allow two servers on one port; a busy port must fail.
    allow_reuse_address = False

    def __init__(self, address: tuple[str, int]):
        super().__init__(address, Handler)
        self.state = AppState(self.server_address[1])

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.server_address[1]}/"


def start_server(port: int | None = None) -> Server:
    candidates = [port] if port is not None else range(DEFAULT_PORT, DEFAULT_PORT + PORT_ATTEMPTS)
    last_error: OSError | None = None
    for candidate in candidates:
        try:
            return Server(("127.0.0.1", candidate))
        except OSError as exc:
            last_error = exc
    raise InputError(f"Nie udało się uruchomić serwera na 127.0.0.1 (porty {candidates[0]}–{candidates[-1]}): {last_error}")


def serve(port: int | None = None, open_browser: bool = True) -> int:
    server = start_server(port)
    print(f"pain-compare działa pod adresem {server.url}")
    print("Zamknij przyciskiem „Zakończ” w aplikacji albo Ctrl+C w tym oknie.")
    if open_browser:
        threading.Timer(0.4, webbrowser.open, [server.url]).start()
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    print("Aplikacja zamknięta. Raporty z tej sesji usunięto z pamięci.")
    return 0
