"""Reading pain.001 (any version, tested with .03 and .09) into flat business records.

Elements are matched by local name, so the namespace version does not matter.
The parser settings follow the main project: no DTD, entities, network or XInclude.
"""

from __future__ import annotations

from decimal import Decimal
import hashlib
from io import BytesIO
from pathlib import Path
import re

from lxml import etree

from .model import Document, InvoiceRef, Mpp, Payment, PmtInfCheck
from .remittance import parse_decimal, parse_mpp, tokenize, ustrd_variants

MAX_BYTES = 100 * 1024 * 1024
PAYMENT_TYPE_FIELDS = ("SvcLvl", "LclInstrm", "CtgyPurp", "InstrPrty", "Purp", "ChrgBr")


class InputError(ValueError):
    pass


def _local(node: etree._Element) -> str | None:
    return etree.QName(node).localname if isinstance(node.tag, str) else None


def kids(parent: etree._Element | None, name: str) -> list[etree._Element]:
    if parent is None:
        return []
    return [child for child in parent if isinstance(child.tag, str) and _local(child) == name]


def kid(parent: etree._Element | None, name: str) -> etree._Element | None:
    found = kids(parent, name)
    return found[0] if found else None


def at(parent: etree._Element | None, path: str) -> etree._Element | None:
    node = parent
    for part in path.split("/"):
        node = kid(node, part)
        if node is None:
            return None
    return node


def text(parent: etree._Element | None, path: str | None = None) -> str:
    node = at(parent, path) if path else parent
    if node is None or node.text is None:
        return ""
    return node.text.strip()


def first(parent: etree._Element | None, *paths: str) -> str:
    for path in paths:
        value = text(parent, path)
        if value:
            return value
    return ""


def leaves(node: etree._Element | None, prefix: str = "") -> list[tuple[str, str]]:
    """All non-empty leaf values below a node as (relative path, value)."""
    if node is None:
        return []
    result: list[tuple[str, str]] = []
    for child in node:
        name = _local(child)
        if name is None:
            continue
        path = f"{prefix}/{name}" if prefix else name
        if len(child):
            result.extend(leaves(child, path))
        else:
            value = (child.text or "").strip()
            for attr, attr_value in child.attrib.items():
                value = f"{value} {attr}={attr_value}".strip()
            if value:
                result.append((path, value))
    return result


def normalize_account(raw: str) -> str:
    value = re.sub(r"[\s-]", "", raw).upper()
    if re.fullmatch(r"\d{26}", value):
        value = "PL" + value
    return value


def _account(parent: etree._Element | None) -> tuple[str, str]:
    ident = kid(parent, "Id")
    raw = first(ident, "IBAN", "Othr/Id")
    return normalize_account(raw), raw


def _code(parent: etree._Element | None, name: str) -> str:
    values = [first(node, "Cd", "Prtry") for node in kids(parent, name)]
    return "+".join(value for value in values if value)


def _payment_type(group: etree._Element, tx: etree._Element) -> dict[str, str]:
    result: dict[str, str] = {}
    for level in (group, tx):
        info = kid(level, "PmtTpInf")
        if info is not None:
            for name in ("SvcLvl", "LclInstrm", "CtgyPurp"):
                value = _code(info, name)
                if value:
                    result[name] = value
            if text(info, "InstrPrty"):
                result["InstrPrty"] = text(info, "InstrPrty")
        if text(level, "ChrgBr"):
            result["ChrgBr"] = text(level, "ChrgBr")
    purpose = first(tx, "Purp/Cd", "Purp/Prtry")
    if purpose:
        result["Purp"] = purpose
    return {name: result.get(name, "") for name in PAYMENT_TYPE_FIELDS}


def _amount(tx: etree._Element) -> tuple[Decimal | None, str, str]:
    amt = kid(tx, "Amt")
    node = kid(amt, "InstdAmt")
    if node is None:
        node = at(amt, "EqvtAmt/Amt")
    if node is None:
        return None, "", ""
    raw = (node.text or "").strip()
    value = Decimal(raw) if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", raw) else None
    return value, raw, node.get("Ccy", "")


def _address(party: etree._Element | None) -> tuple[str, str]:
    address = kid(party, "PstlAdr")
    if address is None:
        return "", ""
    values = [value for _, value in leaves(address)]
    return ", ".join(values), text(address, "Ctry")


def _structured(remittance: etree._Element | None, invoice_regex: re.Pattern[str] | None) -> tuple[list[InvoiceRef], list[str], Mpp | None, str]:
    refs: list[InvoiceRef] = []
    words: list[str] = []
    mpp: Mpp | None = None
    summary: list[str] = []
    for structured in kids(remittance, "Strd"):
        documents = kids(structured, "RfrdDocInf")
        amount_node = kid(structured, "RfrdDocAmt")
        amount: Decimal | None = None
        if amount_node is not None and len(documents) == 1:
            paid = first(amount_node, "RmtdAmt", "DuePyblAmt")
            credit = text(amount_node, "CdtNoteAmt")
            if paid:
                amount = parse_decimal(paid)
            elif credit and parse_decimal(credit) is not None:
                amount = -parse_decimal(credit)
        for document in documents:
            number = text(document, "Nb")
            if number:
                refs.append(InvoiceRef(number, "Strd/RfrdDocInf/Nb", amount))
        reference = text(structured, "CdtrRefInf/Ref")
        if reference:
            refs.append(InvoiceRef(reference, "Strd/CdtrRefInf/Ref"))
        tax_remittance = kid(structured, "TaxRmt")
        if tax_remittance is not None:
            vat_raw = text(tax_remittance, "TtlTaxAmt")
            ref_number = text(tax_remittance, "RefNb")
            mpp = Mpp(parse_decimal(vat_raw) if vat_raw else None, vat_raw, text(tax_remittance, "Cdtr/TaxId"), ref_number, "", "Strd/TaxRmt")
            if ref_number:
                refs.append(InvoiceRef(ref_number, "Strd/TaxRmt/RefNb"))
        for additional in kids(structured, "AddtlRmtInf"):
            extra_refs, extra_words = tokenize(text(additional), "Strd/AddtlRmtInf", invoice_regex)
            refs.extend(extra_refs)
            words.extend(extra_words)
        summary.append("; ".join(f"{path}={value}" for path, value in leaves(structured)))
    return refs, words, mpp, " || ".join(summary)


def _payment(group: etree._Element, tx: etree._Element, seq: int, side: str, invoice_regex: re.Pattern[str] | None, e2e_as_invoice: bool) -> Payment:
    debtor_account, debtor_account_raw = _account(kid(group, "DbtrAcct"))
    creditor_account, creditor_account_raw = _account(kid(tx, "CdtrAcct"))
    amount, amount_raw, currency = _amount(tx)
    execution = kid(group, "ReqdExctnDt")
    execution_date = first(execution, "Dt", "DtTm") or text(execution)
    address, country = _address(kid(tx, "Cdtr"))
    agent = at(tx, "CdtrAgt/FinInstnId")
    bic = first(agent, "BICFI", "BIC") or (f"clr:{text(agent, 'ClrSysMmbId/MmbId')}" if text(agent, "ClrSysMmbId/MmbId") else "")

    remittance = kid(tx, "RmtInf")
    ustrd = [(node.text or "") for node in kids(remittance, "Ustrd")]
    fixed_refs, fixed_words, mpp, strd_summary = _structured(remittance, invoice_regex)
    variants = []
    parsed_mpp = parse_mpp(ustrd, invoice_regex)
    if parsed_mpp is not None:
        mpp, mpp_refs, mpp_words = parsed_mpp
        fixed_refs = mpp_refs + fixed_refs
        fixed_words = mpp_words + fixed_words
    else:
        variants = ustrd_variants([line.strip("\r\n") for line in ustrd], invoice_regex)
    end_to_end = text(tx, "PmtId/EndToEndId")
    if e2e_as_invoice and end_to_end and end_to_end.upper() != "NOTPROVIDED":
        fixed_refs.append(InvoiceRef(end_to_end, "EndToEndId"))

    tax_info = "; ".join(f"Tax/{path}={value}" for path, value in leaves(kid(tx, "Tax")))
    return Payment(
        seq=seq,
        side=side,
        pmt_inf_id=text(group, "PmtInfId"),
        instr_id=text(tx, "PmtId/InstrId"),
        end_to_end_id=end_to_end,
        execution_date=execution_date,
        debtor_name=text(group, "Dbtr/Nm"),
        debtor_account=debtor_account,
        debtor_account_raw=debtor_account_raw,
        currency=currency,
        amount=amount,
        amount_raw=amount_raw,
        creditor_name=text(tx, "Cdtr/Nm"),
        creditor_account=creditor_account,
        creditor_account_raw=creditor_account_raw,
        creditor_bic=bic,
        creditor_country=country,
        creditor_address=address,
        payment_type=_payment_type(group, tx),
        ultimate_debtor=first(tx, "UltmtDbtr/Nm") or first(group, "UltmtDbtr/Nm"),
        ultimate_creditor=first(tx, "UltmtCdtr/Nm"),
        ustrd=ustrd,
        strd_summary=strd_summary,
        tax_info=tax_info,
        mpp=mpp,
        fixed_refs=fixed_refs,
        fixed_words=fixed_words,
        text_variants=variants,
    )


def parse_tree(payload: bytes) -> etree._ElementTree:
    parser = etree.XMLParser(
        resolve_entities=False,
        load_dtd=False,
        no_network=True,
        huge_tree=False,
        remove_comments=True,
        remove_pis=True,
        collect_ids=False,
    )
    if re.search(rb"<!DOCTYPE|<!ENTITY", payload[:4096], re.IGNORECASE):
        raise InputError("Plik zawiera deklarację DTD/encji — odrzucony ze względów bezpieczeństwa.")
    try:
        tree = etree.parse(BytesIO(payload), parser)
    except etree.XMLSyntaxError as exc:
        message = re.sub(r",? line \d+, column \d+$", "", exc.msg or "")
        raise InputError(f"Niepoprawny XML: {message} (linia {exc.position[0]}, kolumna {exc.position[1]}).") from exc
    if tree.docinfo.doctype:
        raise InputError("Plik zawiera deklarację DTD — odrzucony ze względów bezpieczeństwa.")
    return tree


def load_document(path: str | Path, side: str, invoice_regex: re.Pattern[str] | None = None, e2e_as_invoice: bool = False) -> Document:
    file_path = Path(path)
    try:
        payload = file_path.read_bytes()
    except OSError as exc:
        raise InputError(f"Nie można odczytać pliku {file_path}: {exc.strerror}.") from exc
    return load_document_bytes(payload, file_path.name, side, invoice_regex, e2e_as_invoice, str(file_path))


def load_document_bytes(
    payload: bytes,
    name: str,
    side: str,
    invoice_regex: re.Pattern[str] | None = None,
    e2e_as_invoice: bool = False,
    path: str = "",
) -> Document:
    if not payload:
        raise InputError(f"Plik {name} jest pusty.")
    if len(payload) > MAX_BYTES:
        raise InputError(f"Plik {name} przekracza limit {MAX_BYTES // (1024 * 1024)} MiB.")
    try:
        root = parse_tree(payload).getroot()
    except InputError as exc:
        raise InputError(f"{name}: {exc}") from exc
    namespace = etree.QName(root).namespace or ""
    if "pain.001" not in namespace:
        raise InputError(f"Plik {name} nie jest komunikatem pain.001 (namespace: {namespace or 'brak'}).")
    initiation = kid(root, "CstmrCdtTrfInitn")
    if initiation is None:
        raise InputError(f"Plik {name} nie zawiera elementu CstmrCdtTrfInitn.")
    header = kid(initiation, "GrpHdr")
    document = Document(
        path=path or name,
        name=name,
        sha256=hashlib.sha256(payload).hexdigest(),
        size=len(payload),
        namespace=namespace,
        version=namespace.rsplit(":", 1)[-1],
        msg_id=text(header, "MsgId"),
        created=text(header, "CreDtTm"),
        declared_count=text(header, "NbOfTxs"),
        declared_sum=text(header, "CtrlSum"),
        pmt_infs=[],
    )
    seq = 0
    for group in kids(initiation, "PmtInf"):
        group_payments = []
        for tx in kids(group, "CdtTrfTxInf"):
            seq += 1
            group_payments.append(_payment(group, tx, seq, side, invoice_regex, e2e_as_invoice))
        amounts = [payment.amount for payment in group_payments]
        total = sum(amounts, Decimal(0)) if all(value is not None for value in amounts) else None
        document.pmt_infs.append(PmtInfCheck(text(group, "PmtInfId"), text(group, "NbOfTxs"), text(group, "CtrlSum"), len(group_payments), total))
        document.payments.extend(group_payments)
    return document
