from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import re
import sys

from .compare import NEW, OLD, compare_documents
from .extract import InputError, load_document
from .model import Severity
from .report_files import write_csv_files, write_html
from .report_text import render_console, render_inspect

TOOL_DIR = Path(__file__).resolve().parent.parent
EXIT_OK, EXIT_DIFFERENCES, EXIT_ERROR = 0, 1, 2


def _regex(value: str | None) -> re.Pattern[str] | None:
    if not value:
        return None
    try:
        return re.compile(value, re.IGNORECASE)
    except re.error as exc:
        raise InputError(f"Niepoprawne wyrażenie --invoice-regex: {exc}") from exc


def _add_extraction_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--invoice-regex", metavar="WZORZEC", help="własny wzorzec numeru faktury w opisie, np. 'FV[/ ]?\\d+/\\d{2,4}' (domyślnie: każde słowo z cyfrą)")
    parser.add_argument("--e2e-as-invoice", action="store_true", help="traktuj EndToEndId jako numer faktury (gdy ERP wpisuje go tam)")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m pain_compare", description="Merytoryczne porównanie dwóch plików pain.001 (ISO 20022).")
    commands = parser.add_subparsers(dest="command", required=True)

    compare = commands.add_parser("compare", help="porównaj plik STARY i NOWY")
    compare.add_argument("old", metavar="STARY.xml")
    compare.add_argument("new", metavar="NOWY.xml")
    compare.add_argument("--out", metavar="KATALOG", help="katalog raportu (domyślnie pain-compare/reports/<data>_<pliki>)")
    compare.add_argument("--no-files", action="store_true", help="tylko wynik w konsoli, bez HTML/CSV")
    compare.add_argument("--all", action="store_true", help="pokaż w konsoli także grupy zgodne i z różnicami kosmetycznymi")
    compare.add_argument("--limit", type=int, default=50, help="maksymalna liczba grup w konsoli (domyślnie 50)")
    _add_extraction_options(compare)

    web = commands.add_parser("web", help="uruchom aplikację w przeglądarce (wybór plików, podgląd i pobranie raportu)")
    web.add_argument("--port", type=int, help="port na 127.0.0.1 (domyślnie pierwszy wolny od 8875)")
    web.add_argument("--no-browser", action="store_true", help="nie otwieraj przeglądarki automatycznie")

    inspect = commands.add_parser("inspect", help="pokaż, co narzędzie odczytało z jednego pliku")
    inspect.add_argument("file", metavar="PLIK.xml")
    inspect.add_argument("--csv", metavar="PLIK.csv", help="zapisz też listę przelewów do CSV")
    _add_extraction_options(inspect)
    return parser


def _console_utf8() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def _safe_stem(path: str) -> str:
    return re.sub(r"[^\w.-]+", "_", Path(path).stem)[:40]


def run_compare(args: argparse.Namespace) -> int:
    regex = _regex(args.invoice_regex)
    old = load_document(args.old, OLD, regex, args.e2e_as_invoice)
    new = load_document(args.new, NEW, regex, args.e2e_as_invoice)
    result = compare_documents(old, new)
    report_dir = None
    if not args.no_files:
        directory = Path(args.out) if args.out else TOOL_DIR / "reports" / f"{datetime.now():%Y-%m-%d_%H%M%S}_{_safe_stem(args.old)}_vs_{_safe_stem(args.new)}"
        directory.mkdir(parents=True, exist_ok=True)
        options = f"wzorzec faktur: {args.invoice_regex or 'domyślny (słowa z cyfrą)'}; EndToEndId jako faktura: {'tak' if args.e2e_as_invoice else 'nie'}"
        html = write_html(result, directory / "raport.html", options)
        write_csv_files(result, directory)
        report_dir = str(html)
    print(render_console(result, show_all=args.all, limit=args.limit, report_dir=report_dir))
    return EXIT_DIFFERENCES if result.severity >= Severity.ISTOTNA else EXIT_OK


def run_inspect(args: argparse.Namespace) -> int:
    document = load_document(args.file, "PLIK", _regex(args.invoice_regex), args.e2e_as_invoice)
    print(render_inspect(document, document.payments))
    if args.csv:
        import csv

        with open(args.csv, "w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle, delimiter=";")
            writer.writerow(["nr", "data", "beneficjent", "rachunek", "kwota", "waluta", "numery", "źródła numerów", "pozostałe słowa", "Ustrd", "Strd", "EndToEndId"])
            for payment in document.payments:
                writer.writerow([
                    payment.seq,
                    payment.execution_date,
                    payment.creditor_name,
                    payment.creditor_account,
                    payment.amount_raw.replace(".", ","),
                    payment.currency,
                    ", ".join(ref.display for ref in payment.refs),
                    ", ".join(sorted({ref.source for ref in payment.refs})),
                    " ".join(payment.words),
                    " | ".join(payment.ustrd),
                    payment.strd_summary,
                    payment.end_to_end_id,
                ])
        print(f"CSV: {args.csv}")
    return EXIT_OK


def main(argv: list[str] | None = None) -> int:
    _console_utf8()
    args = _parser().parse_args(argv)
    try:
        if args.command == "web":
            from .web import serve

            return serve(args.port, open_browser=not args.no_browser)
        return run_compare(args) if args.command == "compare" else run_inspect(args)
    except InputError as exc:
        print(f"BŁĄD: {exc}", file=sys.stderr)
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
