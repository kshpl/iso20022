"""Business comparison of two pain.001 documents, payment by payment.

Every payment of the old file must have exactly one counterpart in the new file with
the same amount, accounts, date, payment type and remittance; only technical tags
(identifiers, creation time, schema version) may differ.

To find counterparts, payments are first grouped by (debtor account, creditor account,
currency, execution date) — the key the ERP uses when it merges invoices into one
transfer. Inside a group, payments are paired; when invoices are spread over a
different number of transfers, the link "grouping m→n" is a critical difference.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from decimal import Decimal
import re
import unicodedata

from .extract import PAYMENT_TYPE_FIELDS
from .model import Document, Payment, Severity
from .remittance import EDGE_PUNCTUATION, SEPARATOR

OLD = "STARY"
NEW = "NOWY"
DESCRIPTION_LIMIT = 140
NEAR_LIMIT = 130

PAYMENT_TYPE_LABELS = {
    "SvcLvl": "Typ usługi (SvcLvl)",
    "LclInstrm": "Instrument lokalny (LclInstrm)",
    "CtgyPurp": "Kategoria celu (CtgyPurp)",
    "InstrPrty": "Priorytet (InstrPrty)",
    "Purp": "Cel płatności (Purp)",
    "ChrgBr": "Opłaty (ChrgBr)",
}
ABSENCE_MATTERS = {"SvcLvl", "LclInstrm", "CtgyPurp", "ChrgBr"}


@dataclass
class Finding:
    severity: Severity
    category: str
    message: str
    old: str = ""
    new: str = ""
    where: str = ""


@dataclass
class Link:
    """Payments of both files that correspond to each other (ideally exactly one and one)."""

    old: list[Payment]
    new: list[Payment]
    kind: str
    severity: Severity = Severity.OK
    note: str = ""

    @property
    def ok(self) -> bool:
        return self.severity == Severity.OK

    @property
    def is_pair(self) -> bool:
        return len(self.old) == 1 and len(self.new) == 1


@dataclass
class InvoiceRow:
    display: str
    old_count: int
    new_count: int
    old_payments: list[Payment]
    new_payments: list[Payment]
    status: str
    note: str = ""


@dataclass
class Group:
    id: int
    old: list[Payment]
    new: list[Payment]
    pairing: str
    findings: list[Finding] = field(default_factory=list)
    links: list[Link] = field(default_factory=list)
    invoices: list[InvoiceRow] = field(default_factory=list)

    @property
    def severity(self) -> Severity:
        return max((finding.severity for finding in self.findings), default=Severity.OK)

    @property
    def payments(self) -> list[Payment]:
        return self.old + self.new

    @property
    def creditor_name(self) -> str:
        names = [payment.creditor_name for payment in (self.old or self.new) if payment.creditor_name]
        return Counter(names).most_common(1)[0][0] if names else "(brak nazwy)"

    def values(self, getter, side: str | None = None) -> list[str]:
        payments = self.payments if side is None else (self.old if side == OLD else self.new)
        return unique(getter(payment) for payment in payments)

    def total(self, side: str) -> dict[str, Decimal]:
        return totals(self.old if side == OLD else self.new)


@dataclass
class TotalRow:
    currency: str
    old_count: int
    old_sum: Decimal
    new_count: int
    new_sum: Decimal


@dataclass
class Result:
    old: Document
    new: Document
    groups: list[Group]
    file_findings: list[Finding]
    totals: list[TotalRow]

    @property
    def severity(self) -> Severity:
        levels = [group.severity for group in self.groups] + [finding.severity for finding in self.file_findings]
        return max(levels, default=Severity.OK)

    def all_invoices(self) -> list[tuple[Group, InvoiceRow]]:
        return [(group, row) for group in self.groups for row in group.invoices]

    def pair_stats(self) -> PairStats:
        stats = PairStats()
        for group in self.groups:
            for link in group.links:
                if link.is_pair:
                    stats.pairs[link.severity] += 1
                elif link.old and link.new:
                    stats.regrouped += 1
                    stats.regrouped_old += len(link.old)
                    stats.regrouped_new += len(link.new)
                elif link.old:
                    stats.only_old += 1
                else:
                    stats.only_new += 1
        return stats


@dataclass
class PairStats:
    pairs: Counter = field(default_factory=Counter)
    regrouped: int = 0
    regrouped_old: int = 0
    regrouped_new: int = 0
    only_old: int = 0
    only_new: int = 0


# --- helpers -----------------------------------------------------------------


def unique(values) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def fold(value: str) -> str:
    """Case, whitespace, punctuation and Polish diacritics insensitive form."""
    value = value.replace("ł", "l").replace("Ł", "L")
    decomposed = unicodedata.normalize("NFKD", value)
    plain = "".join(char for char in decomposed if not unicodedata.combining(char))
    return re.sub(r"[^0-9a-z]+", " ", plain.casefold()).strip()


def soft(value: str) -> str:
    return " ".join(value.split()).casefold()


def totals(payments: list[Payment]) -> dict[str, Decimal]:
    result: dict[str, Decimal] = defaultdict(Decimal)
    for payment in payments:
        if payment.amount is not None:
            result[payment.currency] += payment.amount
    return dict(result)


def money(value: Decimal | None, currency: str = "") -> str:
    if value is None:
        return "—"
    sign = "-" if value < 0 else ""
    whole, _, fraction = f"{abs(value):.2f}".partition(".")
    groups = []
    while whole:
        groups.insert(0, whole[-3:])
        whole = whole[:-3]
    text = f"{sign}{' '.join(groups)},{fraction}"
    return f"{text} {currency}".strip()


def money_map(values: dict[str, Decimal]) -> str:
    return ", ".join(money(amount, currency) for currency, amount in sorted(values.items())) or "—"


def delta_map(old: dict[str, Decimal], new: dict[str, Decimal]) -> dict[str, Decimal]:
    return {currency: new.get(currency, Decimal(0)) - old.get(currency, Decimal(0)) for currency in sorted(set(old) | set(new)) if new.get(currency) != old.get(currency)}


def account_text(value: str) -> str:
    if not value:
        return "(brak)"
    return " ".join(value[i:i + 4] for i in range(0, len(value), 4))


def payment_ref(payment: Payment) -> str:
    refs = [ref.display for ref in payment.refs]
    detail = "jedyny numer w przelewie" if len(refs) == 1 else f"numerów w przelewie: {len(refs)}"
    return f"{payment.label} ({money(payment.amount, payment.currency)}, {detail})"


def _group_ref(group: Group, side: str) -> str:
    payment = (group.old if side == OLD else group.new)[0]
    return f"#{group.id} {group.creditor_name} ({account_text(payment.creditor_account)}, {payment.execution_date})"


def ref_keys(payments: list[Payment]) -> Counter[str]:
    return Counter(ref.key for payment in payments for ref in payment.refs)


# --- grouping ------------------------------------------------------------------


def _full_key(payment: Payment) -> tuple[str, str, str, str]:
    return payment.debtor_account, payment.creditor_account, payment.currency, payment.execution_date


def _buckets(payments: list[Payment]) -> dict[tuple[str, str, str, str], list[Payment]]:
    result: dict[tuple[str, str, str, str], list[Payment]] = defaultdict(list)
    for payment in payments:
        result[_full_key(payment)].append(payment)
    return result


def _names(payments: list[Payment]) -> set[str]:
    return {fold(payment.creditor_name) for payment in payments if fold(payment.creditor_name)}


def build_groups(old: list[Payment], new: list[Payment]) -> list[Group]:
    old_buckets, new_buckets = _buckets(old), _buckets(new)
    raw: list[tuple[list[Payment], list[Payment], str]] = []

    for key in [key for key in old_buckets if key in new_buckets]:
        raw.append((old_buckets.pop(key), new_buckets.pop(key), "klucz"))

    old_relaxed: dict[tuple[str, str, str], list] = defaultdict(list)
    new_relaxed: dict[tuple[str, str, str], list] = defaultdict(list)
    for key in old_buckets:
        old_relaxed[key[:3]].append(key)
    for key in new_buckets:
        new_relaxed[key[:3]].append(key)
    for relaxed in [key for key in old_relaxed if key in new_relaxed]:
        old_payments = [payment for key in old_relaxed[relaxed] for payment in old_buckets.pop(key)]
        new_payments = [payment for key in new_relaxed[relaxed] for payment in new_buckets.pop(key)]
        raw.append((old_payments, new_payments, "inna data"))

    # Remaining buckets differ in an account or currency. Pair them when they share
    # most invoice numbers or the creditor name, so the report shows what changed.
    new_tokens = {key: set(ref_keys(payments)) for key, payments in new_buckets.items()}
    new_names = {key: _names(payments) for key, payments in new_buckets.items()}
    by_token: dict[str, set] = defaultdict(set)
    by_name: dict[str, set] = defaultdict(set)
    for key in new_buckets:
        for token in new_tokens[key]:
            by_token[token].add(key)
        for name in new_names[key]:
            by_name[name].add(key)
    candidates = []
    for old_key, old_payments in old_buckets.items():
        tokens = set(ref_keys(old_payments))
        names = _names(old_payments)
        reachable = set()
        for token in tokens:
            reachable |= by_token[token]
        for name in names:
            reachable |= by_name[name]
        for new_key in reachable:
            union = tokens | new_tokens[new_key]
            jaccard = len(tokens & new_tokens[new_key]) / len(union) if union else 0.0
            same_name = bool(names & new_names[new_key])
            if jaccard < 0.5 and not same_name:
                continue
            same_total = totals(old_payments) == totals(new_buckets[new_key])
            score = 2 * jaccard + (1 if same_name else 0) + (0.5 if same_total else 0)
            candidates.append((-score, str(old_key), str(new_key), old_key, new_key, "po fakturach" if jaccard >= 0.5 else "po nazwie"))
    for _, _, _, old_key, new_key, how in sorted(candidates):
        if old_key in old_buckets and new_key in new_buckets:
            raw.append((old_buckets.pop(old_key), new_buckets.pop(new_key), how))

    raw.extend((payments, [], f"tylko {OLD}") for payments in old_buckets.values())
    raw.extend(([], payments, f"tylko {NEW}") for payments in new_buckets.values())

    def order(item: tuple[list[Payment], list[Payment], str]) -> tuple:
        payments = item[0] + item[1]
        first = payments[0]
        return fold(first.creditor_name), first.creditor_account, first.execution_date, first.currency, min(p.seq for p in item[0] or item[1])

    return [Group(index, old_payments, new_payments, how) for index, (old_payments, new_payments, how) in enumerate(sorted(raw, key=order), start=1)]


# --- reading of ambiguous Ustrd line breaks -------------------------------------------


def _resolve_variants(payments: list[Payment], other: Counter[str]) -> None:
    for payment in payments:
        if len(payment.text_variants) <= 1:
            continue

        def score(index: int) -> tuple[int, int]:
            mine = Counter(ref.key for ref in payment.fixed_refs + payment.text_variants[index].refs)
            matched = sum((mine & other).values())
            return matched - (sum(mine.values()) - matched), -payment.text_variants[index].glued

        payment.chosen_variant = max(range(len(payment.text_variants)), key=score)


# --- attribute comparison -------------------------------------------------------------


def _values(payments: list[Payment], getter) -> list[str]:
    return unique(getter(payment) for payment in payments)


def _list(values: list[str]) -> str:
    return ", ".join(value or "(brak)" for value in values) or "(brak)"


def plural(count: int) -> str:
    if count == 1:
        return "1 przelew"
    if count % 10 in (2, 3, 4) and count % 100 not in (12, 13, 14):
        return f"{count} przelewy"
    return f"{count} przelewów"


def _where(old: list[Payment], new: list[Payment]) -> str:
    return f"{', '.join(p.label for p in old) or '—'} ↔ {', '.join(p.label for p in new) or '—'}"


def payment_summary(payment: Payment) -> str:
    refs = ", ".join(ref.display for ref in payment.refs)
    return f"{payment.label}: {money(payment.amount, payment.currency)}, {payment.execution_date} | {refs or payment.remittance_text or '(bez opisu)'}"


def _set_diff(old: list[Payment], new: list[Payment], getter, severity: Severity, category: str, message: str, where: str = "") -> Finding | None:
    old_values, new_values = _values(old, getter), _values(new, getter)
    if set(old_values) == set(new_values):
        return None
    return Finding(severity, category, message, _list(old_values), _list(new_values), where)


def _names_diff(old: list[Payment], new: list[Payment], getter, category: str, label: str, different: Severity, where: str) -> Finding | None:
    old_values = [value for value in _values(old, getter) if value]
    new_values = [value for value in _values(new, getter) if value]
    if set(old_values) == set(new_values):
        return None
    old_text, new_text = " / ".join(old_values) or "(brak)", " / ".join(new_values) or "(brak)"
    if {soft(value) for value in old_values} == {soft(value) for value in new_values}:
        return Finding(Severity.KOSMETYCZNA, category, f"{label}: różnica tylko w wielkości liter lub spacjach", old_text, new_text, where)
    if {fold(value) for value in old_values} == {fold(value) for value in new_values}:
        return Finding(Severity.KOSMETYCZNA, category, f"{label}: różnica tylko w polskich znakach lub interpunkcji", old_text, new_text, where)
    if old_values and new_values and all(any(fold(a).startswith(fold(b)) or fold(b).startswith(fold(a)) for b in new_values) for a in old_values):
        return Finding(Severity.KOSMETYCZNA, category, f"{label}: jedna wersja jest skrócona", old_text, new_text, where)
    return Finding(different, category, f"{label}: inna wartość", old_text, new_text, where)


def _words(text: str) -> list[str]:
    return [part.strip(EDGE_PUNCTUATION).casefold() for part in SEPARATOR.split(text) if part.strip(EDGE_PUNCTUATION)]


def _strd_parts(payment: Payment) -> set[str]:
    return {part for part in re.split(r"; | \|\| ", payment.strd_summary) if part}


def _description_findings(old: Payment, new: Payment, where: str) -> list[Finding]:
    findings = []
    a, b = old.remittance_text, new.remittance_text
    if a != b:
        if soft(a) == soft(b):
            severity, message = Severity.KOSMETYCZNA, "Opis różni się tylko wielkością liter lub odstępami"
        elif _words(a) == _words(b):
            severity, message = Severity.KOSMETYCZNA, "Opis różni się tylko separatorami (np. „, ” zamiast spacji)"
        elif fold(a) == fold(b):
            severity, message = Severity.KOSMETYCZNA, "Opis różni się tylko polskimi znakami lub interpunkcją"
        elif sorted(_words(a)) == sorted(_words(b)):
            severity, message = Severity.KOSMETYCZNA, "Opis zawiera te same elementy w innej kolejności"
        else:
            severity, message = Severity.ISTOTNA, "Opis płatności (Ustrd) jest inny"
        findings.append(Finding(severity, "Opis", message, a or "(brak)", b or "(brak)", where))
    if old.strd_summary != new.strd_summary:
        same = _strd_parts(old) == _strd_parts(new)
        findings.append(Finding(
            Severity.KOSMETYCZNA if same else Severity.ISTOTNA,
            "Opis",
            "Opis strukturalny (Strd): te same dane w innej kolejności" if same else "Opis strukturalny (Strd) jest inny",
            old.strd_summary or "(brak)",
            new.strd_summary or "(brak)",
            where,
        ))
    return findings


def _mpp_findings(old: list[Payment], new: list[Payment], where: str) -> list[Finding]:
    old_mpp = [payment for payment in old if payment.mpp]
    new_mpp = [payment for payment in new if payment.mpp]
    if not old_mpp and not new_mpp:
        return []
    if bool(old_mpp) != bool(new_mpp):
        side = OLD if old_mpp else NEW
        return [Finding(Severity.KRYTYCZNA, "MPP", f"Podzielona płatność (MPP) jest tylko w pliku {side}", f"przelewy MPP: {len(old_mpp)}", f"przelewy MPP: {len(new_mpp)}", where)]
    findings = []
    old_vat = sum((payment.mpp.vat or Decimal(0) for payment in old_mpp), Decimal(0))
    new_vat = sum((payment.mpp.vat or Decimal(0) for payment in new_mpp), Decimal(0))
    if old_vat != new_vat:
        findings.append(Finding(Severity.KRYTYCZNA, "MPP", f"Kwota VAT w MPP jest różna (Δ {money(new_vat - old_vat)})", money(old_vat), money(new_vat), where))
    if totals(old_mpp) != totals(new_mpp):
        findings.append(Finding(Severity.ISTOTNA, "MPP", "Kwota przelewów wysłanych jako MPP jest różna", money_map(totals(old_mpp)), money_map(totals(new_mpp)), where))
    nip = _set_diff(old_mpp, new_mpp, lambda payment: payment.mpp.nip, Severity.ISTOTNA, "MPP", "NIP odbiorcy (IDC/TaxId) jest różny", where)
    if nip:
        findings.append(nip)
    return findings


def _address_finding(old: list[Payment], new: list[Payment], where: str) -> Finding | None:
    old_country = [value for value in _values(old, lambda p: p.creditor_country) if value]
    new_country = [value for value in _values(new, lambda p: p.creditor_country) if value]
    if old_country and new_country and set(old_country) != set(new_country):
        return Finding(Severity.ISTOTNA, "Adres", "Kraj w adresie beneficjenta jest różny", ", ".join(old_country), ", ".join(new_country), where)
    old_address, new_address = _values(old, lambda p: p.creditor_address), _values(new, lambda p: p.creditor_address)
    if {fold(value) for value in old_address} == {fold(value) for value in new_address}:
        return None
    same_words = {word for value in old_address for word in fold(value).split()} == {word for value in new_address for word in fold(value).split()}
    return Finding(
        Severity.KOSMETYCZNA if same_words else Severity.ISTOTNA,
        "Adres",
        "Adres beneficjenta: te same dane w innym układzie pól" if same_words else "Adres beneficjenta jest inny",
        " / ".join(value for value in old_address if value) or "(brak)",
        " / ".join(value for value in new_address if value) or "(brak)",
        where,
    )


def _attribute_findings(old: list[Payment], new: list[Payment], where: str) -> list[Finding]:
    findings: list[Finding | None] = []
    for name in PAYMENT_TYPE_FIELDS:
        old_values = _values(old, lambda payment: payment.payment_type[name])
        new_values = _values(new, lambda payment: payment.payment_type[name])
        if set(old_values) == set(new_values):
            continue
        absent = "" in old_values or "" in new_values
        severity = Severity.ISTOTNA if not absent or name in ABSENCE_MATTERS else Severity.KOSMETYCZNA
        message = PAYMENT_TYPE_LABELS[name] + (" — w jednym pliku brak pola" if absent else " — inna wartość")
        findings.append(Finding(severity, "Typ przelewu", message, _list(old_values), _list(new_values), where))
    findings.append(_names_diff(old, new, lambda p: p.creditor_name, "Beneficjent", "Nazwa beneficjenta", Severity.ISTOTNA, where))
    findings.append(_names_diff(old, new, lambda p: p.debtor_name, "Zleceniodawca", "Nazwa zleceniodawcy", Severity.ISTOTNA, where))
    findings.append(_names_diff(old, new, lambda p: p.ultimate_creditor, "Beneficjent", "Ostateczny beneficjent (UltmtCdtr)", Severity.ISTOTNA, where))
    findings.append(_names_diff(old, new, lambda p: p.ultimate_debtor, "Zleceniodawca", "Ostateczny zleceniodawca (UltmtDbtr)", Severity.ISTOTNA, where))
    old_bic = [value for value in _values(old, lambda p: p.creditor_bic) if value]
    new_bic = [value for value in _values(new, lambda p: p.creditor_bic) if value]
    if set(old_bic) != set(new_bic):
        both = bool(old_bic and new_bic)
        findings.append(Finding(
            Severity.ISTOTNA if both else Severity.KOSMETYCZNA,
            "Bank beneficjenta",
            "BIC banku beneficjenta jest różny" if both else "BIC banku beneficjenta podany tylko w jednym pliku",
            ", ".join(old_bic) or "(brak)",
            ", ".join(new_bic) or "(brak)",
            where,
        ))
    findings.append(_address_finding(old, new, where))
    findings.append(_set_diff(old, new, lambda p: p.tax_info, Severity.ISTOTNA, "Podatek", "Dane płatności podatkowej (Tax) są różne", where))
    findings.extend(_mpp_findings(old, new, where))
    return [finding for finding in findings if finding is not None]


def _merge(findings: list[Finding]) -> list[Finding]:
    """The same difference repeated on many pairs (e.g. a name) is shown once with all pairs."""
    merged: dict[tuple, Finding] = {}
    for finding in findings:
        key = (finding.severity, finding.category, finding.message, finding.old, finding.new)
        if key in merged and finding.where:
            merged[key].where = f"{merged[key].where}; {finding.where}" if merged[key].where else finding.where
        else:
            merged.setdefault(key, finding)
    return list(merged.values())


# --- group analysis ---------------------------------------------------------------


def _truncation_hint(key: str, payments: list[Payment]) -> str:
    hints = []
    for payment in payments:
        refs = payment.refs
        if refs and key.startswith(refs[-1].key) and key != refs[-1].key:
            hints.append(f"ostatni numer w opisie {payment.label} („{refs[-1].display}”) wygląda na ucięty")
        elif payment.ustrd_length >= NEAR_LIMIT:
            hints.append(f"opis {payment.label} ma {payment.ustrd_length} znaków — możliwe obcięcie przez limit {DESCRIPTION_LIMIT}")
    return "; ".join(unique(hints))


def _analyze_invoices(group: Group, elsewhere: dict[str, dict[str, list[Group]]]) -> None:
    old_counter, new_counter = ref_keys(group.old), ref_keys(group.new)
    holders: dict[str, dict[str, list[Payment]]] = {OLD: defaultdict(list), NEW: defaultdict(list)}
    display: dict[str, str] = {}
    amounts: dict[str, dict[str, set]] = {OLD: defaultdict(set), NEW: defaultdict(set)}
    for side, payments in ((OLD, group.old), (NEW, group.new)):
        for payment in payments:
            for ref in payment.refs:
                display.setdefault(ref.key, ref.display)
                if payment not in holders[side][ref.key]:
                    holders[side][ref.key].append(payment)
                if ref.amount is not None:
                    amounts[side][ref.key].add(ref.amount)
    one_sided = not group.old or not group.new

    def order(key: str) -> tuple:
        natural = [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", key)]
        return old_counter[key] == new_counter[key], key not in old_counter, [(isinstance(p, str), p) for p in natural]

    for key in sorted(display, key=order):
        old_count, new_count = old_counter[key], new_counter[key]
        notes = []
        if old_count == new_count:
            status = "zgodna"
        elif new_count == 0:
            status = f"tylko {OLD}"
            notes.append(_truncation_hint(key, group.new))
        elif old_count == 0:
            status = f"tylko {NEW}"
            notes.append(_truncation_hint(key, group.old))
        else:
            status = f"liczba wystąpień {old_count} → {new_count}"
        if old_count != new_count:
            for side, count in ((NEW, new_count), (OLD, old_count)):
                if count < max(old_count, new_count):
                    other_groups = [item for item in elsewhere[side].get(key, []) if item is not group]
                    if other_groups:
                        listed = ", ".join(_group_ref(item, side) for item in other_groups[:3])
                        notes.append(f"w pliku {side} ten numer jest w innej grupie: {listed}")
        note = "; ".join(filter(None, notes))
        group.invoices.append(InvoiceRow(display[key], old_count, new_count, holders[OLD][key], holders[NEW][key], status, note))
        if one_sided:
            continue
        if old_count != new_count:
            if new_count == 0:
                message = f"Faktura {display[key]} jest tylko w pliku {OLD}"
            elif old_count == 0:
                message = f"Faktura {display[key]} jest tylko w pliku {NEW}"
            elif new_count > old_count:
                message = f"Faktura {display[key]} występuje w pliku {NEW} więcej razy ({old_count} → {new_count})"
            else:
                message = f"Faktura {display[key]} występuje w pliku {NEW} mniej razy ({old_count} → {new_count})"
            if note:
                message += f" — {note}"
            group.findings.append(Finding(
                Severity.KRYTYCZNA,
                "Faktury",
                message,
                "; ".join(payment_ref(payment) for payment in holders[OLD][key]) or "—",
                "; ".join(payment_ref(payment) for payment in holders[NEW][key]) or "—",
            ))
        elif amounts[OLD][key] and amounts[NEW][key] and amounts[OLD][key] != amounts[NEW][key]:
            group.findings.append(Finding(
                Severity.KRYTYCZNA,
                "Faktury",
                f"Kwota faktury {display[key]} w opisie strukturalnym jest różna",
                ", ".join(money(value) for value in sorted(amounts[OLD][key])),
                ", ".join(money(value) for value in sorted(amounts[NEW][key])),
            ))


def _analyze_link(link: Link) -> list[Finding]:
    """Findings for one set of corresponding payments; also sets the link status."""
    where = _where(link.old, link.new)
    findings: list[Finding] = []
    if not link.old or not link.new:
        payment = (link.old or link.new)[0]
        other = NEW if link.old else OLD
        findings.append(Finding(
            Severity.KRYTYCZNA,
            "Brak odpowiednika",
            f"Przelew nie ma odpowiednika w pliku {other}",
            payment_summary(payment) if payment.side == OLD else "—",
            payment_summary(payment) if payment.side == NEW else "—",
            where,
        ))
    else:
        if link.is_pair:
            old, new = link.old[0], link.new[0]
            if old.amount != new.amount or old.currency != new.currency:
                delta = f" (Δ {money(new.amount - old.amount, new.currency)})" if old.amount is not None and new.amount is not None and old.currency == new.currency else ""
                findings.append(Finding(Severity.KRYTYCZNA, "Kwota", f"Kwota przelewu jest różna{delta}", money(old.amount, old.currency), money(new.amount, new.currency), where))
            findings.extend(_description_findings(old, new, where))
        else:
            findings.append(Finding(
                Severity.KRYTYCZNA,
                "Grupowanie",
                f"Faktury są inaczej rozłożone na przelewy: {plural(len(link.old))} w pliku {OLD}, {plural(len(link.new))} w pliku {NEW}",
                "; ".join(payment_summary(payment) for payment in link.old),
                "; ".join(payment_summary(payment) for payment in link.new),
                where,
            ))
        findings.extend(_attribute_findings(link.old, link.new, where))

    severity = max((finding.severity for finding in findings), default=Severity.OK)
    if link.old and link.new:
        # Invoice, account and date differences are reported once per group, but decide the pair status too.
        if ref_keys(link.old) != ref_keys(link.new) or totals(link.old) != totals(link.new):
            severity = Severity.KRYTYCZNA
        for getter in (lambda p: p.debtor_account, lambda p: p.creditor_account, lambda p: p.currency):
            if set(_values(link.old, getter)) != set(_values(link.new, getter)):
                severity = Severity.KRYTYCZNA
        if set(_values(link.old, lambda p: p.execution_date)) != set(_values(link.new, lambda p: p.execution_date)):
            severity = max(severity, Severity.ISTOTNA)
    link.severity = severity
    link.note = _link_note(link.old, link.new)
    return findings


def analyze_group(group: Group, elsewhere: dict[str, dict[str, list[Group]]]) -> None:
    invalid = [payment for payment in group.payments if payment.amount is None or not payment.currency]
    if invalid:
        group.findings.append(Finding(Severity.KRYTYCZNA, "Kwota", "Przelew bez poprawnej kwoty lub waluty", ", ".join(f"{p.label} „{p.amount_raw}”" for p in invalid if p.side == OLD), ", ".join(f"{p.label} „{p.amount_raw}”" for p in invalid if p.side == NEW)))

    if not group.new or not group.old:
        side, other, payments = (OLD, NEW, group.old) if group.old else (NEW, OLD, group.new)
        related = unique(
            _group_ref(item, other)
            for key in ref_keys(payments)
            for item in elsewhere[other].get(key, [])
            if item is not group
        )
        hint = f" — numery z tych przelewów są w pliku {other} w grupie: {', '.join(related[:3])}" if related else ""
        listed = "; ".join(payment_summary(payment) for payment in payments[:10]) + (f"; … (+{len(payments) - 10})" if len(payments) > 10 else "")
        group.findings.append(Finding(
            Severity.KRYTYCZNA,
            "Brak odpowiednika",
            f"{plural(len(payments)).capitalize()} tylko w pliku {side}, brak odpowiednika w pliku {other}{hint}",
            listed if side == OLD else "—",
            listed if side == NEW else "—",
        ))
        _analyze_invoices(group, elsewhere)
        group.links = [Link([payment], [], f"tylko {OLD}", Severity.KRYTYCZNA) for payment in group.old]
        group.links += [Link([], [payment], f"tylko {NEW}", Severity.KRYTYCZNA) for payment in group.new]
        return

    for getter, severity, category, message in (
        (lambda p: p.debtor_account, Severity.KRYTYCZNA, "Rachunek", "Rachunek obciążany jest różny"),
        (lambda p: p.creditor_account, Severity.KRYTYCZNA, "Rachunek", "Rachunek beneficjenta jest różny"),
        (lambda p: p.currency, Severity.KRYTYCZNA, "Waluta", "Waluta jest różna"),
        (lambda p: p.execution_date, Severity.ISTOTNA, "Data", "Data wykonania jest różna"),
    ):
        finding = _set_diff(group.old, group.new, getter, severity, category, message)
        if finding:
            group.findings.append(finding)

    old_total, new_total = group.total(OLD), group.total(NEW)
    if old_total != new_total:
        delta = ", ".join(money(value, currency) for currency, value in delta_map(old_total, new_total).items())
        group.findings.append(Finding(Severity.KRYTYCZNA, "Kwota", f"Suma kwot dla beneficjenta jest różna (Δ {delta})", money_map(old_total), money_map(new_total)))

    _analyze_invoices(group, elsewhere)

    glued = [payment.label for payment in group.payments if payment.text_variants and payment.text_variants[payment.chosen_variant].glued]
    if glued:
        group.findings.append(Finding(Severity.KOSMETYCZNA, "Opis", "Numer faktury był rozdzielony między pola Ustrd — porównano po sklejeniu", ", ".join(p for p in glued if p.startswith(OLD)), ", ".join(p for p in glued if p.startswith(NEW))))

    group.links = link_payments(group.old, group.new)
    link_findings = [finding for link in group.links for finding in _analyze_link(link)]
    group.findings.extend(_merge(link_findings))


# --- payment level structure ---------------------------------------------------------


def _subset(target: Decimal, pool: list[Payment], max_size: int = 6, max_steps: int = 200_000) -> list[Payment] | None:
    items = sorted((p for p in pool if p.amount is not None and 0 < p.amount <= target), key=lambda p: p.amount, reverse=True)[:24]
    steps = 0

    def search(start: int, remaining: Decimal, chosen: list[Payment]) -> list[Payment] | None:
        nonlocal steps
        steps += 1
        if steps > max_steps:
            return None
        if remaining == 0 and len(chosen) >= 2:
            return list(chosen)
        if len(chosen) == max_size:
            return None
        for index in range(start, len(items)):
            amount = items[index].amount
            if amount > remaining:
                continue
            chosen.append(items[index])
            found = search(index + 1, remaining - amount, chosen)
            if found:
                return found
            chosen.pop()
        return None

    return search(0, target, [])


def _link_note(old: list[Payment], new: list[Payment]) -> str:
    if not old or not new:
        return ""
    notes = []
    old_total, new_total = totals(old), totals(new)
    if old_total != new_total:
        notes.append(f"suma {money_map(old_total)} → {money_map(new_total)}")
    old_keys, new_keys = ref_keys(old), ref_keys(new)
    missing, extra = old_keys - new_keys, new_keys - old_keys
    if missing:
        notes.append(f"tylko w pliku {OLD}: " + ", ".join(sorted(missing)))
    if extra:
        notes.append(f"tylko w pliku {NEW}: " + ", ".join(sorted(extra)))
    return "; ".join(notes)


def link_payments(old: list[Payment], new: list[Payment]) -> list[Link]:
    """Find which payments of both files correspond to each other.

    1. same amount and the same invoice numbers (or the same text when there are none),
    2. payments connected through shared invoice numbers (several payments → different grouping),
    3. without invoice numbers: same amount, then several payments summing up to one.
    """
    links: list[Link] = []
    rest_old, rest_new = list(old), list(new)

    for payment in list(rest_old):
        keys = ref_keys([payment])
        for candidate in rest_new:
            same_refs = ref_keys([candidate]) == keys and (keys or fold(candidate.description) == fold(payment.description))
            if candidate.amount == payment.amount and candidate.currency == payment.currency and same_refs:
                links.append(Link([payment], [candidate], "1:1"))
                rest_old.remove(payment)
                rest_new.remove(candidate)
                break

    parent: dict[int, int] = {}

    def find(item: int) -> int:
        parent.setdefault(item, item)
        while parent[item] != item:
            parent[item] = parent[parent[item]]
            item = parent[item]
        return item

    by_key: dict[str, list[Payment]] = defaultdict(list)
    for payment in rest_old + rest_new:
        for key in ref_keys([payment]):
            by_key[key].append(payment)
    for payments in by_key.values():
        for payment in payments[1:]:
            parent[find(id(payment))] = find(id(payments[0]))
    components: dict[int, list[Payment]] = defaultdict(list)
    for payment in rest_old + rest_new:
        components[find(id(payment))].append(payment)
    for members in components.values():
        component_old = [payment for payment in members if payment.side == OLD]
        component_new = [payment for payment in members if payment.side == NEW]
        if not component_old or not component_new:
            continue
        kind = "1:1" if len(component_old) == len(component_new) == 1 else f"grupowanie {len(component_old)}→{len(component_new)}"
        links.append(Link(component_old, component_new, kind))
        for payment in component_old:
            rest_old.remove(payment)
        for payment in component_new:
            rest_new.remove(payment)

    for payment in list(rest_old):
        candidate = next((item for item in rest_new if item.amount == payment.amount and item.currency == payment.currency), None)
        if candidate is not None:
            links.append(Link([payment], [candidate], "1:1 tylko po kwocie"))
            rest_old.remove(payment)
            rest_new.remove(candidate)

    for single, pool, forward in ((rest_new, rest_old, True), (rest_old, rest_new, False)):
        for payment in sorted(single, key=lambda p: p.amount or Decimal(0), reverse=True):
            if payment not in single or payment.amount is None:
                continue
            subset = _subset(payment.amount, [item for item in pool if item.currency == payment.currency])
            if not subset:
                continue
            link_old, link_new = (subset, [payment]) if forward else ([payment], subset)
            links.append(Link(link_old, link_new, f"grupowanie {len(link_old)}→{len(link_new)} tylko po kwocie"))
            single.remove(payment)
            for item in subset:
                pool.remove(item)

    links.extend(Link([payment], [], f"tylko {OLD}") for payment in rest_old)
    links.extend(Link([], [payment], f"tylko {NEW}") for payment in rest_new)
    return links


# --- file level ------------------------------------------------------------------------


def _consistency(document: Document, side: str) -> list[Finding]:
    findings = []
    amounts = [payment.amount for payment in document.payments]
    computed = sum((value for value in amounts if value is not None), Decimal(0))
    checks = [("GrpHdr", document.declared_count, document.declared_sum, len(document.payments), computed if None not in amounts else None)]
    checks += [(f"PmtInf {item.pmt_inf_id}", item.declared_count, item.declared_sum, item.count, item.total) for item in document.pmt_infs]
    for where, declared_count, declared_sum, count, total in checks:
        if declared_count and declared_count != str(count):
            findings.append(Finding(Severity.ISTOTNA, "Spójność pliku", f"{side}: {where} NbOfTxs={declared_count}, a przelewów jest {count}", document.name if side == OLD else "", document.name if side == NEW else ""))
        if declared_sum and total is not None:
            try:
                differs = Decimal(declared_sum) != total
            except ArithmeticError:
                differs = True
            if differs:
                findings.append(Finding(Severity.ISTOTNA, "Spójność pliku", f"{side}: {where} CtrlSum={declared_sum}, a suma kwot to {total}", document.name if side == OLD else "", document.name if side == NEW else ""))
    return findings


def compare_documents(old: Document, new: Document) -> Result:
    groups = build_groups(old.payments, new.payments)

    for group in groups:
        _resolve_variants(group.old, ref_keys(group.new))
        _resolve_variants(group.new, ref_keys(group.old))
        _resolve_variants(group.old, ref_keys(group.new))

    elsewhere: dict[str, dict[str, list[Group]]] = {OLD: defaultdict(list), NEW: defaultdict(list)}
    for group in groups:
        for side, payments in ((OLD, group.old), (NEW, group.new)):
            for key in ref_keys(payments):
                elsewhere[side][key].append(group)
    for group in groups:
        analyze_group(group, elsewhere)

    old_totals, new_totals = totals(old.payments), totals(new.payments)
    old_counts = Counter(payment.currency for payment in old.payments)
    new_counts = Counter(payment.currency for payment in new.payments)
    rows = [
        TotalRow(currency, old_counts[currency], old_totals.get(currency, Decimal(0)), new_counts[currency], new_totals.get(currency, Decimal(0)))
        for currency in sorted(set(old_counts) | set(new_counts))
    ]
    findings = []
    for row in rows:
        currency = row.currency or "(brak waluty)"
        if row.old_count != row.new_count:
            findings.append(Finding(Severity.KRYTYCZNA, "Liczba przelewów", f"Liczba przelewów w {currency} jest różna ({row.old_count} → {row.new_count})", str(row.old_count), str(row.new_count)))
        if row.old_sum != row.new_sum:
            findings.append(Finding(Severity.KRYTYCZNA, "Suma pliku", f"Łączna suma w {currency} jest różna (Δ {money(row.new_sum - row.old_sum, row.currency)})", money(row.old_sum, row.currency), money(row.new_sum, row.currency)))
    findings += _consistency(old, OLD) + _consistency(new, NEW)
    return Result(old, new, groups, findings, rows)
