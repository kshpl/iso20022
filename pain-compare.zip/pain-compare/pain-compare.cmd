@echo off
rem Runs pain-compare.ps1 with all arguments passed through; without arguments it starts the browser app.
rem -ExecutionPolicy Bypass applies only to this single PowerShell process; system settings are not changed.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pain-compare.ps1" %*
set "PAIN_COMPARE_EXIT=%ERRORLEVEL%"
rem Started by double-click: keep the window open so an error message can be read.
if "%~1"=="" if not "%PAIN_COMPARE_EXIT%"=="0" pause
exit /b %PAIN_COMPARE_EXIT%
