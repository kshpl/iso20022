# pain-compare — porównanie merytoryczne dwóch plików pain.001

Narzędzie tymczasowe na czas testów. Porównuje plik ze starego generatora ERP (STARY) z plikiem nowego rozwiązania (NOWY) **przelew po przelewie**. Każdy przelew z pliku STARY musi mieć w pliku NOWY dokładnie jeden odpowiednik z tą samą kwotą, rachunkami, datą, typem przelewu, MPP i opisem. Wolno się różnić tylko tagom technicznym: identyfikatorom, czasowi utworzenia i znacznikom wynikającym z wersji schematu. Inne rozłożenie faktur na przelewy (np. 3 przelewy → 1) jest różnicą krytyczną.

Narzędzie nie sprawdza zgodności ze schemą ani z wymaganiami banku, do tego służy ISO 20022 Manager.

Nie jest w repozytorium: katalog `pain-compare/` jest wpisany do lokalnego `.git/info/exclude`.

## Szybki start

| system | aplikacja w przeglądarce | porównanie w konsoli |
|---|---|---|
| Windows | dwuklik `pain-compare.cmd` albo `.\pain-compare.ps1` | `.\pain-compare.ps1 stary.xml nowy.xml` |
| macOS, Linux | `.venv/bin/python -m pain_compare web` | `.venv/bin/python -m pain_compare compare stary.xml nowy.xml` |
| ten komputer (repozytorium) | `../.venv/bin/python -m pain_compare web` | `../.venv/bin/python -m pain_compare compare stary.xml nowy.xml` |

Wszystkie polecenia uruchamia się w katalogu `pain-compare`. Na macOS i Linuksie potrzebne jest najpierw jednorazowe przygotowanie środowiska, opisane niżej. Na Windows robi to skrypt.

W aplikacji w przeglądarce:

1. Wskaż albo przeciągnij plik STARY i NOWY. Przycisk ⇄ zamienia je miejscami. Kliknij „Porównaj”.
2. Pod podsumowaniem zobaczysz pełny raport. „Pobierz ZIP (raport + CSV)” albo „Pobierz raport HTML” zapisuje plik do wysłania programistom. „Nowe porównanie” czyści formularz.
3. Zakończ przyciskiem „Zakończ”, klawiszami Ctrl+C w oknie konsoli albo zamykając to okno.

Aplikacja działa tylko pod adresem `127.0.0.1`, domyślnie na porcie 8875 albo pierwszym wolnym po nim. Wczytane pliki i raporty trzyma w pamięci do zamknięcia i nie zapisuje ich na dysku. Zostają tylko pliki, które pobierzesz. Raport zawiera rachunki, nazwy, kwoty i opisy płatności, więc wysyłaj go zaufanym kanałem.

Kopiując narzędzie na inny komputer, pomiń `.venv` (środowisko tworzy się na miejscu) oraz prawdziwe dane w `input/` i `reports/`.

## Windows

### Przygotowanie

Zainstaluj Python 3.11 lub nowszy z python.org. Instalator dodaje launcher `py`, który skrypt znajdzie sam. Resztę skrypt zrobi przy pierwszym uruchomieniu: utworzy `.venv` obok siebie i zainstaluje `lxml` z internetu.

### Aplikacja w przeglądarce

Kliknij dwukrotnie `pain-compare.cmd` albo w PowerShellu, w katalogu `pain-compare`, wpisz:

```powershell
.\pain-compare.ps1
```

Jeśli po dwukliku coś pójdzie nie tak (np. brak Pythona), okno zostanie otwarte, żeby dało się przeczytać komunikat.

### Porównanie w konsoli

Przydaje się przy wielu parach plików albo w automatyzacji:

```powershell
.\pain-compare.ps1 .\input\stary.xml .\input\nowy.xml
```

Skrypt wypisuje wynik, zapisuje raport w `reports\` i otwiera `raport.html` w przeglądarce.

Gdy zasady wykonywania skryptów blokują pliki `.ps1` („running scripts is disabled on this system”), użyj nakładki `pain-compare.cmd` z tymi samymi argumentami. Uruchamia ona skrypt z `-ExecutionPolicy Bypass` tylko dla tego jednego wywołania i nie zmienia ustawień systemu:

```powershell
.\pain-compare.cmd .\input\stary.xml .\input\nowy.xml
```

### Parametry skryptu

Pełny opis: `Get-Help .\pain-compare.ps1 -Detailed`.

| parametr | znaczenie |
|---|---|
| `-Port N` | aplikacja: inny port niż 8875 |
| `-BezOtwierania` | nie otwieraj przeglądarki (aplikacji albo raportu) |
| `-Wszystko` | konsola: pokaż także grupy zgodne i kosmetyczne |
| `-Limit N` | konsola: maksymalna liczba grup (domyślnie 50) |
| `-Wynik KATALOG` | konsola: inny katalog raportu |
| `-BezPlikow` | konsola: bez raportu HTML/CSV |
| `-WzorzecFaktur 'FV/\d+/\d{2}/\d{4}'` | własny wzorzec numeru faktury |
| `-Odczyt PLIK [-Csv PLIK.csv]` | pokaż, co odczytano z jednego pliku |
| `-Python ŚCIEŻKA` | użyj konkretnego Pythona z `lxml` zamiast `.venv` |
| `-Wheelhouse KATALOG` | instalacja `lxml` bez internetu, z pobranego pliku `lxml-*.whl` |

```powershell
.\pain-compare.ps1 -Odczyt .\input\nowy.xml -Csv .\reports\nowy-odczyt.csv
```

## macOS i Linux

### Przygotowanie (jednorazowo)

Potrzebny jest Python 3.11 lub nowszy. Sprawdź wersję:

```bash
python3 --version
```

Na macOS starszy Python zastąp instalatorem z python.org albo `brew install python`. Na Linuksie zainstaluj Pythona z pakietów dystrybucji. Na Ubuntu 22.04, gdzie domyślny jest 3.10, użyj `sudo apt install python3.11 python3.11-venv`, a w poleceniu niżej `python3.11` zamiast `python3`.

W katalogu `pain-compare`:

```bash
python3 -m venv .venv
```

```bash
.venv/bin/python -m pip install lxml
```

Bez internetu zainstaluj `lxml` z pobranego pliku `lxml-*.whl`, pasującego do systemu i wersji Pythona:

```bash
.venv/bin/python -m pip install --no-index --find-links KATALOG_Z_WHL lxml
```

### Aplikacja w przeglądarce

```bash
.venv/bin/python -m pain_compare web
```

Przeglądarka otworzy się sama. Opcje:
- `--port 8900` wybiera inny port;
- `--no-browser` nie otwiera przeglądarki, adres jest wypisany w konsoli.

Na Linuksie bez środowiska graficznego (np. serwer przez SSH) uruchom z `--no-browser`. Na swoim komputerze otwórz tunel `ssh -L 8875:127.0.0.1:8875 serwer` i wejdź na `http://127.0.0.1:8875/`.

### Porównanie w konsoli

```bash
.venv/bin/python -m pain_compare compare input/stary.xml input/nowy.xml
```

```bash
.venv/bin/python -m pain_compare inspect input/nowy.xml --csv reports/nowy-odczyt.csv
```

Opcje `compare`:

| opcja | znaczenie |
|---|---|
| `--all` | pokaż także grupy zgodne i kosmetyczne |
| `--limit N` | maksymalna liczba grup w konsoli (domyślnie 50) |
| `--out KATALOG` | inny katalog raportu |
| `--no-files` | tylko konsola, bez HTML/CSV |
| `--invoice-regex WZORZEC` | własny wzorzec numeru faktury, np. `'FV/\d+/\d{2}/\d{4}'` |
| `--e2e-as-invoice` | traktuj `EndToEndId` jako numer faktury |

`inspect` przyjmuje `--invoice-regex` i `--csv PLIK`. Lista „najczęstszych słów” pokazuje fragmenty opisu, które nie zostały uznane za numery. Warto to sprawdzić przed pierwszym porównaniem.

### Na tym komputerze (repozytorium ISO 20022 Manager)

Przygotowanie nie jest potrzebne: Python 3.13 i `lxml` są już w `.venv` repozytorium. We wszystkich poleceniach zamiast `.venv/bin/python` użyj `../.venv/bin/python`, np.:

```bash
cd /Volumes/Store/Developer/iso_20022-manager/pain-compare
```

```bash
../.venv/bin/python -m pain_compare web
```

## Wyniki

Porównanie w konsoli zapisuje raport w `reports/<data>_<stary>_vs_<nowy>/`. ZIP pobrany z aplikacji zawiera te same pliki:

- `raport.html` — działa offline, ma filtry wag, wyszukiwarkę i rozwijane szczegóły;
- `roznice.csv` — wszystkie różnice;
- `faktury.csv` — każdy numer faktury: w ilu przelewach STARY i NOWY oraz status;
- `przelewy.csv` — wszystkie przelewy obu plików z przypisaną grupą i odpowiednikiem.

Pliki CSV mają separator `;`, przecinek dziesiętny i BOM, więc otwierają się poprawnie w polskim Excelu.

Kod wyjścia porównania w konsoli (także skryptu PowerShell): `0` brak różnic albo tylko kosmetyczne, `1` są różnice istotne lub krytyczne, `2` błąd wczytania pliku.

## Jak działa porównanie

1. **Odczyt.** Każdy przelew (`CdtTrfTxInf`) staje się rekordem z polami: rachunek obciążany, data, waluta, kwota, beneficjent (nazwa, rachunek, BIC, adres), typ przelewu, MPP i numery faktur. Obsługiwane są `pain.001.001.03` i `.09`. Elementy są rozpoznawane po nazwie, nie po wersji.
2. **Numery faktur.** Opis jest dzielony po spacjach, `;` i przecinkach. Przecinek między cyframi, jak w „100,00”, nie dzieli. Każdy fragment z cyfrą jest numerem, z wyjątkiem kwot typu „23.00” albo „1.234,56”. Dodatkowe źródła:
   - `Strd/RfrdDocInf/Nb` (z kwotą faktury, jeśli jest),
   - `Strd/CdtrRefInf/Ref`,
   - MPP: `/INV/` z opisu `/VAT/…/IDC/…/INV/…` albo `TaxRmt/RefNb`.

   Jeśli kilka pól `Ustrd` dzieli numer w środku (np. `FV/2/20` + `26`), wybierany jest odczyt najlepiej pasujący do drugiego pliku. Taka sytuacja jest zgłaszana jako różnica kosmetyczna.
3. **Grupy.** Żeby znaleźć odpowiedniki, przelewy są najpierw grupowane po kluczu rachunek obciążany + rachunek beneficjenta + waluta + data, czyli tym samym kluczem, którym ERP łączy faktury. Grupy bez pary są dopasowywane dalej:
   - ta sama para rachunków, ale inna data (różnica istotna),
   - wspólne faktury lub ta sama nazwa beneficjenta (różnica rachunku lub waluty jest krytyczna).

   Grupa bez odpowiednika dostaje wskazanie, gdzie w drugim pliku są jej faktury.
4. **Pary przelewów.** Wewnątrz grupy przelewy są łączone w pary:
   - 1:1: ta sama kwota i te same numery faktur (bez numerów: ten sam opis), potem po wspólnych numerach;
   - „grupowanie m→n”: faktury rozłożone na inną liczbę przelewów, zawsze różnica krytyczna;
   - przy braku numerów: po samej kwocie;
   - przelew bez odpowiednika: różnica krytyczna.

   Każda para 1:1 jest porównywana pole po polu: kwota, opis (`Ustrd`, `Strd`), typ przelewu, nazwy stron, BIC, adres, MPP i dane podatkowe. Ta sama różnica powtórzona na wielu parach, np. nazwa beneficjenta, jest pokazana raz z listą par.

Główną miarą wyniku jest blok „Przelewy”: ile par 1:1 jest identycznych merytorycznie, ile ma różnice, ile przelewów zgrupowano inaczej i ile nie ma odpowiednika.

## Wagi różnic

- **krytyczna**:
  - inne grupowanie faktur, przelew bez odpowiednika, inna liczba przelewów w pliku;
  - kwota przelewu, suma, waluta, rachunek;
  - faktura brakująca, nadmiarowa lub zdublowana, kwota faktury;
  - VAT w MPP, MPP tylko w jednym pliku;
- **istotna**:
  - data wykonania, typ przelewu (`SvcLvl`, `LclInstrm`, `CtgyPurp`, `ChrgBr`);
  - inny tekst opisu (`Ustrd`) lub inny opis strukturalny (`Strd`);
  - inna nazwa beneficjenta lub zleceniodawcy, BIC, inny adres lub kraj;
  - NIP w MPP, dane `Tax`, niespójne `NbOfTxs`/`CtrlSum` w pliku;
- **kosmetyczna**:
  - opis różny tylko separatorami (`, ` zamiast spacji), odstępami, wielkością liter, polskimi znakami lub kolejnością;
  - nazwa różna tylko wielkością liter, polskimi znakami lub skrótem;
  - adres z tymi samymi danymi w innym układzie pól;
  - BIC podany tylko w jednym pliku.

Kosmetyczne różnice nie zmieniają kodu wyjścia, ale są w raporcie, bo to też różnice w treści widocznej dla odbiorcy.

**Pomijane:** `MsgId`, `CreDtTm`, `PmtInfId`, `InstrId`, `EndToEndId`, kolejność, podział na `PmtInf`, wersja schematu, spacje w IBAN, NRB bez `PL`, zapis kwoty (`100.1` = `100.10`).

Przy opisie dłuższym niż 130 znaków, albo gdy ostatni numer jest początkiem brakującego, raport podpowiada możliwe obcięcie przez limit 140 znaków.

## Testy

Na tym komputerze, w katalogu `pain-compare`:

```bash
../.venv/bin/python -m pytest -q
```

Na innym komputerze najpierw `.venv/bin/python -m pip install pytest`, potem `.venv/bin/python -m pytest -q`. Testy używają wyłącznie syntetycznych plików generowanych w `tests/builder.py`.

## Usunięcie po testach

macOS i Linux, w katalogu nadrzędnym względem `pain-compare`:

```bash
rm -rf pain-compare
```

Windows (PowerShell), w katalogu nadrzędnym:

```powershell
Remove-Item -Recurse -Force .\pain-compare
```

W repozytorium ISO 20022 Manager usuń też z `.git/info/exclude` linię `pain-compare/` i komentarz nad nią.
