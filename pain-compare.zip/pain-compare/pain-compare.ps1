﻿<#
.SYNOPSIS
    Merytoryczne porównanie dwóch plików pain.001 (STARY z ERP i NOWY z nowego rozwiązania).

.DESCRIPTION
    Uruchamia narzędzie pain_compare z katalogu, w którym leży ten skrypt.
    Przy pierwszym uruchomieniu tworzy obok skryptu środowisko .venv i instaluje w nim lxml.

    Bez parametrów uruchamia aplikację w przeglądarce: wybierasz pliki STARY i NOWY,
    oglądasz raport i pobierasz go (HTML albo ZIP z raportem i tabelami CSV).
    Aplikacja działa tylko pod adresem 127.0.0.1 do kliknięcia „Zakończ” albo Ctrl+C.

    Z parametrami -Stary i -Nowy porównuje pliki w konsoli; raport HTML i pliki CSV
    trafiają do katalogu reports\, a raport HTML otwiera się w przeglądarce.

    Kod wyjścia: 0 = zgodne (brak różnic albo tylko kosmetyczne), 1 = różnice istotne lub krytyczne,
    2 = błąd wczytania pliku lub przygotowania środowiska.

.PARAMETER Port
    Port aplikacji w przeglądarce (domyślnie pierwszy wolny od 8875).

.PARAMETER Stary
    Plik XML ze starego generatora ERP.

.PARAMETER Nowy
    Plik XML z nowego rozwiązania.

.PARAMETER Wynik
    Katalog raportu. Domyślnie reports\<data>_<stary>_vs_<nowy> obok skryptu.

.PARAMETER Wszystko
    Pokaż w konsoli także grupy zgodne i z różnicami kosmetycznymi.

.PARAMETER Limit
    Maksymalna liczba grup wypisanych w konsoli (domyślnie 50). Raport zawiera wszystkie.

.PARAMETER BezPlikow
    Tylko wynik w konsoli, bez raportu HTML i CSV.

.PARAMETER BezOtwierania
    Nie otwieraj przeglądarki (aplikacji albo raportu HTML).

.PARAMETER Odczyt
    Zamiast porównania pokaż, co narzędzie odczytało z jednego pliku (numery faktur, słowa opisu).

.PARAMETER Csv
    Razem z -Odczyt: zapisz listę przelewów do pliku CSV.

.PARAMETER WzorzecFaktur
    Własne wyrażenie regularne numeru faktury, np. 'FV/\d+/\d{2}/\d{4}'.
    Domyślnie numerem jest każdy fragment opisu zawierający cyfrę (z wyjątkiem kwot).

.PARAMETER Python
    Ścieżka do konkretnego interpretera Python 3.11+ z zainstalowanym lxml (pomija .venv).

.PARAMETER Wheelhouse
    Katalog z plikiem lxml-*.whl do instalacji bez internetu.

.EXAMPLE
    .\pain-compare.ps1

    Uruchamia aplikację w przeglądarce.

.EXAMPLE
    .\pain-compare.ps1 .\input\stary.xml .\input\nowy.xml

.EXAMPLE
    .\pain-compare.ps1 .\input\stary.xml .\input\nowy.xml -Wszystko -BezOtwierania

.EXAMPLE
    .\pain-compare.ps1 -Odczyt .\input\nowy.xml -Csv .\reports\nowy-odczyt.csv

.EXAMPLE
    .\pain-compare.ps1 stary.xml nowy.xml -WzorzecFaktur 'FV/\d+/\d{2}/\d{4}'
#>
[CmdletBinding(DefaultParameterSetName = 'Aplikacja')]
param(
    [Parameter(ParameterSetName = 'Aplikacja')]
    [ValidateRange(1, 65535)]
    [int]$Port,

    [Parameter(ParameterSetName = 'Porownanie', Mandatory = $true, Position = 0)]
    [string]$Stary,

    [Parameter(ParameterSetName = 'Porownanie', Mandatory = $true, Position = 1)]
    [string]$Nowy,

    [Parameter(ParameterSetName = 'Porownanie')]
    [string]$Wynik,

    [Parameter(ParameterSetName = 'Porownanie')]
    [switch]$Wszystko,

    [Parameter(ParameterSetName = 'Porownanie')]
    [ValidateRange(1, 100000)]
    [int]$Limit = 50,

    [Parameter(ParameterSetName = 'Porownanie')]
    [switch]$BezPlikow,

    [Parameter(ParameterSetName = 'Aplikacja')]
    [Parameter(ParameterSetName = 'Porownanie')]
    [switch]$BezOtwierania,

    [Parameter(ParameterSetName = 'Odczyt', Mandatory = $true)]
    [string]$Odczyt,

    [Parameter(ParameterSetName = 'Odczyt')]
    [string]$Csv,

    [Parameter(ParameterSetName = 'Porownanie')]
    [Parameter(ParameterSetName = 'Odczyt')]
    [string]$WzorzecFaktur,

    [string]$Python,
    [string]$Wheelhouse
)

Set-StrictMode -Version 2
# Native commands (python, pip) report through exit codes; 'Stop' would turn their stderr into exceptions in PowerShell 5.1.
$ErrorActionPreference = 'Continue'

$ToolDir = $PSScriptRoot
$OnWindows = ($env:OS -eq 'Windows_NT')
$VenvDir = Join-Path $ToolDir '.venv'
if ($OnWindows) {
    $VenvPython = Join-Path $VenvDir 'Scripts\python.exe'
} else {
    $VenvPython = Join-Path (Join-Path $VenvDir 'bin') 'python'
}

function Write-Info([string]$Text) {
    Write-Host $Text -ForegroundColor Cyan
}

function New-PythonCommand([string]$Exe, [string[]]$PreArgs = @()) {
    [pscustomobject]@{ Exe = $Exe; PreArgs = $PreArgs }
}

function Invoke-Python($Py, [string[]]$Arguments, [switch]$Quiet) {
    $all = @($Py.PreArgs) + @($Arguments)
    if ($Quiet) {
        & $Py.Exe @all 2>$null | Out-Null
    } else {
        & $Py.Exe @all
    }
}

function Test-PythonCode($Py, [string]$Code) {
    # A missing command would leave a stale $LASTEXITCODE, so check that it exists first.
    if (-not (Get-Command $Py.Exe -ErrorAction SilentlyContinue)) { return $false }
    try {
        Invoke-Python $Py @('-c', $Code) -Quiet
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

function Test-Python($Py) {
    return (Test-PythonCode $Py 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)')
}

function Test-Lxml($Py) {
    return (Test-PythonCode $Py 'import lxml.etree')
}

function Find-BasePython {
    $candidates = @()
    if (Get-Command py -ErrorAction SilentlyContinue) { $candidates += New-PythonCommand 'py' @('-3') }
    foreach ($name in @('python', 'python3')) {
        if (Get-Command $name -ErrorAction SilentlyContinue) { $candidates += New-PythonCommand $name }
    }
    foreach ($candidate in $candidates) {
        if (Test-Python $candidate) { return $candidate }
    }
    return $null
}

function Install-Lxml($Py) {
    $pipArgs = @('-m', 'pip', 'install', '--disable-pip-version-check')
    if ($Wheelhouse) {
        $wheels = (Resolve-Path -LiteralPath $Wheelhouse -ErrorAction Stop).ProviderPath
        Write-Info "Instaluję lxml z katalogu $wheels (jednorazowo)..."
        $pipArgs += @('--no-index', '--find-links', $wheels, 'lxml')
    } else {
        Write-Info 'Instaluję lxml z PyPI (jednorazowo, wymaga internetu)...'
        $pipArgs += @('lxml')
    }
    Invoke-Python $Py $pipArgs
    if ($LASTEXITCODE -ne 0 -or -not (Test-Lxml $Py)) {
        throw 'Instalacja lxml nie powiodła się. Bez dostępu do internetu pobierz plik lxml-*.whl pasujący do wersji Pythona i podaj jego katalog parametrem -Wheelhouse.'
    }
}

function Get-ToolPython {
    if ($Python) {
        $py = New-PythonCommand $Python
        if (-not (Test-Python $py)) { throw "Interpreter '$Python' nie działa albo jest starszy niż Python 3.11." }
        if (-not (Test-Lxml $py)) { throw "W interpreterze '$Python' brakuje biblioteki lxml. Zainstaluj ją: $Python -m pip install lxml" }
        return $py
    }
    $py = New-PythonCommand $VenvPython
    if (-not ((Test-Path -LiteralPath $VenvPython) -and (Test-Python $py))) {
        $base = Find-BasePython
        if (-not $base) {
            throw 'Nie znaleziono Pythona 3.11 lub nowszego. Zainstaluj go z python.org (launcher "py" albo opcja "Add python.exe to PATH") lub wskaż interpreter parametrem -Python.'
        }
        Write-Info "Tworzę środowisko $VenvDir (jednorazowo)..."
        Invoke-Python $base @('-m', 'venv', '--clear', $VenvDir)
        if ($LASTEXITCODE -ne 0 -or -not (Test-Python $py)) { throw "Nie udało się utworzyć środowiska $VenvDir." }
    }
    if (-not (Test-Lxml $py)) { Install-Lxml $py }
    return $py
}

function Resolve-InputFile([string]$Path, [string]$Label) {
    $resolved = Resolve-Path -LiteralPath $Path -ErrorAction SilentlyContinue
    if (-not $resolved) { throw "Nie znaleziono pliku $($Label): $Path" }
    return $resolved.ProviderPath
}

function Get-OutputPath([string]$Path) {
    return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
}

function Get-SafeStem([string]$Path) {
    $stem = [IO.Path]::GetFileNameWithoutExtension($Path) -replace '[^\w.-]+', '_'
    if ($stem.Length -gt 40) { $stem = $stem.Substring(0, 40) }
    return $stem
}

$exitCode = 2
$report = $null
$previousPythonPath = $env:PYTHONPATH
$previousIoEncoding = $env:PYTHONIOENCODING
$previousConsoleEncoding = $null
try {
    $py = Get-ToolPython

    if ($PSCmdlet.ParameterSetName -eq 'Aplikacja') {
        $arguments = @('-m', 'pain_compare', 'web')
        if ($Port) { $arguments += @('--port', [string]$Port) }
        if ($BezOtwierania) { $arguments += '--no-browser' }
    } elseif ($PSCmdlet.ParameterSetName -eq 'Odczyt') {
        $arguments = @('-m', 'pain_compare', 'inspect', (Resolve-InputFile $Odczyt 'do odczytu'))
        if ($Csv) { $arguments += @('--csv', (Get-OutputPath $Csv)) }
    } else {
        $oldFile = Resolve-InputFile $Stary 'STARY'
        $newFile = Resolve-InputFile $Nowy 'NOWY'
        $arguments = @('-m', 'pain_compare', 'compare', $oldFile, $newFile, '--limit', [string]$Limit)
        if ($Wszystko) { $arguments += '--all' }
        if ($BezPlikow) {
            $arguments += '--no-files'
        } else {
            if ($Wynik) {
                $outDir = Get-OutputPath $Wynik
            } else {
                $name = '{0}_{1}_vs_{2}' -f (Get-Date -Format 'yyyy-MM-dd_HHmmss'), (Get-SafeStem $oldFile), (Get-SafeStem $newFile)
                $outDir = Join-Path (Join-Path $ToolDir 'reports') $name
            }
            $arguments += @('--out', $outDir)
            $report = Join-Path $outDir 'raport.html'
        }
    }
    if ($WzorzecFaktur) { $arguments += @('--invoice-regex', $WzorzecFaktur) }

    if ($previousPythonPath) {
        $env:PYTHONPATH = $ToolDir + [IO.Path]::PathSeparator + $previousPythonPath
    } else {
        $env:PYTHONPATH = $ToolDir
    }
    $env:PYTHONIOENCODING = 'utf-8'
    try {
        $previousConsoleEncoding = [Console]::OutputEncoding
        [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
    } catch {
        $previousConsoleEncoding = $null
    }

    Invoke-Python $py $arguments
    $exitCode = $LASTEXITCODE
} catch {
    Write-Host "BŁĄD: $($_.Exception.Message)" -ForegroundColor Red
    $exitCode = 2
} finally {
    $env:PYTHONPATH = $previousPythonPath
    $env:PYTHONIOENCODING = $previousIoEncoding
    if ($previousConsoleEncoding) {
        try { [Console]::OutputEncoding = $previousConsoleEncoding } catch { }
    }
}

if ($PSCmdlet.ParameterSetName -eq 'Aplikacja' -and $exitCode -ne 0) {
    Write-Host 'Nie udało się uruchomić aplikacji (szczegóły powyżej).' -ForegroundColor Red
}
if ($PSCmdlet.ParameterSetName -eq 'Porownanie') {
    Write-Host ''
    switch ($exitCode) {
        0 { Write-Host 'Wynik: zgodne (brak różnic albo tylko kosmetyczne).' -ForegroundColor Green }
        1 { Write-Host 'Wynik: są różnice istotne lub krytyczne — szczegóły w raporcie.' -ForegroundColor Red }
        2 { Write-Host 'Wynik: nie udało się porównać plików (szczegóły powyżej).' -ForegroundColor Red }
        default { Write-Host "Wynik: nieoczekiwany błąd narzędzia (kod $exitCode)." -ForegroundColor Red }
    }
    if ($report -and ($exitCode -eq 0 -or $exitCode -eq 1) -and (Test-Path -LiteralPath $report)) {
        Write-Host "Raport: $report"
        if (-not $BezOtwierania) { Invoke-Item -LiteralPath $report }
    }
}
exit $exitCode
