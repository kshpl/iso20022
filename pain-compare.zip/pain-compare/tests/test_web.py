from __future__ import annotations

import base64
import http.client
import io
import json
import re
import threading
import zipfile

import pytest

from builder import build, tx
from pain_compare.web import start_server


@pytest.fixture
def server():
    instance = start_server(port=0)
    thread = threading.Thread(target=instance.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    yield instance
    instance.shutdown()
    instance.server_close()


def request(server, method, path, body=None, headers=None, host=None):
    port = server.server_address[1]
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    connection.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
    connection.putheader("Host", host or f"127.0.0.1:{port}")
    for name, value in (headers or {}).items():
        connection.putheader(name, value)
    if body is not None:
        connection.putheader("Content-Length", str(len(body)))
    connection.endheaders(body)
    response = connection.getresponse()
    data = response.read()
    connection.close()
    return response, data


def compare_body(old: bytes, new: bytes, old_name="stary ERP.xml", new_name="nowy.xml", regex="") -> bytes:
    return json.dumps({
        "old": {"name": old_name, "data": base64.b64encode(old).decode()},
        "new": {"name": new_name, "data": base64.b64encode(new).decode()},
        "invoice_regex": regex,
    }).encode()


def auth(server, origin=True):
    headers = {"Content-Type": "application/json", "X-Token": server.state.token}
    if origin:
        headers["Origin"] = f"http://127.0.0.1:{server.server_address[1]}"
    return headers


def test_index_contains_token_and_nonce_csp(server):
    response, data = request(server, "GET", "/")
    page = data.decode()
    assert response.status == 200
    assert server.state.token in page and "__TOKEN__" not in page
    nonce = re.search(r'<script nonce="([^"]+)"', page).group(1)
    assert f"'nonce-{nonce}'" in response.getheader("Content-Security-Policy")
    assert response.getheader("X-Frame-Options") == "DENY"


def test_foreign_host_is_rejected(server):
    response, _ = request(server, "GET", "/", host="evil.example:80")
    assert response.status == 403


def test_compare_flow_and_downloads(server):
    old = build([tx("100.00", "FV/1"), tx("200.00", "FV/2")])
    new = build([tx("300.00", "FV/1, FV/2")], version="03", msg_id="M2")
    response, data = request(server, "POST", "/api/compare", compare_body(old, new), auth(server))
    assert response.status == 200, data
    summary = json.loads(data)
    assert summary["severity"] == 3 and summary["verdict"] == "Są różnice krytyczne."
    assert summary["pairs"]["regrouped"] == 1 and summary["pairs"]["regrouped_old"] == 2
    assert summary["files"][0] == {"side": "STARY", "name": "stary ERP.xml", "version": "pain.001.001.09", "count": 2}
    assert summary["filename"].startswith("porownanie_stary_ERP_vs_nowy_")

    response, view = request(server, "GET", summary["links"]["view"])
    assert response.status == 200 and b"Faktury s\xc4\x85 inaczej roz\xc5\x82o\xc5\xbcone" in view
    assert response.getheader("Content-Disposition") is None

    response, html = request(server, "GET", summary["links"]["html"])
    assert response.getheader("Content-Disposition") == f'attachment; filename="{summary["filename"]}.html"'
    assert html == view

    response, archive = request(server, "GET", summary["links"]["zip"])
    assert response.getheader("Content-Type") == "application/zip"
    with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
        assert sorted(zipped.namelist()) == ["faktury.csv", "przelewy.csv", "raport.html", "roznice.csv"]
        assert zipped.read("raport.html") == view


def test_compare_requires_token_and_same_origin(server):
    body = compare_body(build([tx("1.00", "FV/1")]), build([tx("1.00", "FV/1")]))
    response, _ = request(server, "POST", "/api/compare", body, {"Content-Type": "application/json"})
    assert response.status == 403
    headers = auth(server)
    headers["Origin"] = "https://evil.example"
    response, _ = request(server, "POST", "/api/compare", body, headers)
    assert response.status == 403
    response, _ = request(server, "POST", "/api/compare", body, auth(server, origin=False))
    assert response.status == 200


def test_input_errors_are_reported(server):
    good = build([tx("1.00", "FV/1")])
    response, data = request(server, "POST", "/api/compare", compare_body(good, b"<Document>"), auth(server))
    assert response.status == 422 and "nowy.xml: Niepoprawny XML" in json.loads(data)["error"]
    response, data = request(server, "POST", "/api/compare", compare_body(good, good, regex="FV("), auth(server))
    assert response.status == 422 and "Niepoprawny wzorzec" in json.loads(data)["error"]
    response, data = request(server, "POST", "/api/compare", b"{", auth(server))
    assert response.status == 422


def test_unknown_report_and_shutdown(server):
    response, _ = request(server, "GET", "/report/AAAAAAAAAAAAAAAAAAAAAAAA/raport.html")
    assert response.status == 404
    response, _ = request(server, "POST", "/api/shutdown", b"", {"X-Token": "wrong"})
    assert response.status == 403
    response, _ = request(server, "POST", "/api/shutdown", b"", {"X-Token": server.state.token})
    assert response.status == 200
