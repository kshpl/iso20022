from __future__ import annotations

import re

import pytest

from builder import ACME, BETA, tx, write
from pain_compare.compare import NEW, OLD, compare_documents
from pain_compare.extract import InputError, load_document
from pain_compare.model import Severity
from pain_compare.remittance import tokenize


def run(tmp_path, old, new, old_options=None, new_options=None, regex=None):
    old_path = write(tmp_path, "old.xml", old, **(old_options or {}))
    new_path = write(tmp_path, "new.xml", new, **(new_options or {"msg_id": "MSG-2"}))
    pattern = re.compile(regex, re.IGNORECASE) if regex else None
    return compare_documents(load_document(old_path, OLD, pattern), load_document(new_path, NEW, pattern))


def messages(result, severity=None):
    found = [f.message for g in result.groups for f in g.findings if severity is None or f.severity == severity]
    return found + [f.message for f in result.file_findings if severity is None or f.severity == severity]


def test_technical_differences_are_ignored(tmp_path):
    old = [
        tx("100.1", "FV/1/2026", account="61109010140000071219812874"),
        tx("200.00", "FV/2/2026", name="Beta SA", account=BETA),
    ]
    new = [
        tx("200.00", "FV/2/2026", name="Beta SA", account="PL27 1140 2004 0000 3002 0135 5387"),
        tx("100.10", "FV/1/2026", account=ACME),
    ]
    result = run(tmp_path, old, new, {"version": "03"}, {"version": "09", "split_groups": True, "msg_id": "OTHER"})
    assert result.severity == Severity.OK, messages(result)
    assert {group.pairing for group in result.groups} == {"klucz"}


def test_regrouping_is_critical_even_when_totals_and_invoices_match(tmp_path):
    old = [tx("100.00", "FV/1/2026"), tx("200.00", "FV/2/2026"), tx("300.00", "FV/3/2026")]
    new = [tx("600.00", "FV/1/2026, FV/2/2026, FV/3/2026")]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KRYTYCZNA
    [group] = result.groups
    [link] = group.links
    assert link.kind == "grupowanie 3→1" and link.severity == Severity.KRYTYCZNA
    finding = next(f for f in group.findings if f.category == "Grupowanie")
    assert finding.message == "Faktury są inaczej rozłożone na przelewy: 3 przelewy w pliku STARY, 1 przelew w pliku NOWY"
    assert finding.where == "STARY #1, STARY #2, STARY #3 ↔ NOWY #1"
    assert "STARY #2: 200,00 PLN, 2026-10-08 | FV/2/2026" in finding.old
    assert not [f for f in group.findings if f.category in {"Kwota", "Faktury"}]
    assert any("Liczba przelewów w PLN jest różna (3 → 1)" in m for m in messages(result))


def test_different_split_of_grouped_invoices(tmp_path):
    old = [tx("300.00", "FV/1/2026 FV/2/2026"), tx("300.00", "FV/3/2026")]
    new = [tx("100.00", "FV/1/2026"), tx("500.00", "FV/2/2026, FV/3/2026")]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KRYTYCZNA
    assert result.groups[0].links[0].kind == "grupowanie 2→2"


def test_same_grouping_with_other_separator_is_cosmetic(tmp_path):
    old = [tx("300.00", "FV/1/2026, FV/2/2026"), tx("50.00", "FV/3/2026")]
    new = [tx("50.00", "FV/3/2026"), tx("300.00", "FV/1/2026 FV/2/2026")]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KOSMETYCZNA, messages(result)
    [finding] = result.groups[0].findings
    assert finding.message == "Opis różni się tylko separatorami (np. „, ” zamiast spacji)"
    assert finding.where == "STARY #1 ↔ NOWY #2"
    assert result.pair_stats().pairs == {Severity.OK: 1, Severity.KOSMETYCZNA: 1}


def test_other_description_text_is_important(tmp_path):
    result = run(tmp_path, [tx("100.00", "Zapłata za FV/1/2026")], [tx("100.00", "Płatność FV/1/2026")])
    assert result.severity == Severity.ISTOTNA
    assert "Opis płatności (Ustrd) jest inny" in messages(result)


def test_same_difference_on_many_pairs_is_reported_once(tmp_path):
    old = [tx(f"{n}.00", f"FV/{n}", name="Zakład Łódź") for n in range(1, 4)]
    new = [tx(f"{n}.00", f"FV/{n}", name="ZAKLAD LODZ") for n in range(1, 4)]
    result = run(tmp_path, old, new)
    [finding] = result.groups[0].findings
    assert finding.where == "STARY #1 ↔ NOWY #1; STARY #2 ↔ NOWY #2; STARY #3 ↔ NOWY #3"


def test_pair_statistics(tmp_path):
    old = [tx("1.00", "FV/1"), tx("2.00", "FV/2"), tx("3.00", "FV/3"), tx("4.00", "FV/4"), tx("5.00", "FV/5", name="Beta SA", account=BETA)]
    new = [tx("1.00", "FV/1"), tx("2.50", "FV/2"), tx("7.00", "FV/3 FV/4")]
    stats = run(tmp_path, old, new).pair_stats()
    assert stats.pairs == {Severity.OK: 1, Severity.KRYTYCZNA: 1}
    assert (stats.regrouped, stats.regrouped_old, stats.regrouped_new) == (1, 2, 1)
    assert (stats.only_old, stats.only_new) == (1, 0)


def test_missing_invoice_in_grouped_payment(tmp_path):
    old = [tx("100.00", "FV/1/2026"), tx("200.00", "FV/2/2026"), tx("300.00", "FV/3/2026")]
    new = [tx("300.00", "FV/1/2026 FV/2/2026")]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KRYTYCZNA
    critical = messages(result, Severity.KRYTYCZNA)
    assert any("Suma kwot dla beneficjenta jest różna (Δ -300,00 PLN)" in m for m in critical)
    finding = next(f for f in result.groups[0].findings if "FV/3/2026" in f.message)
    assert "tylko w pliku STARY" in finding.message
    assert "300,00 PLN, jedyny numer w przelewie" in finding.old


def test_amount_difference_with_same_invoices(tmp_path):
    result = run(tmp_path, [tx("300.00", "FV/1/2026, FV/2/2026")], [tx("310.00", "FV/1/2026, FV/2/2026")])
    assert result.severity == Severity.KRYTYCZNA
    assert not [r for g in result.groups for r in g.invoices if r.status != "zgodna"]
    [link] = result.groups[0].links
    assert link.kind == "1:1" and not link.ok and "300,00 PLN → 310,00 PLN" in link.note
    assert "Kwota przelewu jest różna (Δ 10,00 PLN)" in messages(result)


def test_different_creditor_account_is_paired_by_invoices(tmp_path):
    old = [tx("300.00", "FV/1/2026, FV/2/2026")]
    new = [tx("300.00", "FV/1/2026, FV/2/2026", account="PL10105000997603123456789123")]
    result = run(tmp_path, old, new)
    [group] = result.groups
    assert group.links[0].severity == Severity.KRYTYCZNA
    assert group.pairing == "po fakturach"
    assert any(f.message == "Rachunek beneficjenta jest różny" and f.severity == Severity.KRYTYCZNA for f in group.findings)
    assert not any(f.category == "Brak odpowiednika" for f in group.findings)


def test_part_of_group_sent_to_wrong_account_points_to_original_group(tmp_path):
    old = [tx("600.00", "FV/1 FV/2 FV/3")]
    new = [tx("300.00", "FV/1 FV/2"), tx("300.00", "FV/3", account="PL10105000997603123456789123")]
    result = run(tmp_path, old, new)
    stray = next(g for g in result.groups if g.pairing == "tylko NOWY")
    [finding] = [f for f in stray.findings if f.category == "Brak odpowiednika"]
    assert "numery z tych przelewów są w pliku STARY w grupie: #" in finding.message
    assert "PL61 1090 1014" in finding.message and "2026-10-08" in finding.message


def test_different_execution_date_is_important(tmp_path):
    result = run(tmp_path, [tx("100.00", "FV/1/2026")], [tx("100.00", "FV/1/2026", date="2026-10-09")])
    [group] = result.groups
    assert group.pairing == "inna data"
    assert result.severity == Severity.ISTOTNA
    assert "Data wykonania jest różna" in messages(result)


def test_invoice_moved_to_other_creditor_is_cross_referenced(tmp_path):
    old = [tx("300.00", "FV/1 FV/2"), tx("50.00", "FV/3", name="Beta SA", account=BETA)]
    new = [tx("100.00", "FV/1"), tx("250.00", "FV/2, FV/3", name="Beta SA", account=BETA)]
    result = run(tmp_path, old, new)
    acme = next(g for g in result.groups if g.creditor_name.startswith("ACME"))
    missing = next(f for f in acme.findings if "FV/2" in f.message)
    assert "w pliku NOWY ten numer jest w innej grupie" in missing.message and "Beta SA" in missing.message


def test_truncated_description_is_hinted(tmp_path):
    numbers = [f"FV/{n:04d}/10/2026/ODDZIAŁ" for n in range(1, 8)]
    old = [tx("10.00", number) for number in numbers]
    text = ", ".join(numbers)
    new = [tx("70.00", text[:140])]
    result = run(tmp_path, old, new)
    notes = " ".join(row.note for row in result.groups[0].invoices)
    assert "wygląda na ucięty" in notes
    assert "możliwe obcięcie przez limit 140" in notes


def test_number_split_between_ustrd_lines_is_glued(tmp_path):
    old = [tx("600.00", "FV/1/2026 FV/2/2026 FV/3/2026")]
    new = [tx("600.00", ["FV/1/2026 FV/2/20", "26 FV/3/2026"])]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KOSMETYCZNA, messages(result)
    assert any("rozdzielony między pola Ustrd" in m for m in messages(result))


def test_separate_ustrd_lines_are_not_glued(tmp_path):
    old = [tx("300.00", "FV/1/2026 FV/2/2026")]
    new = [tx("300.00", ["FV/1/2026", "FV/2/2026"])]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.OK, messages(result)


def test_split_payment_vat_difference(tmp_path):
    old = [tx("123.00", "/VAT/23,00/IDC/1234567890/INV/FV/9/2026/TXT/towar")]
    new = [tx("123.00", "/VAT/24,00/IDC/1234567890/INV/FV/9/2026/TXT/towar")]
    result = run(tmp_path, old, new)
    assert result.severity == Severity.KRYTYCZNA
    assert any("Kwota VAT w MPP jest różna (Δ 1,00)" in m for m in messages(result))
    assert result.groups[0].invoices[0].display == "FV/9/2026"


def test_split_payment_missing_in_new(tmp_path):
    result = run(tmp_path, [tx("123.00", "/VAT/23,00/IDC/1234567890/INV/FV/9/2026")], [tx("123.00", "FV/9/2026")])
    assert any("Podzielona płatność (MPP) jest tylko w pliku STARY" in m for m in messages(result, Severity.KRYTYCZNA))


def test_creditor_only_in_old(tmp_path):
    old = [tx("100.00", "FV/1"), tx("70.00", "FV/7", name="Beta SA", account=BETA)]
    result = run(tmp_path, old, [tx("100.00", "FV/1")])
    beta = next(g for g in result.groups if g.creditor_name == "Beta SA")
    assert beta.pairing == "tylko STARY" and beta.severity == Severity.KRYTYCZNA
    assert any("Łączna suma w PLN jest różna" in m for m in messages(result))


def test_name_diacritics_are_cosmetic(tmp_path):
    result = run(tmp_path, [tx("100.00", "FV/1", name="Zakład Łódź Sp. z o.o.")], [tx("100.00", "FV/1", name="ZAKLAD LODZ SP Z O O")])
    assert result.severity == Severity.KOSMETYCZNA
    assert any("polskich znakach" in m for m in messages(result))


def test_service_level_difference_is_important(tmp_path):
    result = run(tmp_path, [tx("100.00", "FV/1", svc="NURG")], [tx("100.00", "FV/1", svc="SEPA")])
    assert result.severity == Severity.ISTOTNA
    assert any("Typ usługi (SvcLvl)" in m for m in messages(result))


def test_payments_without_invoice_numbers_are_paired_by_amount(tmp_path):
    result = run(tmp_path, [tx("100.00", "Czynsz"), tx("200.00", "Opłata")], [tx("200.00", "Opłata"), tx("100.00", "Czynsz")])
    assert result.severity == Severity.OK, messages(result)
    result = run(tmp_path, [tx("100.00", "Czynsz"), tx("200.00", "Czynsz")], [tx("300.00", "Czynsz")])
    assert result.severity == Severity.KRYTYCZNA
    assert result.groups[0].links[0].kind == "grupowanie 2→1 tylko po kwocie"


def test_duplicate_invoice_in_new(tmp_path):
    result = run(tmp_path, [tx("100.00", "FV/1")], [tx("100.00", "FV/1"), tx("100.00", "FV/1")])
    assert any("więcej razy (1 → 2)" in m for m in messages(result, Severity.KRYTYCZNA))


def test_structured_invoice_amounts(tmp_path):
    def strd(number, amount):
        return f'<Strd><RfrdDocInf><Nb>{number}</Nb></RfrdDocInf><RfrdDocAmt><RmtdAmt Ccy="PLN">{amount}</RmtdAmt></RfrdDocAmt></Strd>'

    old = [tx("300.00", strd=strd("FV/1", "100.00") + strd("FV/2", "200.00"))]
    new = [tx("300.00", strd=strd("FV/1", "150.00") + strd("FV/2", "150.00"))]
    result = run(tmp_path, old, new)
    assert any("Kwota faktury FV/1 w opisie strukturalnym jest różna" in m for m in messages(result, Severity.KRYTYCZNA))


def test_custom_invoice_regex(tmp_path):
    old = [tx("100.00", "Zapłata 12 szt. FV/1/2026")]
    new = [tx("100.00", "Zapłata 13 szt. FV/1/2026")]
    assert run(tmp_path, old, new).severity == Severity.KRYTYCZNA
    result = run(tmp_path, old, new, regex=r"FV/\d+/\d{4}")
    assert result.severity == Severity.ISTOTNA
    assert messages(result, Severity.ISTOTNA) == ["Opis płatności (Ustrd) jest inny"]
    assert [row.display for row in result.groups[0].invoices] == ["FV/1/2026"]


def test_inconsistent_control_sum(tmp_path):
    result = run(tmp_path, [tx("100.00", "FV/1")], [tx("100.00", "FV/1")], new_options={"ctrl_sum": "999.00", "msg_id": "X"})
    assert result.severity == Severity.ISTOTNA
    assert any("NOWY: GrpHdr CtrlSum=999.00" in m for m in messages(result))


def test_tokenizer_rules():
    refs, words = tokenize("Faktury: FV/1/2026, FV/2/2026 FV 3/2026; kwota 1.234,56 zł,FV/4", "Ustrd")
    assert [ref.display for ref in refs] == ["FV/1/2026", "FV/2/2026", "3/2026", "FV/4"]
    assert words == ["Faktury", "FV", "kwota", "1.234,56", "zł"]


def test_doctype_is_rejected(tmp_path):
    path = tmp_path / "evil.xml"
    path.write_text('<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "b">]><Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.09"/>')
    with pytest.raises(InputError, match="DTD"):
        load_document(path, OLD)


def test_other_message_is_rejected(tmp_path):
    path = tmp_path / "camt.xml"
    path.write_text('<Document xmlns="urn:iso:std:iso:20022:tech:xsd:camt.053.001.02"/>')
    with pytest.raises(InputError, match="pain.001"):
        load_document(path, OLD)
