from __future__ import annotations

from builder import tx, write
from pain_compare.__main__ import main


def test_compare_writes_reports_and_exit_codes(tmp_path, capsys):
    old = write(tmp_path, "old.xml", [tx("100.00", "FV/1"), tx("200.00", "FV/2")])
    same = write(tmp_path, "same.xml", [tx("200.00", "FV/2"), tx("100.00", "FV/1")], version="03", msg_id="M2")
    different = write(tmp_path, "diff.xml", [tx("100.00", "FV/1")], msg_id="M3")

    out = tmp_path / "report"
    assert main(["compare", str(old), str(same), "--out", str(out)]) == 0
    assert "WYNIK: brak różnic merytorycznych." in capsys.readouterr().out
    for name in ("raport.html", "roznice.csv", "faktury.csv", "przelewy.csv"):
        assert (out / name).exists()
    payments_csv = (out / "przelewy.csv").read_bytes()
    assert payments_csv.startswith(b"\xef\xbb\xbfplik;nr;grupa")
    assert "100,00" in payments_csv.decode("utf-8-sig")

    assert main(["compare", str(old), str(different), "--no-files"]) == 1
    output = capsys.readouterr().out
    assert "[KRYT]" in output and "FV/2" in output

    broken = tmp_path / "broken.xml"
    broken.write_text("<Document>")
    assert main(["compare", str(old), str(broken), "--no-files"]) == 2
    assert "BŁĄD" in capsys.readouterr().err


def test_html_escapes_payment_data(tmp_path):
    old = write(tmp_path, "old.xml", [tx("100.00", "<script>alert(1)</script> FV/1", name="A & <B>")])
    new = write(tmp_path, "new.xml", [tx("100.00", "FV/1", name="A & <B>")], msg_id="M2")
    out = tmp_path / "report"
    main(["compare", str(old), str(new), "--out", str(out)])
    html = (out / "raport.html").read_text(encoding="utf-8")
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html


def test_inspect(tmp_path, capsys):
    path = write(tmp_path, "file.xml", [tx("100.00", "Zapłata FV/1/2026, FV/2/2026")])
    csv_path = tmp_path / "inspect.csv"
    assert main(["inspect", str(path), "--csv", str(csv_path)]) == 0
    output = capsys.readouterr().out
    assert "FV/1/2026, FV/2/2026" in output and "zapłata × 1" in output
    assert csv_path.read_text(encoding="utf-8-sig").startswith("nr;data")
