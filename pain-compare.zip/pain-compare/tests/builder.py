"""Synthetic pain.001 builder for tests (no real payment data)."""

from __future__ import annotations

from decimal import Decimal
from pathlib import Path
from xml.sax.saxutils import escape

NAMESPACES = {
    "03": "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03",
    "09": "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09",
}
DEBTOR = "PL14999999990000000000000001"
ACME = "PL61109010140000071219812874"
BETA = "PL27114020040000300201355387"


def tx(
    amount: str,
    ustrd: str | list[str] | None = None,
    *,
    name: str = "ACME Sp. z o.o.",
    account: str = ACME,
    ccy: str = "PLN",
    date: str = "2026-10-08",
    debtor: str = DEBTOR,
    svc: str = "",
    strd: str = "",
    bic: str = "",
    e2e: str = "",
) -> dict:
    lines = [] if ustrd is None else ([ustrd] if isinstance(ustrd, str) else list(ustrd))
    return {
        "amount": amount, "ustrd": lines, "name": name, "account": account, "ccy": ccy, "date": date,
        "debtor": debtor, "svc": svc, "strd": strd, "bic": bic, "e2e": e2e,
    }


def _account(value: str) -> str:
    compact = value.replace(" ", "")
    if compact.isdigit():
        return f"<Othr><Id>{escape(value)}</Id></Othr>"
    return f"<IBAN>{escape(value)}</IBAN>"


def build(payments: list[dict], version: str = "09", *, split_groups: bool = False, ctrl_sum: str | None = None, msg_id: str = "MSG-1") -> bytes:
    bic_tag = "BICFI" if version == "09" else "BIC"
    groups: dict[object, list[dict]] = {}
    for index, payment in enumerate(payments):
        key = index if split_groups else (payment["date"], payment["debtor"], payment["svc"])
        groups.setdefault(key, []).append(payment)

    blocks = []
    counter = 0
    for number, members in enumerate(groups.values(), start=1):
        first = members[0]
        date = f"<ReqdExctnDt><Dt>{first['date']}</Dt></ReqdExctnDt>" if version == "09" else f"<ReqdExctnDt>{first['date']}</ReqdExctnDt>"
        service = f"<PmtTpInf><SvcLvl><Cd>{first['svc']}</Cd></SvcLvl></PmtTpInf>" if first["svc"] else ""
        transactions = []
        for payment in members:
            counter += 1
            remittance = "".join(f"<Ustrd>{escape(line)}</Ustrd>" for line in payment["ustrd"]) + payment["strd"]
            agent = f"<CdtrAgt><FinInstnId><{bic_tag}>{payment['bic']}</{bic_tag}></FinInstnId></CdtrAgt>" if payment["bic"] else ""
            transactions.append(
                "<CdtTrfTxInf>"
                f"<PmtId><InstrId>{msg_id}-I{counter}</InstrId><EndToEndId>{escape(payment['e2e'] or f'{msg_id}-E{counter}')}</EndToEndId></PmtId>"
                f"<Amt><InstdAmt Ccy=\"{payment['ccy']}\">{payment['amount']}</InstdAmt></Amt>{agent}"
                f"<Cdtr><Nm>{escape(payment['name'])}</Nm></Cdtr><CdtrAcct><Id>{_account(payment['account'])}</Id></CdtrAcct>"
                + (f"<RmtInf>{remittance}</RmtInf>" if remittance else "")
                + "</CdtTrfTxInf>"
            )
        total = sum((Decimal(p["amount"]) for p in members), Decimal(0))
        blocks.append(
            f"<PmtInf><PmtInfId>{msg_id}-P{number}</PmtInfId><PmtMtd>TRF</PmtMtd><NbOfTxs>{len(members)}</NbOfTxs><CtrlSum>{total}</CtrlSum>"
            f"{service}{date}<Dbtr><Nm>Firma Testowa</Nm></Dbtr><DbtrAcct><Id>{_account(first['debtor'])}</Id></DbtrAcct>"
            f"<DbtrAgt><FinInstnId><{bic_tag}>TESTPLPWXXX</{bic_tag}></FinInstnId></DbtrAgt>{''.join(transactions)}</PmtInf>"
        )
    total = ctrl_sum or str(sum((Decimal(p["amount"]) for p in payments), Decimal(0)))
    document = (
        f'<?xml version="1.0" encoding="UTF-8"?><Document xmlns="{NAMESPACES[version]}"><CstmrCdtTrfInitn>'
        f"<GrpHdr><MsgId>{msg_id}</MsgId><CreDtTm>2026-10-07T10:00:00</CreDtTm><NbOfTxs>{len(payments)}</NbOfTxs><CtrlSum>{total}</CtrlSum>"
        f"<InitgPty><Nm>Firma Testowa</Nm></InitgPty></GrpHdr>{''.join(blocks)}</CstmrCdtTrfInitn></Document>"
    )
    return document.encode("utf-8")


def write(directory: Path, name: str, payments: list[dict], **options) -> Path:
    path = directory / name
    path.write_bytes(build(payments, **options))
    return path
